APKs DO VAICOMIGO

Esta pasta é exclusivamente para os 3 APKs finais:
- VaiComigo-Passageiros.apk
- VaiComigo-Motorista.apk
- VaiComigo-Administracao.apk

ATENÇÃO: neste momento nenhum APK compilado existe no pacote original recebido.
Não renomeie ZIPs, pastas ou arquivos do projeto para .apk: isso não cria um aplicativo instalável.
