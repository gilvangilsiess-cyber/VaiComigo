# Auditoria de segurança — VaiComigo
Data: 24/09/2026. Escopo: PWA local e projeto Supabase conectado. Revisão estática + consultas de políticas, funções e advisors; sem pentest externo, varredura de rede ou teste real com duas contas.

## Corrigido e aplicado no banco

| Risco | Achado | Correção |
| --- | --- | --- |
| Crítico: promoção a administrador | `profiles` permitia ao titular alterar `role`; `is_admin()` confiava nesse campo. | Trigger impede INSERT com role diferente de passageiro e UPDATE de role pela sessão autenticada. RPCs internas continuam sob revisão. |
| Alto: exposição de embarques | `nearest_requested_rides` devolvia pontos de embarque a qualquer conta autenticada. | Exige motorista disponível com identidade, CNH e CRLV aprovados; raio limitado a 30 km. |
| Alto: substituição de evidência | Storage permitia `UPDATE` em arquivo de documentos do próprio motorista, inclusive depois da aprovação. | Removida política UPDATE; novos arquivos exigem nova análise. Bucket limitado a 8 MB e JPEG/PNG/PDF. |
| Alto: documentos inventados | Registro de CNH/CRLV no banco podia referir caminho sem arquivo privado associado. | Trigger valida conta, tipo, pasta e existência do objeto; toda inserção volta a `pending` e põe motorista offline. |
| Médio: dados do veículo | `get_public_driver_profile` permitia enumerar placa e perfil pelo UUID. | Dados devolvidos apenas a motorista titular, administrador ou passageiro de sua viagem; campo aprovado usa identidade e documentos. |
| Alto: cotação sem destino | `create_ride_quote` público a autenticados permitia distância declarada sem destino, com risco de tarifa manipulada. | EXECUTE revogado para anon e autenticados. Fluxo do app `create_ride_with_destination` segue disponível. |
| Médio: XSS e checkout | Texto de destino era inserido como HTML; caminho de documento ia para onclick; URL de checkout era injetada em onclick. | Escapar conteúdo, gerar botão com listener e exigir HTTPS em domínio Mercado Pago. |

As correções estão registradas nos arquivos `supabase/security-audit-*.sql`. Consultas confirmaram trigger do cargo, bloqueio de cotação direta e remoção de UPDATE de documento. Os 15 testes automatizados locais passaram. Alterações do frontend exigem novo deploy para chegar aos aparelhos.

## Pendências para operar com público

1. **Fraude de tarifa continua possível por parâmetro de distância** em `create_ride_with_destination`: a função rejeita distância inferior a 85% da linha reta, mas o cliente ainda envia distância/duração. Calcular rota e preço integralmente no servidor, com provedor de rotas ou motor confiável, antes de cobrar passageiros.
2. **Identidade manual não é KYC nem prova de vida.** Integrar fornecedor especializado em documento, face, vivacidade e antifraude; exigir revisão humana e procedimento para recurso, falsos positivos e contas bloqueadas.
3. **Biometria/documentos sem prazo automático de exclusão.** Definir política de retenção, base legal, aviso e procedimento de acesso/exclusão com assessoria jurídica, criar rotina de limpeza auditável; limitar downloads e acesso administrativo. Bucket privado não substitui governança.
4. **Proteção contra senha vazada desativada**, segundo o advisor Auth do Supabase. Ativar no Dashboard em Auth/password security; exigir MFA ao menos para o administrador e verificar sessões/recuperação de conta. Não foi alterado por não haver API de configuração Auth disponível nesta sessão.
5. **Superfície do frontend:** há muitos `innerHTML` e eventos `onclick` inline. A CSP estrita não pode ser ativada sem refatorar todos esses handlers. Fazer auditoria sistemática de cada dado vindo de usuário/servidor, remover HTML dinâmico e adicionar CSP sem `unsafe-inline` após a refatoração.
6. **Funções privilegiadas:** advisor aponta 52 funções SECURITY DEFINER executáveis por autenticados. Algumas são necessárias para RPCs e checam `auth.uid()`/`is_admin()`; revisar individualmente parâmetros e autorização. `get_shared_trip` é intencionalmente público com token temporário, exigindo limite de taxa e registro de acesso.
7. **Pagamento e notificações:** função push implantada aceita JWT ou segredo do webhook e valida dono da corrida; falta limitar frequência/volume de `user_notification` e solicitações de push por usuário. Pagamento online ainda precisa validação fim a fim de gateway, webhook idempotente e antifraude.
8. **Abuso de conta e disponibilidade:** acrescentar rate limiting no signup/login, uploads, busca, SOS e RPCs; retenção mínima de logs, monitoramento de tentativas e alertas. Configure CAPTCHA/SMTP e políticas para exclusão/revogação de acesso.
9. **Advisors adicionais:** extensões `cube`/`earthdistance` em `public` e duas tabelas privadas com RLS sem políticas (comportamento de bloqueio intencional). Revisar migração de extensões só com janela de manutenção para evitar quebrar consultas geográficas.

## Limites desta verificação

Não há garantia de invulnerabilidade. Não foram usados usuários simulados com permissões distintas para testar todos os RPCs, não se confirmou a configuração do Auth no Dashboard nem a versão atualmente publicada no Netlify. A revisão estática não substitui pentest de aplicação e teste integrado entre passageiro, motorista e diretor.
