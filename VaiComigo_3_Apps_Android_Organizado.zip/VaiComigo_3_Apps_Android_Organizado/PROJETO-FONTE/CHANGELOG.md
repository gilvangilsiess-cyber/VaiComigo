# Histórico e documentação anterior do VaiComigo

Conteúdo preservado dos 30 documentos anteriores, em ordem de versão/revisão. Registros históricos descrevem o estado na época em que foram escritos e podem mencionar arquivos posteriormente consolidados. As instruções atuais estão em `README.md`.

---

## README-v30.md

# VaiComigo v30 — PWA + Supabase

A v30 fecha a primeira camada operacional do aplicativo.

## Banco
Execute **depois de v29**:
- `v30-driver-availability-admin.sql`

Ele cria:
- `set_driver_availability(boolean)` — entrada/saída segura do motorista.
- `admin_set_driver_document_status(uuid,text)` — aprovação/reprovação de cadastro pelo administrador.

O motorista só fica `available` quando `document_status = 'approved'`.

## Frontend
- Interface PWA modernizada para celular.
- Passageiro, motorista e administrador no mesmo aplicativo.
- GPS com filtragem, snapping e fila offline.
- Chamadas reais e aceite de corrida.
- Realtime para corrida/localização.
- Compartilhamento de viagem e SOS.
- Histórico, pagamentos e carteira.
- Painel administrativo.

## Configuração
No primeiro uso, informe a URL do Supabase e a chave `anon/public`.
Nunca coloque `service_role` no navegador.

## Instalação no Android
Hospede estes arquivos em HTTPS. Abra o endereço no Chrome e use **Adicionar à tela inicial / Instalar aplicativo**.

---

## README-v31.md

# VaiComigo v31

Evolução do PWA v30 com experiência de corrida em tempo real.

## O que há de novo
- Painel de corrida ativa no início.
- Estados: procurando motorista → motorista encontrado → a caminho → corrida em andamento → concluída.
- Acompanhamento do motorista em tempo real.
- Compartilhamento e SOS acessíveis durante a corrida.
- Avaliação de 1 a 5 estrelas após conclusão.
- Comentário opcional da viagem.
- Nova migração `v31-rating.sql`.

## Banco
Execute as migrações anteriores em ordem e depois:
`v31-rating.sql`

A v31 usa as RPCs existentes de corrida, pagamento e segurança. A avaliação adiciona `ride_ratings` e `rate_completed_ride()`.

## PWA
Abra o `index.html` por HTTPS/localhost para usar geolocalização e Service Worker. Para publicar, coloque a pasta em um host HTTPS.

---

## README-v33.md

# VaiComigo v33

Esta versão acrescenta:
- login/cadastro por e-mail e senha, mantendo conexão anônima como modo de demonstração;
- perfil do passageiro;
- perfil do motorista e dados do veículo;
- cálculo da tarifa usando a rota OSRM quando disponível;
- criação segura da corrida por `create_ride_quote()`;
- métodos Pix, cartão e dinheiro sem armazenar dados brutos de cartão;
- consulta segura do motorista da corrida por `get_ride_driver()`.

## Supabase
Execute `v33-auth-fare-payment.sql` depois das migrações anteriores.

## Pagamentos
A interface não coleta nem armazena número de cartão, CVV ou senha. O checkout de cartão/Pix deve ser conectado posteriormente a um PSP/gateway que faça tokenização e autenticação do pagamento.

---

## README-v34.md

# VaiComigo v34 — pagamentos reais

A v34 adiciona integração de pagamento online com Mercado Pago via Supabase Edge Functions.

## O que está pronto
- Pix: cria cobrança real e mostra QR Code/código Pix.
- Cartão: cria checkout seguro do Mercado Pago e redireciona o passageiro.
- Webhook: consulta o pagamento no Mercado Pago e sincroniza o status no Supabase.
- Dinheiro: continua sendo confirmado pelo motorista.
- O navegador nunca recebe o Access Token do Mercado Pago.

A arquitetura segue o modelo recomendado pelo Supabase: segredos ficam nas Edge Functions, nunca no frontend. citeturn0search0turn0search5

## 1. Banco
Execute `v34-payment-gateway.sql` depois das migrações anteriores.

## 2. Secret do Mercado Pago
No Supabase, em Edge Function Secrets, crie:

`MP_ACCESS_TOKEN=SEU_ACCESS_TOKEN`

O token deve ficar somente no backend/Edge Function. O Supabase documenta que chaves secretas não devem ser enviadas para o navegador. citeturn0search0turn0search5

## 3. Deploy das funções

```bash
supabase functions deploy create-payment
supabase functions deploy mp-webhook --no-verify-jwt
```

A função de pagamento usa autenticação do usuário; o webhook é público porque é chamado pelo provedor e consulta o pagamento diretamente no Mercado Pago antes de alterar o banco. Supabase recomenda manter endpoints autenticados com JWT quando chamados pelo usuário. citeturn0search1turn0search4

## 4. Pix
O endpoint de pagamentos do Mercado Pago fornece QR Code/código Pix, que o PWA exibe ao passageiro. citeturn0search11

## 5. Produção
Antes de colocar dinheiro real em produção:
- configure credenciais de produção;
- configure a conta Mercado Pago da empresa;
- teste primeiro com credenciais de teste;
- configure domínio HTTPS do PWA;
- valide RLS e permissões do banco;
- teste aprovação, pendência, rejeição, cancelamento e webhook.

## 6. Observação
O cartão nesta versão usa o Checkout do Mercado Pago, evitando que o VaiComigo manipule diretamente número do cartão/CVV. Isso reduz a superfície de segurança do PWA.

---

## README-v35.md

# VaiComigo v35

## Novidades
- Perfil público seguro do motorista após aceite da corrida.
- Foto (quando cadastrada), nome, veículo, cor/ano, placa e avaliação média.
- Selo de motorista aprovado.
- Telefone, documentos e localização não são expostos no cartão público.
- RPC `get_public_driver_profile()` protegida por `authenticated`.
- Fluxo de corrida v34 preservado.

## Banco
Execute `v35-driver-public-profile.sql` depois das migrações anteriores.

## Pagamentos
A v34 continua responsável pelo gateway. Credenciais de pagamento permanecem nas Edge Functions e não devem ser colocadas no frontend.

## Observação
Nenhum segredo é necessário para o funcionamento do frontend em modo demonstração. Para pagamentos reais, o provedor externo exige uma conta/credencial própria do operador da plataforma; essa é a única parte que não pode ser criada automaticamente pelo aplicativo.

---

## README-v36.md

# VaiComigo v36 — Credenciamento seguro do motorista

Esta versão adiciona o fluxo documental do motorista:

- CNH e CRLV com upload privado no Supabase Storage;
- validade dos documentos;
- status pendente/aprovado/reprovado/expirado;
- painel administrativo para visualizar e revisar documentos;
- motorista fica offline quando documentação é reprovada ou expira;
- aprovação só libera disponibilidade quando os documentos obrigatórios estiverem aprovados.

## Migração
Execute `v36-driver-documents.sql` depois das migrações anteriores.

Os documentos são armazenados no bucket privado `driver-documents`. O navegador nunca recebe uma URL pública permanente; o administrador recebe uma URL assinada temporária ao clicar em `Ver`.

---

## README-v37.md

# VaiComigo v37 — Central de Operações

A v37 adiciona uma central administrativa operacional sobre a base v36.

## Novidades
- indicadores de SOS abertos, pagamentos pendentes e documentos pendentes;
- lista operacional de motoristas com suspensão/retorno à disponibilidade;
- acompanhamento de corridas recentes e cancelamento administrativo seguro;
- central de ocorrências SOS com estados assumir/encerrar;
- painel de pagamentos recentes;
- RPCs administrativas protegidas por `is_admin()`.

## Migração
Execute `v37-admin-operations.sql` depois das migrações anteriores.

## Observação
A disponibilidade real do motorista continua condicionada à aprovação documental. O painel não expõe documentos privados publicamente.

---

## README-v38.md

# VaiComigo v38 — Integração e endurecimento ponta a ponta

A v38 é uma etapa de integração, não apenas uma nova tela.

## Correções principais
- Papel do usuário e modo do aplicativo são revalidados no Supabase.
- Passageiro, motorista e administrador compartilham um único contexto de conta.
- Motorista só aceita corrida se estiver aprovado e disponível.
- Um motorista não pode assumir duas corridas simultâneas.
- Ao concluir/cancelar uma corrida, o motorista é liberado para nova operação, permanecendo offline até voltar a ficar disponível.
- Novo diagnóstico operacional para o administrador.
- Identificação de corridas solicitadas há mais de 15 minutos, SOS, documentos e pagamentos pendentes.
- Service Worker atualizado para v38.

## Migração
Execute `v38-integration-hardening.sql` depois da v37.

## Fluxo validado na arquitetura
Passageiro → solicitação → motorista → aceite atômico → chegada → início → conclusão/cancelamento → liberação do motorista → pagamento/avaliação → histórico.

---

## README-v39.md

# VaiComigo v39 — Suporte e Atendimento

A v39 integra atendimento ao aplicativo único do passageiro, motorista e administrador.

## Novidades
- Chamados de suporte ligados opcionalmente à corrida ativa.
- Categorias: corrida, pagamento, motorista, segurança, conta, Tour e outros.
- Prioridade normal, alta e urgente.
- Histórico de mensagens.
- Realtime para tickets e mensagens.
- Painel administrativo de atendimento.
- Estados: aberto, em atendimento, aguardando usuário, resolvido e fechado.
- RPCs protegidas por autenticação/admin.

## Banco
Execute `v39-support.sql` depois da v38.

## Observação
O atendimento usa o próprio Supabase. Não exige aplicativo externo.

---

## README-v40-PUSH-GPS.md

# VaiComigo v40 — GPS offline + Web Push

## Arquivos integrados

- `sw.js`: cache PWA, IndexedDB, Background Sync `sync-gps`, Web Push e ações da notificação.
- `js/modules/gps-engine.js`: `watchPosition`, filtro de ruído/saltos, buffer IndexedDB e RPC `update_driver_location`.
- `js/modules/driver.js`: disponibilidade, chamadas, alerta sonoro/vibratório, `accept_ride` e PushSubscription.
- `app.js`: carrega a Edge Function `push-notify` após uma nova corrida e expõe `enableDriverPush()`.
- `index.html`: carrega os módulos ES e adiciona o botão de ativação de alertas.
- `supabase/functions/push-notify/`: emissor Web Push com VAPID.

## Configuração VAPID

Gere um par de chaves VAPID fora do repositório e configure no projeto Supabase:

```bash
npx web-push generate-vapid-keys

supabase secrets set \
  VAPID_PUBLIC_KEY="SUA_CHAVE_PUBLICA" \
  VAPID_PRIVATE_KEY="SUA_CHAVE_PRIVADA" \
  VAPID_SUBJECT="mailto:seu-email@dominio.com"
```

A chave **pública** deve estar disponível no frontend. Pode ser colocada no `index.html`:

```html
<meta name="vai-vapid-public-key" content="SUA_CHAVE_PUBLICA">
```

A chave privada nunca deve ir para o frontend, Git ou banco.

## Deploy

```bash
supabase functions deploy push-notify
```

O arquivo `supabase/functions/push-notify/config.toml` mantém `verify_jwt = true`.

## Fluxo de uma nova corrida

1. O passageiro chama `create_ride_quote`.
2. O app recebe o `ride.id`.
3. O app chama `push-notify` com `action=ride_request`.
4. A Edge Function valida que o usuário autenticado é o passageiro da corrida.
5. A função encontra motoristas com `drivers.status = available`.
6. Ela envia Web Push para as subscriptions desses motoristas.
7. O Service Worker mostra "Aceitar corrida" e "Recusar".
8. Ao tocar em "Aceitar", o app executa `accept_ride`, que continua sendo atômico no banco.

## Limitação intencional

O banco v24 atualiza a posição corrente em `drivers`; não existe tabela histórica de pontos. O IndexedDB garante retenção local durante quedas de rede e os pontos são reenviados em ordem cronológica, mas o servidor conserva a última posição recebida.

O push da nova corrida é disparado pelo cliente do passageiro depois da criação da corrida. Para tornar esse disparo 100% independente do navegador do passageiro, a mesma Edge Function pode ser ligada posteriormente a um Database Webhook/integração server-side para o evento `INSERT` em `rides`.

## v41 — endurecimento de produção

Foi adicionada a migration `v41-production-hardening.sql`.

### 1. Histórico de GPS

A tabela `driver_location_history` passa a registrar cada ponto enviado pelo `update_driver_location`, preservando a trilha mesmo quando o dispositivo precisou usar o buffer offline. A função `cleanup_driver_location_history(30)` pode ser executada por `service_role` para retenção de 30 dias (ou outro período).

### 2. Push geográfico

A função `push_ride_candidates` seleciona apenas motoristas:

- com `status = available`;
- com latitude/longitude válidas;
- com GPS atualizado nos últimos 180 segundos;
- a até 10 km da origem da corrida.

Os limites podem ser alterados diretamente no `push-notify/index.ts`.

### 3. Disparo server-side

A criação de uma corrida `requested` alimenta automaticamente `ride_push_queue` por trigger no banco. Para tornar o disparo independente do navegador do passageiro, configure um **Database Webhook** no Supabase:

- tabela: `public.ride_push_queue`
- evento: `INSERT`
- método: `POST`
- URL: `https://SEU-PROJETO.supabase.co/functions/v1/push-notify`
- header `Authorization`: `Bearer SEU_SERVICE_ROLE_KEY`
- header `Content-Type`: `application/json`
- body: `{"action":"process_ride_queue","ride_id":"{{$1.ride_id}}"}`

Use o editor de Database Webhooks do seu projeto para criar o webhook. A chave `service_role` deve ficar somente no servidor/configuração segura do Supabase e nunca no frontend, Git ou `index.html`.

A função também mantém o caminho antigo `ride_request`, então o app atual continua funcionando como fallback enquanto o webhook é configurado. O registro da fila impede o mesmo ride de ser processado duas vezes depois de concluído.

### 4. Ordem de aplicação

Aplique `v41-production-hardening.sql` **depois** das migrations existentes (em especial v21, v24 e v40), faça o deploy da função e então configure o Database Webhook.

```bash
supabase functions deploy push-notify
```

Não é necessário colocar a chave privada VAPID no frontend.

---

## README-v40.md

# VaiComigo v40 — Notificações

Esta versão adiciona um centro de notificações integrado ao PWA.

## Eventos
- mudanças de status da corrida;
- pagamentos confirmados, falhos ou cancelados;
- respostas do suporte;
- contador de não lidas;
- marcar uma/todas como lidas;
- preferência de notificações no aparelho;
- Supabase Realtime para receber notificações enquanto o app está aberto.

## Banco
Execute `v40-notifications.sql` depois da v39.

## Observação sobre push em segundo plano
O PWA pede a permissão do navegador e está preparado para notificações locais. Para **push real quando o aplicativo estiver fechado**, ainda é necessária uma chave pública/privada VAPID e uma Edge Function de envio. Essa credencial não deve ser colocada no frontend.

---

## README-v41.md

# VaiComigo v41 — endurecimento de produção

Esta versão estende a integração v40 com:

- histórico persistente de posições GPS;
- candidatos de push filtrados por distância e frescor do GPS;
- fila criada por trigger no banco quando uma corrida é criada;
- processamento server-side via Supabase Database Webhook, com contrato compatível com `record.id`;
- fallback client-side já existente enquanto o webhook não estiver configurado.

Arquivos principais:

- `v41-production-hardening.sql`
- `supabase/functions/push-notify/index.ts`
- `README-v40-PUSH-GPS.md`

Antes de produção, aplique a migration, configure as secrets VAPID e configure o Database Webhook conforme a documentação.


## v42 — segurança e idempotência do push

- A fila usa lock temporário para impedir dois workers de enviarem a mesma corrida simultaneamente.
- Uma corrida só é marcada como processada depois que pelo menos um push é entregue.
- Inscrições 404/410 são removidas automaticamente.
- O Edge Function aceita o formato nativo do Database Webhook (`record.id`).
- Para webhook sem JWT, configure o secret `VAI_WEBHOOK_SECRET` e envie o mesmo valor no header `x-vai-webhook-secret`.
- O cliente continua podendo chamar `action=ride_request` como fallback.

### Webhook

Configure o Database Webhook para `INSERT` em `public.ride_push_queue`, URL:
`https://SEU-PROJETO.supabase.co/functions/v1/push-notify`

Header recomendado:
`x-vai-webhook-secret: <mesmo valor de VAI_WEBHOOK_SECRET>`

Secret:
```bash
supabase secrets set VAI_WEBHOOK_SECRET="um-segredo-longo-e-aleatorio"
```

> **Importante:** `supabase/functions/push-notify/config.toml` usa `verify_jwt = false` de propósito. A própria função valida JWT para chamadas normais e exige `x-vai-webhook-secret` para o Database Webhook. Nunca deixe o endpoint do webhook sem esse secret.

---

## README-v43.md

# VaiComigo v43 — retry confiável de despacho

A v43 não repete as implementações de GPS/push da v40-v42. Ela corrige o ponto restante do fluxo: uma corrida pode nascer quando nenhum motorista elegível está online ou com GPS recente.

## O que mudou

- `ride_push_queue` agora possui `next_attempt_at` e `max_attempts`.
- Falhas usam backoff progressivo (até 5 minutos entre tentativas).
- O worker consulta somente itens realmente prontos através de `pending_ride_pushes()`.
- O `push-notify` continua idempotente via `claim_ride_push()`.
- Após 20 tentativas sem entrega, a fila para e preserva `last_error` para diagnóstico.
- Nada muda no fluxo de aceite atômico da corrida.

## Aplicação

1. Execute `v43-reliable-push-retry.sql` depois da v41/v42.
2. Deploy:

```bash
supabase functions deploy push-notify
```

3. O Database Webhook da v42 continua apontando `INSERT` de `ride_push_queue` para `push-notify`. Isso dispara a primeira tentativa imediatamente.

## Retry periódico (recomendado)

Para o retry continuar mesmo sem novos eventos, configure um job periódico do Supabase para chamar:

```text
POST https://SEU-PROJETO.supabase.co/functions/v1/push-notify
x-vai-webhook-secret: SEU_VAI_WEBHOOK_SECRET
Content-Type: application/json

{}
```

O job pode rodar a cada minuto. A função só processa itens retornados por `pending_ride_pushes()`.

### Importante

Não coloque `VAI_WEBHOOK_SECRET`, `SUPABASE_SERVICE_ROLE_KEY` ou a chave privada VAPID no frontend. Para um job agendado, armazene o secret no mecanismo seguro de secrets/Vault do Supabase.

## Validação

A base JavaScript continua a mesma da v42; esta versão altera somente a fila/retry e o worker server-side.

---

## README-v44.md

# VaiComigo v44 — webhook de pagamento autenticado

Base: v43. Esta versão altera somente a segurança do webhook do Mercado Pago.

## Correção
`supabase/functions/mp-webhook/index.ts` agora exige a assinatura `x-signature` do Mercado Pago e o `x-request-id`.

A assinatura é validada com HMAC-SHA256 usando o segredo configurado em `MP_WEBHOOK_SECRET`, sobre o manifesto:

`id:{data.id};request-id:{x-request-id};ts:{ts};`

Também há janela anti-replay de 5 minutos.

## Secret
Configure no Supabase:

```bash
supabase secrets set MP_WEBHOOK_SECRET="SEU_WEBHOOK_SECRET"
```

Mantenha também `MP_ACCESS_TOKEN`, `SUPABASE_URL` e `SUPABASE_SERVICE_ROLE_KEY` configurados.

## Deploy

```bash
supabase functions deploy mp-webhook
```

Depois configure no Mercado Pago a URL da Edge Function:

`https://SEU-PROJETO.supabase.co/functions/v1/mp-webhook`

Não coloque `MP_WEBHOOK_SECRET` no frontend.

---

## README-v45.md

# VaiComigo v45 — Payment State Hardening

## Objetivo

A v45 não refaz GPS, Push, retry ou assinatura do Mercado Pago. Ela corrige apenas uma regressão possível no estado financeiro.

## Correção

`sync_external_payment()` agora trata `paid` como estado terminal. Um webhook atrasado/repetido com `pending` ou `failed` não consegue rebaixar uma transação já liquidada.

Também evita que um evento antigo `pending` reabra uma transação que já esteja `failed`.

## Aplicação

Execute após as migrações anteriores:

```bash
supabase db push
```

ou aplique `v45-payment-state-hardening.sql` no SQL Editor.

## Validação

A função continua disponível exclusivamente para `service_role`; o navegador não pode chamar `sync_external_payment`.

---

## README-v46.md

# VaiComigo v46 — Laboratório E2E de teste

A v46 adiciona um laboratório de teste isolado para validar o fluxo completo usando duas contas e dois celulares, sem exigir análise documental real.

## 1. Aplicar a migração

No Supabase SQL Editor, execute:

```sql
-- v46-test-lab.sql
```

O modo de teste começa **desligado**.

## 2. Preparar uma conta administradora

A conta administradora existente continua sendo usada. Se ainda não houver uma:

```sql
update public.profiles
set role='admin'
where id='UUID-DA-CONTA-ADMIN';
```

## 3. Ligar o laboratório

Entre como administrador → Perfil/Admin → **Laboratório E2E** → **Ligar laboratório**.

Isso é deliberadamente uma ação administrativa. Não deixe o laboratório ligado em uma instalação pública.

## 4. Criar as duas contas

### Celular A — passageira

Crie uma conta normal pelo botão **Criar conta**.

Exemplo:

```text
esposa.teste@exemplo.com
```

Não precisa ser motorista.

### Celular B — motorista

Crie outra conta normal:

```text
motorista.teste@exemplo.com
```

Depois de entrar, no Perfil aparecerá:

> 🧪 Ambiente de teste ativo
> 
> Preparar esta conta como motorista de teste

Pressione o botão. A conta ganha um cadastro de motorista com dados de teste e `document_status='approved'` automaticamente.

## 5. Fazer o teste real com dois celulares

### Motorista

1. Abra Perfil → Motorista.
2. Ative **Ficar disponível**.
3. Permita GPS.
4. Ative **alertas de corrida**.
5. Deixe o celular parado próximo ao local da origem da corrida.

### Passageira

1. Abra o mapa.
2. Defina a origem.
3. Informe o destino.
4. Escolha um método de teste, preferencialmente `cash` para não envolver cobrança real.
5. Solicite a corrida.

### Resultado esperado

```text
PASSAGEIRA
Criar corrida
    ↓
rides.status = requested
    ↓
fila de push
    ↓
MOTORISTA
recebe oferta
    ↓
Aceitar
    ↓
accepted
    ↓
arriving
    ↓
in_progress
    ↓
completed
```

O aceite continua protegido pela função atômica existente; o laboratório não cria um caminho alternativo de aceite.

## 6. Diagnóstico

A função disponível para o diagnóstico é:

```sql
select public.test_e2e_status('UUID-DA-CORRIDA');
```

Ela informa:

- modo de teste;
- usuário autenticado;
- status da corrida;
- motorista associado;
- status de pagamento;
- se a corrida foi marcada como teste;
- horário do servidor.

## 7. Segurança do laboratório

O modo de teste é global e deve ficar desligado fora de um ambiente controlado.

Quando ligado:

- usuários autenticados podem preparar a própria conta como motorista de teste;
- a aprovação documental é automática apenas para esse cadastro de teste;
- novas corridas são marcadas com `test_run=true`;
- o fluxo normal de `accept_ride` e `update_ride_status` continua sendo utilizado.

O laboratório não altera a política real de aprovação quando está desligado.

## 8. E-mail de confirmação

Para um teste rápido em um **projeto Supabase separado de testes**, pode ser conveniente desativar a confirmação obrigatória de e-mail nas configurações de Auth. Não faça isso no projeto de produção.

## 9. Próxima validação

Depois de executar o primeiro cenário de dois celulares, o próximo trabalho deve ser baseado nos erros concretamente observados no teste. Não adicionar novas funcionalidades antes disso.


## Correção de configuração do cliente

Passageiros e motoristas **não conectam o Supabase**. O administrador configura uma única vez `js/config.js` com a URL pública e a chave `anon` do projeto. Essas informações podem ficar no frontend; nunca use `service_role` ali. O botão de conexão foi removido da experiência normal.

---

## README-REV48.md

# VaiComigo — revisão 48 (24/09/2026)

## Mudanças já aplicadas ao projeto Supabase conectado

O conteúdo de `v48-security-fare.sql` foi executado no banco real. O projeto não registra migrações no histórico do Supabase porque as versões anteriores também foram executadas diretamente no SQL Editor. Guarde este arquivo junto com o código e, em novos ambientes, aplique-o após v47.

- `profiles.role` não pode ser inserido ou alterado por usuários autenticados; continuam liberados cadastro de `id`, `full_name`, `phone` e edição de nome/telefone.
- RPCs `SECURITY DEFINER` não aceitam chamadas anônimas, com exceção intencional do compartilhamento de viagem por token. RPCs de gatilho e serviço não aceitam chamadas de passageiros/motoristas.
- `complete_ride` ignora o valor final enviado pelo motorista e usa a tarifa existente no servidor; mantém o argumento antigo por compatibilidade.
- `create_ride_quote` antiga não é mais executável por usuários: o app da revisão 48 usa `create_ride_with_destination`, que registra coordenadas do destino e recusa rotas incompatíveis com a distância em linha reta.
- Reservas de Tour ganharam `route_code` e `itinerary`, faltantes no esquema real. O passageiro só pode alterar o status diretamente e um gatilho aceita exclusivamente cancelamento de uma reserva solicitada. Inserções exigem preço correspondente à duração escolhida.

## Mudanças no aplicativo

- GPS sem sinal/permissão não é substituído silenciosamente por uma localização falsa.
- Busca oferece sugestões locais para lugares conhecidos; pesquisa externa ocorre só após tocar em calcular. Vários resultados exigem escolha explícita.
- O preço exibido após solicitar corrida é o retornado pelo Supabase.
- Coordenadas de destino são enviadas à criação da corrida e usadas pelo botão de navegação do motorista durante a viagem.
- Pix e cartão aparecem desativados até a ativação do provedor; dinheiro é o padrão. A configuração gerada no build também mantém pagamentos online desligados.
- O service worker não devolve a página inicial para requisições de mapas, scripts externos e outras APIs quando estiver offline.
- Corrigidos pontos de interpolação de texto de destino sem escape em cartões de chamada e compartilhamento.

## Pendências para operar com passageiros

1. Publicar **este ZIP** junto com o banco já atualizado. Uma versão antiga implantada ainda chama a RPC anterior, agora bloqueada.
2. Fazer teste real de ponta a ponta com passageiro e motorista, incluindo atualização de status, Realtime, GPS, retorno de tarifa, Tour e dinheiro. O banco ainda não tinha usuários nem corridas no momento desta revisão.
3. Contratar/configurar busca de lugares com licença e capacidade de autocomplete para produção. O Nominatim público não permite autocomplete e não oferece a cobertura/escala esperada; a lista local tem somente três locais já presentes no código. Testar expressões como “Castelo” e “Rodoviária do Bingen” com dados reais antes de liberar.
4. Mover cálculo e verificação da rota/tarifa para um serviço confiável no servidor. A nova RPC confere plausibilidade, mas ainda recebe distância e duração calculadas no cliente.
5. Implantar e configurar Edge Functions e segredos de pagamento/push antes de habilitar Pix, cartão ou alertas remotos. Nenhuma Edge Function estava implantada no projeto conectado.
6. Revisar o fluxo de administrador inicial e políticas dos demais módulos, monitoramento, políticas de retenção de GPS, custos/limites de mapas e operação do SOS antes de escala comercial.

## Verificações efetuadas

`node --check` passou para JavaScript da aplicação; consultas ao banco confirmaram zero RPCs privilegiadas anônimas (exceto link por token), `profiles.role` protegido e RPC nova disponível. O teste E2E simulado do ZIP requer Playwright, indisponível neste ambiente. Nenhum teste com conta real ou aparelhos foi executado.

---

## README-REV49-BUSCA-LOCAL.md

# VaiComigo v49 — busca por lugares da região

Esta revisão é **busca por locais conhecidos**, não uma lista de endereços formais. O catálogo pode ser ampliado em `js/local-places.js` sem alterar a tela principal.

## Exemplos

- `castelo` ou `castélo` → Castelo de Itaipava, Itaipava (sugestão principal).
- `rodoviaria` ou `terminal` → Rodoviária do Bingen primeiro e Rodoviária do Centro depois.
- `terminal bingen` → Bingen; `rodoviária centro` → Centro.
- Incluídos Museu Imperial, Catedral, Palácio Quitandinha, Palácio de Cristal e Casa de Santos Dumont.

As sugestões locais aparecem ao digitar, mesmo sem consultar um serviço de mapas. A busca externa acontece **somente após seleção ou pedido de rota**. Coordenadas do Castelo são baseadas no OpenStreetMap; para os terminais, informações geográficas públicas conflitavam entre si, então não há ponto fixo inventado. Ao selecionar terminal, o app tenta resolver um resultado de Petrópolis; se não confirmar o local, não calcula corrida. Cada resultado externo é filtrado por município e limites da região, exigindo escolha explícita caso haja mais de uma opção.

## Limites e próximos passos

- A busca externa ainda usa o Nominatim público. Ele não deve receber consultas a cada tecla nem ser a base de operação comercial em escala. Integrar provedor contratado de lugares para cobertura e confiabilidade, com segredo no servidor e observabilidade.
- Confirmar posição exata da entrada/embarque de Bingen e Centro com validação local antes de fixar coordenadas no catálogo. Em algumas bases comerciais, a coordenada indicada para Bingen diverge vários quilômetros de uma fotografia georreferenciada do terminal; não usá-la para calcular tarifa.
- Validar os nomes e a experiência da busca em celulares e percorrer as rotas efetivas. Testes automatizados de relevância e filtro geográfico: `node tests/local-places.test.cjs`.

Fontes consultadas: site do Castelo (https://www.castelodeitaipava.com.br/localizacao.asp); dados OSM do Castelo (https://mapcarta.com/pt/W1002709356); plano de turismo da Câmara de Petrópolis (https://sapl.petropolis.rj.leg.br/media/sapl/public/documentoacessorio/2023/15837/anexo_-_plano_diretor_turismo.pdf); política do Nominatim (https://operations.osmfoundation.org/policies/nominatim/).

---

## README-REV55-BUSCA-CIDADE.md

# Busca da cidade — revisão 55

A sugestão de destinos agora consulta um índice geográfico real enquanto o usuário digita. O catálogo local continua apenas para nomes regionais conhecidos. Rua, bairro, estabelecimento e número não dependem de cadastrar exemplos no código.

- Pesquisa incremental após três caracteres, espera de 380 ms, cancelamento de pedidos antigos, cache curto e filtro pelo município de Petrópolis.
- Consulta ao Photon por texto digitado, com viés geográfico e delimitação; sem uso do Nominatim público para autocomplete.
- O usuário escolhe o resultado antes da rota. Se o número da casa não aparecer no índice, o app pede para marcar a entrada no mapa em vez de assumir o centro da rua.
- O botão “Marque o ponto no mapa” permite indicar um destino ausente da base. A cobertura real depende da qualidade e atualização do provedor.

**Operação:** a URL padrão `https://photon.komoot.io/api/` é uma instância de demonstração, sujeita a limites e indisponibilidade. Para lançar na cidade inteira, substitua por instância Photon própria ou serviço comercial compatível com a API `/api` e GeoJSON. Defina `window.VAI_GEOCODER_URL` antes de carregar `js/city-search.js`, por exemplo em `js/config.js`. Não publique chaves privadas no JavaScript do navegador: se usar fornecedor com chave secreta, faça o acesso por função no servidor com limites, cache e observabilidade.

**Validação:** `node tests/local-places.test.cjs` e `node tests/city-search.test.cjs`. Testes de integração no celular devem confirmar cobertura de várias ruas e bairros reais, números de casas, internet lenta, queda do serviço e rotas.

---

## README-REV56-MAPA.md

# Mapa vetorial — revisão 56

A tela principal e o mapa de acompanhamento agora usam o estilo vetorial `bright` do OpenFreeMap via MapLibre, integrado ao Leaflet para preservar a lógica existente de rotas, marcadores e GPS. Nas telas sem WebGL ou se a biblioteca não carregar, o mapa raster anterior permanece como contingência.

Melhorias de interação: mapa maior, ferramentas de localização e expansão, marcador de destino próprio, GPS contrastante e linha de rota legível. O modo expandido conserva o botão para fechar e recalcula o tamanho do mapa.

Corrigido também o estado `selectedDestination`, `routeQuote` e `routeLine`, que era usado sem declaração inicial; isso podia causar erros na busca e no cálculo. `window.map` foi exposto para o roteiro turístico que já tentava acessá-lo.

Estilo personalizável por `window.VAI_MAP_STYLE_URL` antes do carregamento de `app.js`. Tiles são um serviço externo e exigem conexão; a qualidade de rótulos/ruas depende do mapeamento OpenStreetMap. Para uma experiência comparável às plataformas maiores, ainda é necessária validação visual em aparelhos Android de diferentes capacidades e testes de navegação em movimento. A integração Leaflet + MapLibre não fornece inclinação ou rotação da câmera.

---

## README-REV57-NOTIFICACOES.md

# Revisão 57 — barra inferior e notificações

A barra inferior usa distribuição flexível: as abas que não pertencem à conta não deixam colunas vazias. O sino virou a aba “Alertas” fixa na barra; sua lista abre acima dela, com contador de não lidas.

Na primeira abertura compatível com HTTPS e notificações, aparece um convite de ativação. O usuário pode adiar por sete dias; a permissão do sistema só é solicitada no toque de “Ativar alertas”, como exigem os navegadores. Permissão não é assinatura Web Push: o app só apresenta alertas em segundo plano como ativos quando a chave VAPID existe, a conta está conectada e `push_subscriptions` recebeu a inscrição com êxito. A opção da central permite desativar.

**Atualização REV58:** a chave VAPID pública está configurada e a função de envio, o disparo da fila e a retentativa foram implantados no Supabase. Cada aparelho ainda precisa abrir a versão atualizada do aplicativo e ativar as notificações para registrar sua própria inscrição.

Verificar em Android HTTPS: barra com passageiro (4 abas), motorista autorizado, admin; abertura do convite, aceitar, negar e adiar; assinatura vinculada ao usuário e recebimento real de uma notificação com tela bloqueada após configurar Web Push.

---

## README-REV58-PUSH-ATIVO.md

# REV58 — Notificações com o app fechado

A chave VAPID pública está no aplicativo. A chave privada e o segredo do disparador estão no Vault do projeto Supabase, acessíveis somente ao serviço. A Edge Function `push-notify` foi implantada, com disparo ao entrar na fila e retentativa automática a cada minuto. O service worker foi atualizado para esta revisão.

Para receber alertas, instale ou atualize esta versão no endereço HTTPS do aplicativo. Em cada aparelho, entre na conta e toque em **Ativar alertas** quando aparecer o convite. O navegador solicitará permissão e registrará a assinatura do aparelho. A permissão precisa ser concedida separadamente em cada aparelho.

Verificação no servidor: o diagnóstico de `push-notify` retornou HTTP 200 com `ready: true`, e a chamada da fila agendada retornou HTTP 200. Ainda é necessário testar a entrega real após cadastrar um aparelho; não havia assinaturas registradas no projeto durante esta revisão.

---

## README-REV60-EMBARQUE.md

# REV60 — Ponto de encontro e busca local

O passageiro pode ajustar a partida tocando em **Ajustar ponto de encontro**, marcar a entrada no mapa e conferir o marcador antes de solicitar a corrida. **Usar meu GPS novamente** desfaz o ajuste. Toda mudança no ponto de encontro invalida a estimativa anterior; é necessário consultar a rota novamente.

Se o GPS relatar precisão pior que 100 metros, a estimativa aconselha ajustar o ponto no mapa. A busca do catálogo local reconhece um pequeno erro de digitação em palavras de cinco letras ou mais.

Verificações locais: sintaxe JavaScript, testes de busca local e busca da cidade. Falta validar o percurso completo com dois aparelhos e atualizar o site HTTPS com este pacote. A busca e o cálculo de rotas ainda dependem dos serviços externos configurados no projeto; esta revisão não os substitui.

---

## README-REV64-CONFIABILIDADE.md

# REV64 — Confiabilidade da solicitação

Ao alterar destino ou partida durante um cálculo, respostas antigas da busca e da rota deixam de atualizar a estimativa e o botão de solicitar. A seleção no mapa mantém apenas uma ação pendente por vez. O botão fixo de solicitar não aparece enquanto o campo de destino está em foco.

Se a solicitação falhar sem confirmação do servidor, o aplicativo orienta verificar **Minhas viagens** antes de repetir o pedido. Isso reduz o risco de solicitar uma segunda corrida quando a primeira foi registrada, mas a resposta se perdeu por falha de conexão. Falhas conhecidas do servidor mostram a mensagem recebida e permitem nova tentativa.

O erro de GPS distingue permissão negada e tempo esgotado, sugerindo marcar o ponto de embarque no mapa. Verificações locais: sintaxe JavaScript, busca local, busca da cidade e integridade do CSS. Ainda é necessário testar pedidos reais com dois aparelhos e publicar o pacote atualizado no site HTTPS.

---

## README-REV65-RECENTES.md

# REV65 — Destinos recentes

Ao tocar no campo de destino vazio, o VaiComigo mostra até cinco lugares escolhidos anteriormente neste navegador. A lista fica somente no armazenamento local do aparelho; não é sincronizada com a conta. O botão **Limpar** remove todos os recentes deste navegador.

Coordenadas fora da área atendida não são guardadas. Repetir um destino move o lugar para o topo sem duplicá-lo. Escolher um recente restaura o marcador e calcula a rota novamente, usando o ponto de embarque atual.

Validado localmente com testes de persistência, deduplicação, limite, área, limpeza e as buscas existentes. A apresentação e o comportamento do teclado devem ser conferidos no celular após publicar a revisão.

---

## README-DEPLOY.md

# VaiComigo — deploy e teste real

Este pacote já está com o código preparado para o teste ponta a ponta. O único dado que não pode ser preenchido automaticamente neste arquivo é a conexão com o projeto Supabase real.

## O que já está pronto
- Cadastro/login sem pedir URL ou chave do Supabase ao usuário.
- Configuração interna em `js/config.js`.
- Laboratório E2E separado do ambiente normal.
- Aprovação automática de motorista somente quando o modo de teste está explicitamente ligado no banco.
- Diagnóstico E2E para passageiro e motorista.
- Corrida, aceite, GPS, estados e pagamento em dinheiro para o teste.
- Push/GPS e fila de despacho mantidos.
- RPCs internas com permissões endurecidas.
- Nenhuma chave `service_role`, `sb_secret_*`, VAPID privada ou segredo do Mercado Pago deve ir para o frontend.

## Para publicar no Netlify
No Netlify, em **Site configuration → Environment variables**, defina somente:

- `SUPABASE_URL` = URL do projeto Supabase
- `SUPABASE_ANON_KEY` = chave anon/publicável
- `VAPID_PUBLIC_KEY` = chave pública VAPID, se Web Push for usado
- `VAI_ENVIRONMENT` = `test` somente para o ambiente de teste

O `netlify.toml` executa `scripts/generate-config.mjs` durante o build.

## Para o banco de teste
No SQL Editor do projeto Supabase, aplicar os arquivos SQL em ordem numérica, terminando em:

1. `v46-test-lab.sql`
2. `v47-e2e-support.sql`
3. `v47-rpc-grants-hardening.sql`

Depois, no projeto de teste, ligar o laboratório:

```sql
update public.platform_settings
set test_mode_enabled = true, updated_at = now()
where id = true;
```

Para voltar ao comportamento normal:

```sql
update public.platform_settings
set test_mode_enabled = false, updated_at = now()
where id = true;
```

## Teste com dois celulares
1. Celular da passageira: criar conta e solicitar uma corrida em dinheiro.
2. Celular do motorista: criar conta, preparar/cadastrar motorista de teste, permitir localização e ficar disponível.
3. Aceitar a corrida.
4. Marcar **a caminho → iniciar → finalizar**.
5. Confirmar o recebimento em dinheiro.
6. Abrir **Perfil → Diagnóstico E2E** nos dois celulares para verificar o estado do servidor.

O diagnóstico também pode ser aberto com `?diag=1`.

## Importante
O ZIP não contém credenciais reais do projeto Supabase porque essas credenciais pertencem ao ambiente de implantação. O arquivo `js/config.js` vazio é intencional até a conexão com o projeto real ser feita.

---

## README-E2E.md

# VaiComigo — preparo para teste ponta a ponta (2 celulares)

## 1. Configuração interna (uma vez, pelo responsável técnico)
Preencha **js/config.js** (ou, no Netlify com deploy por Git/CLI, as variáveis `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `VAPID_PUBLIC_KEY`, `VAI_ENVIRONMENT=test`; o build roda `scripts/generate-config.mjs`, que recusa service_role/sb_secret_).
- `supabaseUrl`, `supabaseAnonKey` (anon/publishable), `vapidPublicKey`: **públicos**, podem ir no frontend.
- **Nunca** no frontend: `SUPABASE_SERVICE_ROLE_KEY`, `VAPID_PRIVATE_KEY`, `MP_ACCESS_TOKEN`, `MP_WEBHOOK_SECRET`, senha do banco → *Secrets* das Edge Functions (`supabase secrets set ...`).
- `environment: 'test'` mostra o botão **Diagnóstico E2E** no Perfil (também abre com `?diag=1`).
- Deploy manual (arrastar ZIP no Netlify) não roda build: edite o `js/config.js` antes de compactar.

## 2. Banco (SQL Editor, nesta ordem)
1. Schema base (tabelas `profiles`, `drivers`, `rides`) — **não vem neste ZIP**; precisa já existir.
2. `v12` … `v46` (arquivos `vNN-*.sql`, ordem numérica; v46 = laboratório de teste).
3. `v47-e2e-support.sql` (register_driver, cancel_ride, test_e2e_report).
4. `v47-rpc-grants-hardening.sql` (recomendado; revoga execução por anon/authenticated de RPCs internas).
Auth → desligue **Confirm email** no projeto de teste.

## 3. Ligar/desligar o modo TESTE (padrão: desligado)
```sql
update public.platform_settings set test_mode_enabled = true  where id = true;  -- ligar
update public.platform_settings set test_mode_enabled = false where id = true;  -- desligar
```
Com ele ligado: cadastro de motorista já nasce aprovado e as corridas saem com `test_run=true`. Desligado, a aprovação continua manual (documentos/admin).

## 4. Edge Functions
`supabase functions deploy push-notify create-payment mp-webhook`
Secrets: `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT`, `VAI_WEBHOOK_SECRET` (push); `MP_ACCESS_TOKEN`, `MP_WEBHOOK_SECRET` (pagamento online). Retry automático da fila exige Database Webhook em `ride_push_queue` (header `x-vai-webhook-secret`) ou pg_cron. Para o teste use **pagamento em dinheiro** (não depende do Mercado Pago).

## 5. Roteiro com dois celulares
Celular 1 (passageira): abrir o site → Perfil → Criar conta → solicitar corrida (dinheiro).
Celular 2 (motorista): abrir o site → Criar conta → Perfil → Cadastrar motorista → área do motorista → Ficar disponível (permitir GPS e alertas) → aceitar → a caminho → iniciar → finalizar → confirmar dinheiro.
Em ambos: Perfil → Diagnóstico E2E → escolher o papel → "Atualizar a cada 5 s". Copiar relatório para enviar.
Estados: OK · FALHOU · BLOQUEADO (configuração externa) · PENDENTE (etapa ainda não ocorreu) · N/A.

---

## README-ETAPA-1.md

# VaiComigo — entrega da Etapa 1

O mapa principal usa MapLibre GL nativo, com estilo vetorial, inclinação e câmera animada. Se o estilo vetorial falhar, o mapa tenta tiles raster do OpenStreetMap. Em navegadores sem WebGL o mapa principal e o mapa da viagem compartilhada continuam no Leaflet raster. Edifícios 3D aparecem somente quando o estilo efetivamente inclui dados de altura. A tela inicial mantém o mapa como fundo do fluxo do passageiro; o redesenho das telas e os gestos dos painéis são da Etapa 3.

O GPS automático fornece partida sem botão de confirmação. A busca reversa exibe o nome da rua quando a fonte pública responde; caso contrário, mantém a posição e avisa o usuário. O ponto pode ser escolhido no mapa e arrastado no mapa nativo. Uma mudança da partida invalida a cotação antiga.

`v66-map-gps-realtime.sql` foi aplicado ao Supabase. Ativa PostGIS, cria índice GiST para motoristas disponíveis e índice de corridas ativas. O banco publica coordenadas por `realtime.send` em canal privado `ride-location:<uuid>`, autorizado somente para passageiro e motorista da corrida ativa; a RPC `ride_driver_location` fornece a posição inicial autorizada. Sem conexão, o último pino permanece visível e o app informa quando os dados estão antigos. Os cálculos financeiros e o andamento da corrida continuam sob os contratos atuais.

**Dependências operacionais:** estilo OpenFreeMap, raster OSM e Photon de demonstração não oferecem garantia operacional contratada. A cotação ainda usa o endpoint público OSRM; se ficar indisponível, o aplicativo avisa e permite tentar de novo, sem mostrar tarifa fabricada. Para implantação comercial, contratar hospedagem de tiles e roteamento com SLA (MapTiler/Mapbox/HERE/Valhalla próprio, conforme cobertura e licenças) exige credencial, custo variável de uso e configuração de proxy server-side. Nenhuma chave privada foi colocada no front-end.

**Validação executada:** checagem de sintaxe dos scripts, 3 testes locais de busca/destinos, leitura da extensão PostGIS, índice, política e permissões da RPC no Supabase. A corrida com dois aparelhos e a revisão visual em aparelhos reais ainda não foram testadas.

**Etapa 2:** autocomplete, catálogo enriquecido, favoritos e voz. **Etapa 3:** sistema visual, sheets com gestos e máquina de estados. Nada dessas etapas foi implementado aqui.

---

## README-ETAPA-2.md

# VaiComigo — Etapa 2: busca e endereço

**Entregue:** campos empilhados de partida e destino com marcadores círculo/quadrado; sugestões locais imediatas desde a primeira letra; Edge Function que combina pontos editoriais e Photon, ou HERE Autosuggest quando `HERE_API_KEY` está configurada; nome, endereço, categoria e distância calculada antes do toque; resultados mistos; três opções finais permanentes; pesquisa ampla no Brasil; fallback para marcar no mapa; favoritos e recentes privados sincronizados pela conta; voz nos navegadores que implementam Web Speech. A busca reversa do GPS mantém o comportamento da Etapa 1.

**Correção decisiva:** a instância Photon pública retornava HTTP 400 para `lang=pt`. Removido esse parâmetro tanto da busca como da geocodificação reversa. Consulta real feita pela Edge Function retornou resultados de `castelo`, `centro`, `itaipava`, `rodoviaria`, `bairro` depois da correção.

**Ampliação em 24/09/2026:** a Rodoviária do Bingen agora figura em primeiro lugar na busca real `rodoviaria` (OSM way 256719153, centro da estação: −22,5162932 / −43,2290271). Foram importados 144 bairros e pontos de interesse, além de 1.554 nomes de ruas únicos da área consultada, com proveniência do OpenStreetMap e crédito ODbL na interface. O catálogo totaliza 1.705 registros. O carregamento offline foi paginado para superar o limite de linhas da API REST. A consulta genérica `bairro` agora mostra bairros reais primeiro. Vias sem número trazem o aviso “trecho aproximado da via” e um número digitado precisa de endereço correspondente antes da seleção.

**Aceite ainda pendente:** a amostra real `castelo` ainda não mostrou Pousada Monte Castelo e Castelo Country Club porque esses estabelecimentos não constam da fonte aberta consultada com coordenadas verificadas. Não inventamos sua posição. A busca de endereço exato com número também depende de cobertura que o catálogo de trechos de ruas não fornece. Sem `HERE_API_KEY`, a fonte externa é Photon público, sujeito a cobertura, cotas e latência. Configure `HERE_API_KEY` como secret em **Supabase → Edge Functions → Secrets**, sem colocar chave em `js/config.js`. Avalie o resultado de estabelecimentos ausentes e entradas de embarque no aparelho antes do aceite final. O centro da estação do Bingen não é um ponto de acesso veicular confirmado.

**Custos e contratos:** HERE cobra conforme o plano/uso; o volume cresce com autocomplete a cada letra. Revise preço, quota e licença no painel HERE antes de ativar a chave. Resultados HERE não são persistidos no cache Postgres; somente resultados Photon/OSM ficam até 12 horas. Photon público é serviço de demonstração e pode limitar volume. Postgres, PostGIS, pg_trgm, Edge Functions e leituras de conta consomem cota do plano Supabase. Não há chave privada no navegador.

**Dados:** `v67` adicionou pontos de interesse com categoria, endereço, aliases, GIST e índice trigram, além de favoritos e recentes com RLS por dono. `v68` isolou cache OSM no servidor. `v69` liberou catálogo editorial para exibição imediata/offline. `v70` removeu grants públicos de favoritos e recentes. `v71` adicionou apenas pontos com coordenadas verificadas. `v72–v79` ampliaram terminais, bairros, POIs e vias, paginaram o catálogo e melhoraram a busca de bairros. Todas as migrações foram aplicadas ao projeto conectado. Os dados OSM estão sujeitos à ODbL; preserve a atribuição e analise obrigações de compartilhamento da base derivada antes de sua distribuição externa.

**Validação:** 4 testes locais; checagem de sintaxe JS; RPCs paginadas consultadas no Supabase; requisições HTTP reais para Edge Function (`rodoviaria`, `bairro`, `castelo`, `centro`, `itaipava`, `Rua do Imperador`); resultados `bairro` verificados após o deploy v6. O teste de usabilidade em aparelho e pesquisa HERE real dependem da credencial do provedor.

---

## README-ETAPA-3.md

# VaiComigo — Etapa 3: interface e estados da corrida

## Arquivos alterados e criados

- `index.html`: alternância de tema, alça da folha da busca e carregamento dos módulos visuais.
- `css/vai-stage3.css`: tokens de superfície, texto, contraste, estados, componentes, tema escuro e movimento acessível.
- `js/stage3-ui.js`: tema automático segundo o aparelho, preferência manual persistida, gesto para ampliar o mapa, folhas modais e indicador de carregamento da estimativa.
- `js/ride-state.js`: transições explícitas solicitada → aceita → a caminho → em viagem → concluída/cancelada; progresso e animações conectados aos eventos de corrida persistidos no servidor; restauração após reconexão. A RPC Supabase continua sendo a autoridade para alterar status.
- `sw.js`: versão renovada do cache e inclusão dos novos arquivos para PWA offline.
- `tests/ride-state.test.cjs`: verifica transições aceitas, bloqueio de salto e restauração de estado.

## Validação

`node --test tests/*.test.cjs` passou: cinco arquivos de teste. Arquivos JavaScript alterados passaram em `node --check`. Verificar em aparelhos reais o gesto de arrastar, o contraste do tema escuro, o comportamento com teclado virtual e as atualizações Realtime com motorista e passageiro. A mudança não foi publicada na hospedagem Netlify.

## Pendência prévia

A Etapa 2 continua com lacunas de cobertura documentadas em `README-ETAPA-2.md`. O novo fluxo visual não supre POIs sem coordenadas ou números de imóvel ausentes da fonte de geocodificação.

## Correção após teste em aparelho — v81

O print de produção mostrou o cabeçalho encoberto pelo mapa e a barra de navegação fora da tela. A regra anterior de mapa em tela cheia definia `position:relative` para `nav` quando a home estava ativa; a nova folha alterou a ordem das camadas. `css/vai-stage3.css` fixa a barra inferior, mantém o cabeçalho acima do mapa e deixa a superfície da folha acima do canvas. `js/stage3-ui.js` fecha modais por seus botões normais quando há gesto ou Escape; `js/ride-state.js` deixa a validação de status exclusivamente com a RPC para que dados locais atrasados não impeçam ações. `app.js` mostra falha de mapa sem interromper a inicialização do restante do aplicativo. `sw.js` ganhou versão v81 para renovar o cache no aparelho.

Os cinco testes e as checagens de sintaxe passaram após a correção. O print fornecido é evidência do problema anterior; ainda é necessária verificação visual da versão corrigida no navegador móvel publicado. Se o GPS continuar em “Identificando”, verificar permissão de localização, carregamento das bibliotecas externas do mapa e erros de rede no navegador.
