# Cadastro real e teste com dois aparelhos

## Situação verificada no Supabase

- Gilvan Siess já possui uma conta confirmada. Houve login bem-sucedido com senha. Use **Entrar como motorista → Perfil → Entrar** com o mesmo e-mail e senha. Repetir **Criar conta** para o mesmo e-mail não cria outro cadastro nem resolve o acesso.
- Gilvan é o administrador da operação. No modo Motorista, a aba **Admin** permite analisar CNH e CRLV e aprovar o credenciamento documental. Seu cadastro de motorista continua **pendente** e **offline**: nenhum documento foi enviado nem houve aprovação automática.
- Priscila ainda não possui conta. No segundo aparelho, escolher **Passageiro → Perfil → Criar conta**; usar seu próprio e-mail, nome e senha. Se chegar confirmação por e-mail, abrir o link e voltar ao aplicativo. Cada aparelho mantém sua própria sessão.
- O laboratório de aprovação automática está **desligado**.

## Revisões obrigatórias de e-mail antes do teste

O Supabase registrou o envio de uma confirmação para Gilvan e confirmou aquela conta, mas o painel de SMTP não ficou acessível nesta sessão. O serviço SMTP padrão tem restrições de destinatário e limite de envio; para o cadastro público da Priscila e futuros passageiros configure um provedor SMTP próprio em **Supabase → Authentication → Emails → SMTP Settings**, com remetente, host, porta, usuário e senha do provedor. Esses segredos ficam exclusivamente no Supabase.

Em **Authentication → URL Configuration**, configure como Site URL o domínio definitivo do app e autorize explicitamente o endereço de retorno HTTPS usado no cadastro. O frontend passou a enviar `emailRedirectTo` para o endereço atual da página. Uma URL não autorizada pode fazer o link voltar ao endereço padrão `localhost` do projeto. Não inclua chaves privadas no frontend nem no ZIP.

## Sequência do teste

1. Publicar este ZIP e confirmar que os dois aparelhos carregam a mesma versão.
2. Entrar como motorista no aparelho de Gilvan com a **conta existente**. Em **Central do motorista**, verificar o cadastro e enviar CNH e CRLV.
3. No painel **Admin**, abrir **Documentos**, examinar os dois arquivos e aprovar cada um. O motorista só é liberado depois que os dois documentos válidos forem aprovados. Atualizar a Central do motorista e ficar disponível.
4. Priscila cria e confirma sua conta no outro aparelho. Abre **Passageiro**, consulta rota e valor e solicita uma corrida próxima do motorista.
5. Gilvan recebe a chamada, aceita, inicia, acompanha pelo GPS e conclui. Priscila verifica o acompanhamento e a conclusão.
6. Usar **dinheiro** para conferir o fluxo de pagamento. Pix e cartão permanecem desativados em `js/config.js` até conectar um provedor real; nenhum pagamento eletrônico será cobrado neste teste.

Sem SMTP configurado e sem a Priscila concluir o cadastro, não há como afirmar que o percurso entre aparelhos foi validado. Os testes automatizados locais cobrem componentes, mas não substituem a execução conjunta nos celulares.
