# Navegação VaiComigo

O motorista pode abrir **Iniciar navegação VaiComigo** após aceitar uma corrida. A rota mostra a próxima manobra, distância, ETA e alertas por voz quando o navegador permitir. Durante a viagem, **Navegar até o destino** calcula a rota para o destino da corrida. O passageiro usa **Acompanhar motorista** para seguir o carro no mapa.

## Trânsito real

A função `navigation-route` está publicada no projeto Supabase conectado com verificação de JWT. Para ativar o provedor, configure `MAPBOX_ACCESS_TOKEN` nos **Secrets das Edge Functions** do projeto. O token não deve ser salvo no ZIP, no `js/config.js` ou enviado ao navegador.

Quando o provedor responde com cobertura de congestionamento, o app usa sua rota e pinta os trechos congestionados. Sem credencial, sem cobertura ou em caso de falha, usa a rota OSRM e indica que não há trânsito ao vivo. As chamadas à API Directions da Mapbox são cobradas conforme o volume de solicitações e o plano contratado; confirme limites e faturamento em https://www.mapbox.com/pricing antes de ativar em produção.

## Validação obrigatória para uso em rua

- Verificar GPS, atualização do passageiro e orientação do motorista em dois aparelhos reais.
- Testar curvas, trevos, túneis, vias sem sinal, perda de rede e segundo plano no Android.
- Conferir a cobertura local e as restrições viárias antes de depender exclusivamente das instruções do PWA. O botão **Abrir navegação** existente mantém a saída para um navegador externo.

O PWA não oferece as mesmas garantias de localização em segundo plano e integração com o sistema operacional de um app nativo. A navegação não deve ser considerada equivalente ao Waze sem esses testes e uma estratégia nativa para o motorista.
