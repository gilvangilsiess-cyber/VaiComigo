# VaiComigo — PWA

Aplicativo de mobilidade de Petrópolis com funções de passageiro, motorista e administração.

## Executar localmente

Sirva a pasta do projeto por HTTP, por exemplo `python3 -m http.server 8765`, e abra `http://localhost:8765/`. Configuração pública do ambiente em `js/config.js`; credenciais privadas pertencem exclusivamente ao servidor/Supabase. O acesso a GPS, service worker e notificações exige origem segura ou localhost.

## Testes

- `npm test`: testes Node de busca, recentes, estados, inicialização dos scripts e precache. Não instala dependências.
- `npm run test:e2e-mock`: simulação no Chromium; requer Python `playwright` e Chromium instalados (`python3 -m pip install playwright` e `python3 -m playwright install chromium`). O relatório vai para `tests/e2e-mock/result.txt`. Simula backend: não valida produção, RLS, Realtime ou geolocalização em celulares reais.
- Antes de publicar, testar no navegador, em celulares e desktop, os fluxos passageiro/motorista/admin contra o ambiente apropriado. Estes fluxos não foram certificados somente pelos testes Node.

O aplicativo usa MapLibre GL no mapa principal e um adaptador de primitivas Leaflet para os fluxos existentes; as duas bibliotecas permanecem necessárias. A aparência está em `css/vai-design.css`; `css/vai-map.css` e `css/vai-search.css` contêm regras específicas de layout. Documentação histórica está em `CHANGELOG.md`; estado verificado do banco e limites da consolidação em `SCHEMA-AUDIT.md`.
