# Estado do schema verificado no Supabase

Consulta somente leitura realizada em 24/09/2026 no projeto configurado para VaiComigo.

- `public`: 21 tabelas visíveis via `information_schema.columns` (incluindo `rides`, `drivers`, `tour_bookings`, `ride_pois`, `saved_places` e `place_search_cache`).
- `ride_pois`: 8 linhas editoriais, 65 nós OSM, 1.632 vias OSM, total 1.705 linhas.
- Histórico `supabase_migrations.schema_migrations`: `v74_osm_petropolis_ruas`, `v75_osm_petropolis_ruas`, `v76_osm_petropolis_ruas` e `v77_osm_petropolis_ruas` aplicadas em quatro versões distintas (`20260924110129`, `20260924110141`, `20260924110152`, `20260924110204`). Os quatro scripts locais têm checksums diferentes; nenhum foi excluído.

**BLOQUEADO: `schema.sql` executável consolidado.** Neste ambiente não existe `supabase` CLI/`pg_dump` com acesso de exportação. Listagem de tabelas não fornece funções, políticas RLS, triggers, índices, grants, extensões e dependências na ordem necessária para um dump fiel. Não foi criado um esquema aproximado nem alterado o banco de produção. Para produzir esse arquivo, exportar o schema real usando uma conexão de leitura autorizada com `supabase db dump --schema public --file schema.sql` (ou `pg_dump --schema-only` com extensões e schemas dependentes) e comparar com as migrações preservadas antes de considerar o resultado reinstalável.
