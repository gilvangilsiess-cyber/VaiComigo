# Reconstrução visual — acompanhamento

## Entrega 1: base visual (neste ZIP)

- Folha `css/vai-design.css` reescrita com uma única origem de tokens e componentes.
- Folhas `css/vai-map.css` e `css/vai-search.css` preservam layout e usam os tokens comuns.
- Fundos grafite, texto claro e detalhes dourados nos estados de tema; cabeçalho, cards, navegação, busca, modais, notificações, motorista e administração usam a mesma base.
- IDs, eventos e contratos de dados permanecem nos arquivos existentes. A ação de solicitar corrida permanece fixa quando há orçamento pronto.
- Cache do service worker atualizado; cores da barra do navegador e da instalação PWA alinhadas ao fundo.

**Verificação feita:** oito testes Node, análise sintática das três folhas CSS, correspondência das classes HTML com o CSS anterior e contraste calculado dos tokens principais. **Verificação pendente:** conferir renderização e interações em navegador mobile/desktop. O navegador disponível neste ambiente recusou o servidor local; a disponibilidade dos tiles do mapa também depende da conexão externa.

## Entrega 2: home e mapa (neste ZIP)

- Cabeçalho da home compacto; partida, destino, estimativa e mensagens ficam próximos e antes do mapa.
- Botão de solicitar continua fixo após uma estimativa válida; a consulta deixa de rolar a tela para longe da estimativa.
- Estados de mapa carregando/pronto/indisponível e GPS disponível/sem permissão; controles de seleção manual desabilitados quando o mapa falha.
- GPS e busca de endereços continuam funcionando mesmo sem biblioteca ou tiles de mapa; com rota externa disponível, é possível consultar a estimativa sem desenho no mapa.
- Dependências locais Leaflet e MapLibre continuam no ZIP. O carregamento dos mapas vetoriais/raster depende de provedores externos de tiles.

**Verificação feita:** testes Node de GPS e estimativa sem mapa, verificações de estrutura do HTML, sintaxe do CSS e a suíte completa. **Verificação pendente:** renderização e toque em navegador de celular/desktop com tiles reais; o navegador remoto disponível recusa o servidor local deste ambiente.

## Entrega 3: demais telas e revisão final (neste ZIP)

- Viagens, motorista, perfil, administração, Tour e notificações usam ajustes de espaçamento, leitura, campos e ações nos dois temas existentes.
- Tabelas administrativas têm rolagem horizontal em telas estreitas; formulários e documentos do motorista não extravasam a largura do aparelho.
- Corrigida a regra que retirava a posição fixa da navegação inferior na home.
- Cache do service worker atualizado para carregar os novos CSS.

**Verificação feita:** suíte automatizada e análise sintática de HTML, JavaScript e CSS. **Verificação pendente:** revisão visual e toque em navegador de celular e desktop reais; o navegador remoto disponível não abre o servidor local deste ambiente.

## Correção após a etapa 3: recuperação do mapa

- Se o mapa vetorial falhar, a aplicação remove a instância e inicia o mapa básico com Leaflet automaticamente.
- A camada de compatibilidade vetorial é restaurada antes do fallback, para permitir marcadores e rotas no Leaflet.
- Falhas repetidas dos tiles básicos têm mensagem própria; GPS e busca continuam utilizáveis.
- O cache do PWA foi atualizado para entregar a correção. A disponibilidade dos tiles em cada rede precisa de verificação em um aparelho real.

## Melhoria do mapa após a etapa 3

- MapLibre com câmera inclinada e suavização de bordas; botão 2D/3D para alternar a perspectiva.
- Edifícios extrudados usam as alturas disponíveis nos dados OpenFreeMap/OpenStreetMap, com tons alinhados ao dourado do aplicativo.
- Relevo opcional usa tiles Terrarium públicos de elevação; se falharem, mantém o mapa sem terreno. Regiões sem alturas cadastradas permanecem planas.
- A recuperação para o mapa básico da correção anterior permanece ativa. A renderização de tiles externos ainda depende da conexão do aparelho; este ambiente não permite verificar os tiles em um navegador de celular real.

## Correção de legibilidade após o mapa 3D

- O mapa deixa de ser um fundo fixo por trás do formulário e fica contido no cartão “Perto de você”, que pode ser ampliado.
- Busca, partida, botão e textos passam a ter fundo opaco, sem sobreposição de tiles; cores e ações existentes são preservadas.
- Esta revisão foi validada por sintaxe e estrutura CSS, mas a renderização final ainda precisa ser conferida em celular real.

## Navegação: primeira entrega funcional

- O passageiro pode acompanhar o carro em uma vista ampliada. A câmera segue as coordenadas recebidas em tempo real, respeitando rumo recebido e perspectiva 3D disponível.
- Botão para sair do acompanhamento; arrastar o mapa também pausa o seguimento automático.
- O detector de posição antiga permanece ativo durante a animação do veículo e agora é desligado apenas ao encerrar o acompanhamento da corrida.
- Esta é a base de acompanhamento do passageiro. Ainda faltam instruções de conversão, recálculo, ajuste à via, trânsito e testes em dois aparelhos para alcançar o objetivo de navegação proposto.

## Orientação do motorista e integração de trânsito

- Orientação interna no mapa do VaiComigo com próxima manobra, distância, ETA e voz em português quando o navegador permitir.
- GPS é ajustado à geometria da rota para exibição; três amostras consecutivas fora da rota, com precisão aceitável e intervalo de segurança, solicitam recálculo.
- Edge Function `navigation-route` usa Mapbox Directions `driving-traffic` somente quando `MAPBOX_ACCESS_TOKEN` estiver configurado nos Secrets do Supabase; o token não sai no retorno. Sem a credencial ou se o serviço falhar, o app mantém a rota OSRM e informa que não dispõe de trânsito ao vivo.
- A camada colorida de congestionamento é mostrada somente quando a resposta do provedor contém segmentos de trânsito válidos.
- Ainda exigem validação em dois aparelhos e em trajeto real a confiabilidade de GPS, restrições de vias, conversões, voz e cobertura de trânsito em Petrópolis. O PWA depende das limitações de execução e localização em segundo plano do navegador.
