let map,me,accuracyCircle,destinationMarker,watchId;
let selectedDestination=null,selectedPickup=null,routeQuote=null,routeLine=null,pickupMarker=null,pendingMapSelection=null,quoteGeneration=0,rideRequestPending=false,lastGpsError=null;
const petr=[-22.5100,-43.1800];
let driverAvailable=false;
window.onVaiDriverAvailabilityChanged=function(available){driverAvailable=Boolean(available);if(driverAvailable)flushGpsQueue().catch(console.warn)};
let currentRole='passenger';
let appMode='passenger';
async function driverMode(){
  if(activeVaiArea()!=='driver')return;
  const user=await ensureUser(true);
  if(!user){ return; }
  appMode='driver';
  renderMode();
  tab('driver',2);
  loadDriverFinance();
  loadDriverEarnings();
}
async function loadDriverTourRequests(){
 if(!window.supabaseClient||!window.currentUser||!driverAvailable)return;
 const pos=await getPosition();
 if(!pos)return;
 const {data,error}=await window.supabaseClient.rpc('nearest_requested_tours',{p_lat:pos.lat,p_lng:pos.lng,p_radius_km:15});
 const box=document.getElementById('driverTourCall');
 if(!box)return;
 if(error||!data){box.innerHTML='';return}
 const t=data[0];
 if(!t){box.innerHTML='';return}
 const dt=new Date(t.start_at);
 box.innerHTML='<div class="call"><div class="head"><b>🏛️ Novo Tour</b><span class="status">'+Number(t.distance_km).toFixed(1)+' km</span></div><p><strong>'+dt.toLocaleDateString('pt-BR')+' • '+dt.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})+'</strong><br><span style="color:#667085;font-size:13px">'+t.duration_hours+' horas • R$ '+Number(t.price).toFixed(2).replace('.',',')+'</span></p><button class="btn" onclick="acceptTourCall(\''+t.id+'\')">Aceitar Tour</button></div>';
}
async function acceptTourCall(id){
 if(!window.supabaseClient||!window.currentUser)return;
 const {data,error}=await window.supabaseClient.rpc('accept_tour',{p_tour_id:id});
 if(error){document.getElementById('driverTourCall').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">Não foi possível aceitar este Tour.<br><span style="font-size:12px">'+String(error.message||'Tente novamente.')+'</span></div>';return}
 const dt=new Date(data.start_at);
 document.getElementById('driverTourCall').innerHTML='<div class="msg"><b>✓ Tour aceito</b><br>'+dt.toLocaleDateString('pt-BR')+' • '+dt.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})+' • '+data.duration_hours+'h<br><strong>R$ '+Number(data.price).toFixed(2).replace('.',',')+'</strong><br><span style="font-size:12px;color:#667085">O passageiro foi avisado em tempo real.</span></div>';
}
function calcFare(distanceKm=5,durationMin=12){
  const base=6.00, km=2.40, minute=.35;
  return Math.max(10, base+distanceKm*km+durationMin*minute);
}



const imperialStops=[
 {name:'Museu Imperial',lat:-22.5096,lng:-43.1779,minutes:100},
 {name:'Catedral São Pedro de Alcântara',lat:-22.5065,lng:-43.1785,minutes:35},
 {name:'Casa de Santos Dumont',lat:-22.5122,lng:-43.1765,minutes:45},
 {name:'Palácio de Cristal',lat:-22.5109,lng:-43.1827,minutes:40},
 {name:'Palácio Quitandinha',lat:-22.5215,lng:-43.2310,minutes:60}
];
function showImperialRoute(){
  if(!window.map||!window.L){document.getElementById('msg').textContent='Mapa indisponível. O roteiro do Tour continua disponível em texto.';showImperialPlan();return}
  if(window.tourLayer)window.map.removeLayer(window.tourLayer);
  const pts=imperialStops.map(x=>[x.lat,x.lng]);
  window.tourLayer=L.polyline(pts,{weight:5}).addTo(window.map);
  imperialStops.forEach((x,i)=>L.marker([x.lat,x.lng]).addTo(window.map).bindPopup(`<b>${i+1}. ${x.name}</b><br>${x.minutes} min sugeridos`));
  window.map.fitBounds(pts,{padding:[30,30]});
  document.getElementById('msg').innerHTML='<div class="msg"><b>🏛️ Roteiro Imperial carregado</b><br>5 paradas • Centro Histórico + Quitandinha</div>';
}
function showImperialPlan(){
 const rows=imperialStops.map((x,i)=>`<div style="padding:10px 0;border-bottom:1px solid #eee"><b>${i+1}. ${x.name}</b><br><span style="font-size:12px;color:#667085">${x.minutes} min sugeridos</span></div>`).join('');
 document.getElementById('msg').innerHTML=`<div class="msg"><b>Roteiro de 6 horas</b>${rows}<button class="btn" onclick="showImperialRoute()" style="margin-top:12px">Ver no mapa</button></div>`;
}

const TOUR_PRICES={4:200,6:280,8:360};
let activeTourSubscription=null;
function bookImperialTour(){tour()}
function updateTourSummary(){const h=Number(document.getElementById('tourHours')?.value||6),p=TOUR_PRICES[h]||280;const el=document.getElementById('tourSummary');if(el)el.innerHTML='<b>Roteiro incluso</b><br>5 paradas • Centro Histórico + Quitandinha<br><strong>R$ '+p.toFixed(2).replace('.',',')+'</strong> • '+h+' horas';}
function tourStatusLabel(status){return ({requested:'Aguardando confirmação',accepted:'Tour confirmado',cancelled:'Tour cancelado',completed:'Tour concluído'})[status]||status||'Status desconhecido'}
function tourCard(t){const d=new Date(t.start_at),date=d.toLocaleDateString('pt-BR'),time=d.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});return '<div class="call" style="margin-top:10px"><div class="head"><b>🏛️ Tour Imperial</b><span class="status">'+tourStatusLabel(t.status)+'</span></div><p><strong>'+date+' • '+time+'</strong><br><span style="color:#667085;font-size:13px">'+t.duration_hours+' horas • R$ '+Number(t.price).toFixed(2).replace('.',',')+'</span></p><button class="btn secondary" onclick="showImperialRoute()">Ver roteiro no mapa</button></div>'}
async function confirmTour(){const hours=Number(document.getElementById('tourHours').value),price=TOUR_PRICES[hours],date=document.getElementById('date').value,time=document.getElementById('time').value;if(!date||!time)return;if(!window.supabaseClient){closeTour();document.getElementById('msg').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318"><b>Serviço indisponível</b><br>O VaiComigo está indisponível no momento. Tente novamente em instantes.</div>';return}const user=await ensureUser(true);if(!user){closeTour();return}const pos=await getPosition(),startAt=new Date(date+'T'+time+':00');if(Number.isNaN(startAt.getTime()))return;if(!pos){document.getElementById('msg').textContent='Ative a localização para solicitar o Tour.';closeTour();return}closeTour();document.getElementById('msg').innerHTML='<div class="msg">⏳ Enviando solicitação do Tour Imperial…</div>';const itinerary=imperialStops.map((x,i)=>({order:i+1,name:x.name,lat:x.lat,lng:x.lng,minutes:x.minutes}));const payload={passenger_id:user.id,start_at:startAt.toISOString(),duration_hours:hours,price,status:'requested',pickup_lat:pos.lat,pickup_lng:pos.lng,route_code:'imperial-'+hours+'h',itinerary};const {data,error}=await window.supabaseClient.from('tour_bookings').insert(payload).select().single();if(error){document.getElementById('msg').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318"><b>Não foi possível solicitar o Tour.</b><br><span style="font-size:12px">'+String(error.message||'Tente novamente em instantes.')+'</span></div>';return}window.activeTour=data;subscribeTour(data.id);document.getElementById('msg').innerHTML='<div class="msg"><b>✓ Tour Imperial solicitado</b><br>'+date.split('-').reverse().join('/')+' • '+time+' • '+hours+'h<br><strong>R$ '+price.toFixed(2).replace('.',',')+'</strong><br><span style="font-size:12px;color:#667085">Aguardando confirmação do motorista.</span><br><button class="btn" style="margin-top:10px" onclick="showImperialRoute()">Ver roteiro no mapa</button></div>';loadMyTours()}
function rideStatusLabel(status){return ({requested:'Procurando motorista',accepted:'Motorista encontrado',arriving:'Motorista a caminho',in_progress:'Em andamento',completed:'Concluída',cancelled:'Cancelada'})[status]||status||'Desconhecido'}
function formatMoney(v){return 'R$ '+Number(v||0).toFixed(2).replace('.',',')}
function formatDateTime(v){const d=new Date(v);return d.toLocaleDateString('pt-BR')+' • '+d.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}
function rideCard(r){const completed=r.status==='completed';return '<div class="call" style="margin-top:10px"><div class="head"><b>🚗 '+escapeHtml(r.destination_name||'Corrida')+'</b><span class="status">'+rideStatusLabel(r.status)+'</span></div><p><strong>'+formatDateTime(r.created_at)+'</strong><br><span style="color:#667085;font-size:13px">'+formatMoney(r.final_price ?? r.estimated_price)+'</span></p><button class="btn secondary" onclick="showRideReceipt(\''+r.id+'\')">'+(completed?'Ver recibo':'Ver detalhes')+'</button></div>'}
async function loadTripHistory(){
 const box=document.getElementById('rideHistory'); if(!box)return;
 if(!window.supabaseClient){box.innerHTML='<p style="color:#667085;font-size:13px">Entre na sua conta para consultar seu histórico.</p>';return}
 const user=await ensureUser(); if(!user){box.innerHTML='<p style="color:#667085;font-size:13px">Entre na sua conta para consultar seu histórico.</p>';return}
 box.innerHTML='<p style="color:#667085;font-size:13px">⏳ Carregando corridas…</p>';
 const {data,error}=await window.supabaseClient.from('rides').select('id,created_at,updated_at,status,destination_name,estimated_price,fare_estimate,final_price,origin_lat,origin_lng,driver_id,accepted_at,arrived_at,started_at,completed_at,cancelled_at,payment_status,payment_method').eq('passenger_id',user.id).order('created_at',{ascending:false}).limit(30);
 if(error){box.innerHTML='<p style="color:#b42318;font-size:13px">Não foi possível carregar o histórico.<br><span style="font-size:11px">'+String(error.message||'Erro inesperado.')+'</span></p>';return}
 box.innerHTML=data?.length?data.map(rideCard).join(''):'<p style="color:#667085;font-size:13px">Você ainda não possui corridas.</p>';
}
async function showRideReceipt(id){
 if(!window.supabaseClient)return;
 const {data,error}=await window.supabaseClient.from('rides').select('id,created_at,updated_at,status,destination_name,estimated_price,fare_estimate,final_price,origin_lat,origin_lng,driver_id,accepted_at,arrived_at,started_at,completed_at,cancelled_at,payment_status,payment_method').eq('id',id).maybeSingle();
 if(error||!data){document.getElementById('msg').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">Não foi possível abrir os detalhes desta viagem.</div>';tab('home',0);return}
 const price=data.final_price ?? data.fare_estimate ?? data.estimated_price ?? 0;
 const duration=data.started_at&&data.completed_at?Math.max(0,Math.round((new Date(data.completed_at)-new Date(data.started_at))/60000)):null;
 document.getElementById('msg').innerHTML='<div class="call"><div class="head"><b>🧾 Detalhes da viagem</b><span class="status">'+rideStatusLabel(data.status)+'</span></div><p><strong>Destino</strong><br>'+escapeHtml(data.destination_name||'Não informado')+'</p><p style="font-size:13px;color:#667085;margin:6px 0">Solicitada: '+formatDateTime(data.created_at)+(duration!==null?' • Duração: '+duration+' min':'')+'<br>Pagamento: '+String(data.payment_method||'Não informado')+' • '+String(data.payment_status||'pending')+'</p><div style="font-size:20px;font-weight:900;margin-top:8px">'+formatMoney(price)+'</div></div>';
 tab('home',0); window.scrollTo({top:document.body.scrollHeight,behavior:'smooth'});
}

async function loadMyTours(){const box=document.getElementById('myTours');if(!box)return;if(!window.supabaseClient){box.innerHTML='<p style="color:#667085;font-size:13px">Entre na sua conta para consultar seus Tours.</p>';return}const user=await ensureUser();if(!user){box.innerHTML='<p style="color:#667085;font-size:13px">Não foi possível identificar sua conta.</p>';return}box.innerHTML='<p style="color:#667085;font-size:13px">⏳ Carregando…</p>';const {data,error}=await window.supabaseClient.from('tour_bookings').select('id,start_at,duration_hours,price,status,route_code,itinerary').eq('passenger_id',user.id).order('start_at',{ascending:false}).limit(20);if(error){box.innerHTML='<p style="color:#b42318;font-size:13px">Não foi possível carregar seus Tours.</p>';return}box.innerHTML=data?.length?data.map(tourCard).join(''):'<p style="color:#667085;font-size:13px">Você ainda não possui Tours agendados.</p>'}
function subscribeTour(id){if(!window.supabaseClient)return;if(activeTourSubscription)window.supabaseClient.removeChannel(activeTourSubscription);activeTourSubscription=window.supabaseClient.channel('tour-'+id).on('postgres_changes',{event:'UPDATE',schema:'public',table:'tour_bookings',filter:'id=eq.'+id},payload=>{const t=payload.new;window.activeTour=t;loadMyTours();document.getElementById('msg').innerHTML='<div class="msg"><b>🏛️ Tour Imperial</b><br>Status atualizado: <strong>'+tourStatusLabel(t.status)+'</strong><br>'+t.duration_hours+'h • R$ '+Number(t.price).toFixed(2).replace('.',',')+'</div>'}).subscribe()}
async function cancelTour(){if(!window.supabaseClient||!window.activeTour){document.getElementById('msg').innerHTML='<div class="msg">Nenhuma reserva ativa para cancelar.</div>';return}const {error}=await window.supabaseClient.from('tour_bookings').update({status:'cancelled'}).eq('id',window.activeTour.id);if(error){document.getElementById('msg').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">Não foi possível cancelar a reserva.</div>';return}window.activeTour=null;document.getElementById('msg').innerHTML='<div class="msg">Reserva do Tour Imperial cancelada.</div>';loadMyTours()}

function currentPaymentMethod(){return document.getElementById('paymentMethod')?.value||localStorage.getItem('vai_payment')||'cash'}
function paymentLabel(m){return m==='card'?'Cartão':m==='cash'?'Dinheiro':'Pix'}
function choosePayment(method){
  if(method!=='cash'&&!window.VAI_CONFIG?.paymentsEnabled){method='cash'}
  const sel=document.getElementById('paymentMethod'); if(sel)sel.value=method; localStorage.setItem('vai_payment',method);
  ['pix','card','cash'].forEach(x=>document.getElementById('pay'+x[0].toUpperCase()+x.slice(1))?.classList.toggle('on',x===method));
  const panel=document.getElementById('paymentPanel'); if(panel)panel.innerHTML=method==='pix'?'Pix selecionado. O QR Code será gerado pelo provedor de pagamento quando conectado.':method==='card'?'Cartão selecionado. O pagamento será finalizado em checkout seguro do provedor; nenhum dado de cartão fica no VaiComigo.':'Dinheiro selecionado. O motorista confirmará o recebimento ao final da corrida.';
  const qp=document.getElementById('quotePayment');if(qp)qp.textContent=paymentLabel(method);
}
function openAuth(mode){
 if(!activeVaiArea())return;
 if(activeVaiArea()==='admin')mode='login';
 for(const id of ['authEmail','authPassword','authName','authPhone'])document.getElementById(id).value='';
 authMode=mode;
 document.getElementById('authModal').classList.add('on');
 document.getElementById('authTitle').textContent=mode==='signup'?'Criar conta':'Entrar';
 document.getElementById('authSubmit').textContent=mode==='signup'?'Criar conta':'Entrar';
 document.getElementById('authName').style.display=mode==='signup'?'block':'none';
 document.getElementById('authPhone').style.display=mode==='signup'?'block':'none';
 document.getElementById('authMsg').textContent='';
 document.getElementById('authGuide').textContent=mode==='signup'?'Crie sua conta. Em seguida, entre com seu e-mail e senha.':'Use o e-mail e a senha da sua conta.';
 document.getElementById('authSwitch').textContent=mode==='signup'?'Já tenho conta · Entrar':'Não tenho conta · Cadastrar';
 document.getElementById('authSwitch').hidden=activeVaiArea()==='admin';
 document.getElementById('authEmail').focus();
}
function switchAuthForm(){if(activeVaiArea()==='admin')return;const email=document.getElementById('authEmail').value.trim();openAuth(authMode==='signup'?'login':'signup');document.getElementById('authEmail').value=email}
function closeAuth(){document.getElementById('authModal').classList.remove('on')}
function authFeedback(text){const msg=document.getElementById('authMsg');if(msg)msg.textContent=text}
async function rejectWrongArea(text){
 await signOutVai();localStorage.removeItem(VAI_ENTRY_KEY);delete document.body.dataset.entryRole;
 if(window.VAI_FIXED_ROLE){enterVaiArea(window.VAI_FIXED_ROLE);document.getElementById('connectionStatus').textContent=text;return;}
 document.querySelectorAll('.page').forEach(page=>page.classList.remove('active'));
 document.getElementById('entryNotice').textContent=text;
 renderMode();scrollTo(0,0);
}
async function submitAuth(){
 if(!window.supabaseClient){authFeedback('O VaiComigo está indisponível no momento. Tente novamente.');return}
 const email=document.getElementById('authEmail').value.trim(),password=document.getElementById('authPassword').value;
 const name=authMode==='signup'?document.getElementById('authName').value.trim():'';
 const phone=authMode==='signup'?document.getElementById('authPhone').value.trim():'';
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||password.length<6){authFeedback('Confira seu e-mail e informe uma senha de pelo menos 6 caracteres.');return}
 if(authMode==='signup'&&!name){authFeedback('Informe seu nome para criar a conta.');return}
 const btn=document.getElementById('authSubmit');btn.disabled=true;btn.textContent='Aguarde…';
 try{
  const result=authMode==='signup'
   ?await window.supabaseClient.auth.signUp({email,password,options:{emailRedirectTo:window.VAI_AUTH_REDIRECT||location.origin+location.pathname,data:{full_name:name,phone,requested_area:activeVaiArea()}}})
   :await window.supabaseClient.auth.signInWithPassword({email,password});
  if(result.error){authFeedback(result.error.message);return}
  if(authMode==='signup'){
   if(result.data?.session){const {error}=await window.supabaseClient.auth.signOut();if(error)throw error;}
   window.currentUser=null;window.appContext=null;
   closeAuth();openAuth('login');document.getElementById('authEmail').value=email;
   authFeedback('Cadastro recebido. Se o Supabase pedir confirmação, abra o link enviado ao seu e-mail. Depois entre com sua senha.');
   document.getElementById('authPassword').focus();return;
  }
  if(!result.data?.session?.user){authFeedback('Não foi possível entrar. Confira o e-mail e a senha.');return}
  window.currentUser=result.data.session.user;
  await ensureProfileData();await loadProfileRole();await refreshAppContext();
  const area=activeVaiArea(),ctx=window.appContext||{};
  const admin=ctx.is_admin===true||currentRole==='admin';
  const driver=ctx.has_driver_profile===true||currentRole==='driver'||window.currentUser.user_metadata?.requested_area==='driver';
  if(area==='admin'&&!admin){closeAuth();await rejectWrongArea('Esta conta não tem acesso à administração. Escolha sua área para entrar.');return}
  if(area==='passenger'&&(admin||driver)){closeAuth();await rejectWrongArea('Esta conta é de motorista ou diretor. Selecione sua área de trabalho para entrar.');return}
  if(area==='driver'&&!driver&&admin){closeAuth();await rejectWrongArea('Entre em Administração para gerenciar a operação. Para dirigir, cadastre primeiro seu perfil profissional.');return}
  if(area==='driver'&&!driver){closeAuth();await rejectWrongArea('Esta conta foi criada para passageiro. Entre na área de passageiro.');return}
  closeAuth();await refreshAccountUI();renderMode();refreshAdminEntry();
  document.getElementById('connectionStatus').textContent='Conta conectada.';
  tab(area==='admin'?'admin':area==='driver'?'driver':'home',area==='admin'?4:area==='driver'?2:0);
  if(area==='driver'){ensureVaiMapStarted();await loadDriverProfileReal();await loadMyDriverDocuments();loadDriverFinance();loadDriverEarnings();}
  if(area==='passenger'){loadTripHistory();loadMyTours();}
 }catch(error){authFeedback('Não foi possível concluir. Confira sua conexão e tente novamente.');console.error('Autenticação',error)}
 finally{btn.disabled=false;btn.textContent=authMode==='signup'?'Criar conta':'Entrar'}
}
async function ensureProfileData(name='',phone=''){
  if(!window.supabaseClient||!window.currentUser)return;
  const payload={id:window.currentUser.id,full_name:name||window.currentUser.user_metadata?.full_name||localStorage.getItem('vai_profile_name')||'Passageiro VaiComigo',phone:phone||window.currentUser.user_metadata?.phone||localStorage.getItem('vai_profile_phone')||null};
  const {data}=await window.supabaseClient.from('profiles').select('id,full_name,phone,role,payment_method').eq('id',window.currentUser.id).maybeSingle();
  if(!data)await window.supabaseClient.from('profiles').insert(payload);else if(name||phone)await window.supabaseClient.from('profiles').update({full_name:payload.full_name,phone:payload.phone}).eq('id',window.currentUser.id);
}
async function refreshAccountUI(){
  const status=document.getElementById('authStatus'),nameEl=document.getElementById('profileName'),phoneEl=document.getElementById('profilePhone');
  if(!window.currentUser){if(status)status.textContent='Visitante';return}
  await ensureProfileData();const {data}=await window.supabaseClient.from('profiles').select('full_name,phone,avatar_url').eq('id',window.currentUser.id).maybeSingle();
  if(status)status.textContent='Conectado';if(nameEl)nameEl.textContent=data?.full_name||window.currentUser.email||'Conta VaiComigo';if(phoneEl)phoneEl.textContent=data?.phone||window.currentUser.email||'Conta VaiComigo';document.querySelector('#profile .authGrid')?.classList.add('vc-account-connected');window.loadMyIdentityReview?.();
}
async function signOutVai(){
 if(window.VAI_NATIVE_APP&&window.VAI_FIXED_ROLE==='driver'&&window.currentUser){
  const {error}=await window.supabaseClient.rpc('set_driver_availability',{p_available:false});
  if(error)throw error;
  await window.VaiNativeLocation?.stop();
 }
 if(window.VAI_NATIVE_APP&&window.VAI_FIXED_ROLE==='driver'&&window.VaiNativePush)await window.VaiNativePush.unregister();
 if(window.supabaseClient){const {error}=await window.supabaseClient.auth.signOut();if(error)throw error;}
 window.currentUser=null;window.appContext=null;window.activeRide=null;window.vaiIdentityApproved=false;currentRole='passenger';
 const status=document.getElementById('authStatus'),name=document.getElementById('profileName'),phone=document.getElementById('profilePhone');
 if(status)status.textContent='Visitante';if(name)name.textContent='Conta VaiComigo';if(phone)phone.textContent='Conta desconectada';
 document.querySelector('#profile .authGrid')?.classList.remove('vc-account-connected');window.loadMyIdentityReview?.();
 const recent=document.getElementById('driverCall');if(recent)recent.replaceChildren();
 const ride=document.getElementById('activeRidePanel');if(ride)ride.style.display='none';renderMode();
}
async function saveDriverProfileReal(){
 const user=await ensureUser(true);if(!user||!window.supabaseClient)return;
 const fields=['driverName','driverPhone','driverVehicle','driverPlate','driverColor','driverYear'].map(id=>document.getElementById(id)?.value.trim()||'');
 const [name,phone,vehicle,plate,color,year]=fields;
 const feedback=document.getElementById('driverJourneyStatus'),button=document.getElementById('driverProfileSave');
 if(!name||!vehicle||!plate){feedback.textContent='Preencha nome, modelo do veículo e placa antes de salvar.';return}
 if(year && (!Number.isInteger(Number(year))||Number(year)<1980||Number(year)>new Date().getFullYear()+1)){
  feedback.textContent='Confira o ano do veículo.';return;
 }
 button.disabled=true;button.textContent='Salvando…';feedback.textContent='Salvando seus dados…';
 try{
  const editing=Boolean(window.appContext?.has_driver_profile);
  const {data,error}=editing
   ?await window.supabaseClient.rpc('update_my_driver_profile',{p_full_name:name,p_phone:phone,p_vehicle_model:vehicle,p_vehicle_plate:plate,p_vehicle_color:color||null,p_vehicle_year:year?Number(year):null,p_avatar_url:null})
   :await window.supabaseClient.rpc('register_driver',{p_full_name:name,p_phone:phone,p_vehicle_model:vehicle,p_vehicle_plate:plate,p_vehicle_color:color||null,p_vehicle_year:year?Number(year):null});
  if(error)throw error;
  await refreshAppContext();renderMode();await loadDriverProfileReal();
  document.getElementById('driverApproval').textContent=data?.document_status==='approved'?'Aprovado':'Aguardando análise';
  feedback.textContent=editing?'Dados atualizados. Confira seus documentos abaixo.':'Cadastro salvo. Agora envie CNH e CRLV e verifique sua identidade no Perfil.';
  document.getElementById('driverDocumentsCard')?.scrollIntoView({behavior:'smooth',block:'start'});
 }catch(error){feedback.textContent='Não foi possível salvar: '+(error.message||'tente novamente.');}
 finally{button.disabled=false;button.textContent='Salvar cadastro do motorista';}
}
async function loadDriverProfileReal(){
 if(!window.supabaseClient||!window.currentUser)return;const {data}=await window.supabaseClient.from('drivers').select('full_name,phone,vehicle_model,vehicle_plate,vehicle_color,vehicle_year,document_status,status').eq('id',window.currentUser.id).maybeSingle();if(!data)return;
 const map={driverName:data.full_name,driverPhone:data.phone,driverVehicle:data.vehicle_model,driverPlate:data.vehicle_plate,driverColor:data.vehicle_color,driverYear:data.vehicle_year};for(const [id,v] of Object.entries(map)){const el=document.getElementById(id);if(el)el.value=v??''}const st=document.getElementById('driverApproval');if(st)st.textContent=data.document_status==='approved'?'Aprovado':data.document_status==='rejected'?'Reprovado':'Aguardando documentos';
 if(window.VAI_NATIVE_APP&&data.status==='available'&&!driverAvailable){
  await window.vaiComigoDriver?.setAvailability(true);
 }
}

async function saveDriverProfile(){
  const user=await ensureUser(true); if(!user)return;
  const {data:prof}=await window.supabaseClient.from('profiles').select('full_name,phone').eq('id',user.id).maybeSingle();
  const name=prompt('Nome do motorista:',prof?.full_name||''); if(!name)return;
  const phone=prompt('Celular com DDD:',prof?.phone||''); if(phone===null)return;
  const model=prompt('Modelo do veículo:','Chevrolet Onix'); if(!model)return;
  const plate=prompt('Placa:','ABC1D23'); if(!plate)return;
  const {data,error}=await window.supabaseClient.rpc('register_driver',{p_full_name:name,p_phone:phone,p_vehicle_model:model,p_vehicle_plate:plate,p_vehicle_color:null,p_vehicle_year:null});
  if(error){alert('Não foi possível concluir o cadastro: '+(error.message||'tente novamente.'));return}
  localStorage.setItem('vai_driver_name',name);
  localStorage.setItem('vai_driver_model',model);
  localStorage.setItem('vai_driver_plate',plate);
  await refreshAppContext(); renderMode(); loadDriverProfileReal();
  alert(data?.document_status==='approved'?'✓ Cadastro de motorista concluído e aprovado (ambiente de teste).':'✓ Cadastro enviado. Envie CNH e CRLV na área do motorista para análise.');
}
async function startPayment(){
  const method=document.getElementById('paymentMethod')?.value||localStorage.getItem('vai_payment')||'cash';
  localStorage.setItem('vai_payment',method);
  const ride=window.activeRide;
  if(!ride||ride.status!=='completed'){
    document.getElementById('msg').innerHTML='<div class="msg">O pagamento fica disponível depois que a corrida for concluída.</div>'; return;
  }
  if(method==='cash'){
    document.getElementById('msg').innerHTML='<div class="msg"><b>💵 Dinheiro</b><br>O motorista confirma o recebimento ao final da corrida.</div>'; return;
  }
  if(!window.supabaseClient){document.getElementById('msg').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">Entre na sua conta para pagar.</div>';return;}
  const panel=document.getElementById('paymentPanel'); if(panel)panel.innerHTML='⏳ Criando cobrança segura…';
  const {data,error}=await window.supabaseClient.functions.invoke('create-payment',{body:{ride_id:ride.id}});
  if(error){if(panel)panel.innerHTML='<span style="color:#b42318">Não foi possível iniciar o pagamento.<br>'+escapeHtml(error.message||'Erro no gateway.')+'</span>';return;}
  if(data?.kind==='pix'){
    const qr=data.qr_code_base64?'<img alt="QR Code Pix" style="width:220px;height:220px;display:block;margin:10px auto;border-radius:12px" src="data:image/png;base64,'+data.qr_code_base64+'">':'';
    const code=data.qr_code?'<textarea readonly style="width:100%;min-height:90px;border:1px solid var(--line);border-radius:12px;padding:10px;font-size:12px">'+escapeHtml(data.qr_code)+'</textarea>':'';
    if(panel)panel.innerHTML='<div><b>⚡ Pix gerado</b>'+qr+'<p style="font-size:12px;color:#667085">Pague pelo QR Code ou copie o código Pix. O status será atualizado automaticamente após a confirmação do provedor.</p>'+code+'<button class="btn secondary" style="margin-top:8px" onclick="copyPixCode()">Copiar código Pix</button></div>';
    window.lastPixCode=data.qr_code||'';
  } else if(data?.kind==='card'&&data.checkout_url){
    if(panel){panel.innerHTML='<div><b>💳 Checkout seguro</b><p>Você será levado ao checkout do provedor para concluir o cartão.</p></div>';const url=new URL(data.checkout_url);if(url.protocol!=='https:'||!/(^|\.)mercadopago\.com(\.br)?$/.test(url.hostname)){panel.textContent='Checkout com endereço inválido. Tente novamente.';return;}const button=document.createElement('button');button.className='btn';button.textContent='Abrir checkout';button.addEventListener('click',()=>location.assign(url.href));panel.firstElementChild.append(button);}
  } else if(panel) panel.innerHTML='<span style="color:#b42318">Resposta de pagamento incompleta.</span>';
}
async function copyPixCode(){if(!window.lastPixCode)return;try{await navigator.clipboard.writeText(window.lastPixCode);alert('Código Pix copiado.')}catch(e){alert('Selecione e copie o código manualmente.')}}

function openAccount(){if(!window.currentUser){openAuth('signup');return}document.getElementById('identityReviewCard')?.scrollIntoView({behavior:'smooth',block:'start'})}
function showFare(){
  const d=Number(prompt('Distância estimada em km','5')||5);
  const t=Number(prompt('Tempo estimado em minutos','12')||12);
  const v=calcFare(d,t);
  document.getElementById('msg').innerHTML='<div class="msg"><b>Estimativa da corrida</b><br>R$ '+v.toFixed(2).replace('.',',')+'<br><span style="font-size:12px;color:#667085">'+d.toFixed(1)+' km • '+t+' min</span></div>';
}

const APP_CONFIG=window.VAI_CONFIG||{};
const SB_URL=String(APP_CONFIG.supabaseUrl||'').trim();
const SB_KEY=String(APP_CONFIG.supabaseAnonKey||'').trim();
window.supabaseClient=(SB_URL&&SB_KEY)?supabase.createClient(SB_URL,SB_KEY,window.VAI_NATIVE_APP?{auth:{flowType:'pkce'}}:undefined):null;
window.vaiAppConfigured=!!(SB_URL&&SB_KEY);
window.currentUser=null;
window.VAI_VAPID_PUBLIC_KEY=String(APP_CONFIG.vapidPublicKey||document.querySelector('meta[name="vai-vapid-public-key"]')?.content||'').trim();
window.enableDriverPush=enableDriverPush;
window.addEventListener('load',()=>{const p=localStorage.getItem('vai_payment')||'cash';choosePayment(p);if(!window.VAI_CONFIG?.paymentsEnabled){for(const id of ['payPix','payCard']){const button=document.getElementById(id);if(button){button.disabled=true;button.title='Disponível após ativação do provedor de pagamentos';button.style.opacity='.5'}}const pay=document.querySelector('button[onclick="startPayment()"]');if(pay)pay.style.display='none'}const cs=document.getElementById('connectionStatus');if(!window.supabaseClient&&cs)cs.textContent='Serviço ainda não configurado. O aplicativo precisa das configurações internas do ambiente.';});
async function connectDemo(){
 // Restaura a sessão existente. Nunca cria usuário anônimo: o usuário faz CRIAR CONTA → ENTRAR.
 if(!window.supabaseClient)return;
 const {data:{session}}=await window.supabaseClient.auth.getSession();
 if(!session)return;
 window.currentUser=session.user;
 refreshAdminEntry();
 document.getElementById('connectionStatus').textContent='✓ Conta conectada ao VaiComigo.'; refreshAccountUI(); loadMyTours();
}
let vaiUnavailableWarned=false;
function notifyServiceUnavailable(){
 console.error('[VaiComigo] Configuração interna ausente: preencha supabaseUrl e supabaseAnonKey em js/config.js (ou SUPABASE_URL/SUPABASE_ANON_KEY no deploy).');
 if(vaiUnavailableWarned)return; vaiUnavailableWarned=true;
 alert('O VaiComigo está indisponível no momento. Tente novamente em alguns instantes.');
}
function promptLogin(){
 openAuth('login');
 const m=document.getElementById('authMsg'); if(m)m.textContent='Entre ou crie sua conta para continuar.';
}
async function loadProfileRole(){
 if(!window.supabaseClient||!window.currentUser)return 'passenger';
 try{
   const {data,error}=await window.supabaseClient.rpc('get_my_app_context');
   if(!error&&data){
     currentRole=data.role||'passenger';
     window.appContext=data;
     return currentRole;
   }
 }catch(e){}
 const {data}=await window.supabaseClient.from('profiles').select('role').eq('id',window.currentUser.id).maybeSingle();
 currentRole=data?.role||'passenger';
 return currentRole;
}

async function refreshAppContext(){
 if(!window.supabaseClient||!window.currentUser)return null;
 const {data,error}=await window.supabaseClient.rpc('get_my_app_context');
 if(!error&&data){window.appContext=data;currentRole=data.role||'passenger';return data;}
 return null;
}
async function ensureUser(interactive=false){
 // interactive=true: ação iniciada pelo usuário (abre Entrar/Criar conta se ainda não houver sessão).
 // interactive=false: chamadas de fundo, nunca abrem telas nem alertas.
 if(!window.supabaseClient){ if(interactive)notifyServiceUnavailable(); return null }
 if(window.currentUser){if(!currentRole)await loadProfileRole();return window.currentUser}
 await connectDemo();
 if(window.currentUser){
   const {data:existing}=await window.supabaseClient.from('profiles').select('id,role').eq('id',window.currentUser.id).maybeSingle();
   if(!existing){ await ensureProfileData(); }
   await loadProfileRole();
 } else if(interactive){ promptLogin(); }
 return window.currentUser||null
}
// Reenvio de pontos armazenados pela versão anterior; novas posições usam VaiComigoGPS.
const DRIVER_GPS_QUEUE_KEY='vai_driver_gps_queue_v24';
function readGpsQueue(){try{return JSON.parse(localStorage.getItem(DRIVER_GPS_QUEUE_KEY)||'[]')}catch{return[]}}
function writeGpsQueue(q){try{localStorage.setItem(DRIVER_GPS_QUEUE_KEY,JSON.stringify(q.slice(-120)))}catch{}}
async function flushGpsQueue(){
 if(!navigator.onLine||!window.supabaseClient||!window.currentUser||!driverAvailable)return;
 const q=readGpsQueue();if(!q.length)return;
 const remaining=[];
 for(const point of q){
  const {error}=await window.supabaseClient.rpc('update_driver_location',{p_lat:point.lat,p_lng:point.lng,p_accuracy:point.accuracy,p_heading:point.heading,p_speed:point.speed});
  if(error)remaining.push(point);
 }
 writeGpsQueue(remaining);
}
window.addEventListener('online',flushGpsQueue);
window.addEventListener('focus',()=>{if(document.getElementById('driver')?.classList.contains('active')){loadDriverFinance();loadDriverEarnings();loadDriverProfileReal();loadMyDriverDocuments();refreshAppContext().then(renderMode)}});
window.addEventListener('offline',()=>{const sync=document.getElementById('driverLocationSync');if(sync)sync.textContent='⚠ Sem conexão • GPS sendo armazenado localmente';});

async function confirmCashPaymentForRide(id){
 if(!window.supabaseClient)return;
 const {data,error}=await window.supabaseClient.rpc('confirm_cash_payment',{p_ride_id:id});
 if(error){document.getElementById('driverCall').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">Não foi possível confirmar o pagamento em dinheiro.</div>';return}
 document.getElementById('driverCall').innerHTML='<div class="msg"><b>✓ Pagamento em dinheiro confirmado</b><br>'+formatMoney(data.amount)+' registrado como pago.</div>';
}
async function loadDriverFinance(){
 const box=document.getElementById('driverFinance'); if(!box)return;
 if(!window.supabaseClient){box.innerHTML='<p style="color:#667085;font-size:13px">Entre na sua conta para consultar seus ganhos.</p>';return}
 const user=await ensureUser(); if(!user){box.innerHTML='<p style="color:#667085;font-size:13px">Entre na sua conta para consultar seus ganhos.</p>';return}
 box.innerHTML='<p style="color:#667085;font-size:13px">⏳ Calculando seus ganhos…</p>';
 const {data,error}=await window.supabaseClient.rpc('get_driver_financial_summary');
 if(error){box.innerHTML='<p style="color:#b42318;font-size:13px">Não foi possível carregar o financeiro.<br><span style="font-size:11px">'+String(error.message||'Erro inesperado.')+'</span></p>';return}
 const x=data?.[0]||data||{};
 const earned=Number(x.driver_earnings||0), gross=Number(x.gross_completed||0), commission=Number(x.platform_commission||0), paid=Number(x.paid_to_driver||0), pending=Math.max(0,earned-paid);
 box.innerHTML='<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">'+
 '<div style="background:#f8fafc;border-radius:14px;padding:12px"><small style="color:#667085">Bruto</small><div style="font-size:20px;font-weight:900">'+formatMoney(gross)+'</div></div>'+
 '<div style="background:#ecfdf3;border-radius:14px;padding:12px"><small style="color:#667085">Seu ganho</small><div style="font-size:20px;font-weight:900;color:#166534">'+formatMoney(earned)+'</div></div>'+
 '<div style="background:#fff7ed;border-radius:14px;padding:12px"><small style="color:#667085">Comissão</small><div style="font-size:18px;font-weight:900">'+formatMoney(commission)+'</div></div>'+
 '<div style="background:#eff6ff;border-radius:14px;padding:12px"><small style="color:#667085">A receber</small><div style="font-size:18px;font-weight:900;color:#1949a8">'+formatMoney(pending)+'</div></div></div>'+
 '<p style="margin:10px 0 0;color:#667085;font-size:11px">Comissão configurada: '+Number(x.commission_percent||20).toFixed(2).replace('.',',')+'%. Nenhum repasse bancário é realizado automaticamente nesta fase.</p>';
}
async function loadDriverEarnings(){
 const box=document.getElementById('driverFinance'); if(!box||!window.supabaseClient)return;
 const {data,error}=await window.supabaseClient.rpc('get_driver_earnings',{p_limit:20});
 if(error||!data)return;
 if(!data.length){box.innerHTML+='<p style="color:#667085;font-size:13px;margin-top:10px">Nenhuma corrida concluída ainda.</p>';return}
 box.innerHTML+='<div style="margin-top:12px"><b style="font-size:13px">Últimas corridas</b>'+data.map(r=>'<div style="padding:10px 0;border-bottom:1px solid #eee;font-size:12px"><strong>'+formatDateTime(r.completed_at)+'</strong> • '+escapeHtml(r.destination_name||'Corrida')+'<br><span style="color:#667085">Bruto '+formatMoney(r.gross_amount)+' • Comissão '+formatMoney(r.platform_commission)+' • Você '+formatMoney(r.driver_earnings)+' • '+String(r.payment_status||'pending')+'</span></div>').join('')+'</div>';
}
async function buildDriverRoute(destLat,destLng,label='Destino'){
 if(!map||!Number.isFinite(destLat)||!Number.isFinite(destLng))return;
 const start=me?.getLatLng();
 if(!start){const pos=await getPosition(); if(!pos)return null; return buildDriverRouteFrom(Number(pos.lat),Number(pos.lng),destLat,destLng,label)}
 return buildDriverRouteFrom(start.lat,start.lng,destLat,destLng,label);
}
let navigationTrafficUnavailable=false;
async function requestNavigationRoute(origin,target){
 if(!navigationTrafficUnavailable&&window.supabaseClient?.functions?.invoke&&window.currentUser){
  try{
   const result=await Promise.race([
    window.supabaseClient.functions.invoke('navigation-route',{body:{origin,target}}),
    new Promise((_,reject)=>setTimeout(()=>reject(new Error('traffic_timeout')),4200))
   ]);
   if(!result.error&&result.data?.route?.geometry?.coordinates?.length>1)return result.data;
   if(result.error?.context?.status===503)navigationTrafficUnavailable=true;
  }catch(error){console.warn('Rota com trânsito indisponível',error)}
 }
 const url='https://router.project-osrm.org/route/v1/driving/'+origin.lng+','+origin.lat+';'+target.lng+','+target.lat+'?overview=full&geometries=geojson&steps=true';
 const response=await fetchWithTimeout(url,{cache:'no-store'},15000);
 if(!response.ok)throw new Error('route_http_'+response.status);
 const data=await response.json(),route=data.routes?.[0];if(!route)throw new Error('route_empty');
 return {route,source:'osrm',traffic:null};
}
function drawTrafficSegments(route,traffic){
 if(!map?.native||!map.ready)return;
 const gl=map.gl,id='vc-traffic-live';
 try{
  if(gl.getLayer(id))gl.removeLayer(id);
  if(gl.getSource(id))gl.removeSource(id);
  const coords=route?.geometry?.coordinates||[],levels=traffic?.congestion||[];
  if(levels.length!==coords.length-1)return;
  const features=levels.flatMap((level,i)=>['moderate','heavy','severe'].includes(level)?[{type:'Feature',properties:{level},geometry:{type:'LineString',coordinates:[coords[i],coords[i+1]]}}]:[]);
  if(!features.length)return;
  gl.addSource(id,{type:'geojson',data:{type:'FeatureCollection',features}});
  gl.addLayer({id,type:'line',source:id,paint:{'line-color':['match',['get','level'],'severe','#b02f39','heavy','#e06840','moderate','#e5aa53','#d4b17a'],'line-width':8,'line-opacity':.9}},gl.getStyle().layers?.find(x=>x.type==='symbol')?.id);
 }catch(error){console.warn('Camada de trânsito indisponível',error)}
}
async function buildDriverRouteFrom(startLat,startLng,destLat,destLng,label){
 const info=document.getElementById('driverRouteInfo'); if(info)info.textContent='Calculando rota…';
 try{
   const result=await requestNavigationRoute({lat:startLat,lng:startLng},{lat:destLat,lng:destLng}),route=result.route;
   if(window.driverRouteLayer)map.removeLayer(window.driverRouteLayer);
   window.driverRouteLayer=L.geoJSON(route.geometry,{style:{color:'#d4b17a',weight:7,opacity:.95}}).addTo(map);
   drawTrafficSegments(route,result.traffic);
   window.driverRouteTarget=L.latLng(destLat,destLng);
   window.driverRouteSteps=route.legs?.[0]?.steps||[];
   window.VaiNavigationEngine?.setRoute(route);
   const km=(route.distance/1000).toFixed(1).replace('.',','); const min=Math.max(1,Math.round(route.duration/60));
   window.driverRouteSummary={distanceKm:route.distance/1000,durationMin:min,label};
   if(info)info.innerHTML='Rota até '+escapeHtml(label)+': <b>'+km+' km</b> • <b>'+min+' min</b> · '+(result.traffic?'trânsito considerado':'sem dados de trânsito ao vivo');
   fitDriverRoute();
   return route;
 }catch(e){
   window.VaiNavigationEngine?.reset();
   if(window.driverRouteLayer)map.removeLayer(window.driverRouteLayer);
   window.driverRouteLayer=L.polyline([[startLat,startLng],[destLat,destLng]],{weight:5,dashArray:'8 8'}).addTo(map);
   window.driverRouteTarget=L.latLng(destLat,destLng);
   if(info)info.textContent='Rota detalhada indisponível. Mostrando direção direta até o passageiro.';
   fitDriverRoute();
   return null;
 }
}
function fitDriverRoute(){
 if(!map||!document.getElementById('home')?.classList.contains('active'))return;
 if(window.driverRouteLayer)map.fitBounds(window.driverRouteLayer.getBounds(),{padding:[45,45]});
 else if(window.driverRouteTarget)map.setView(window.driverRouteTarget,16);
}
function clearDriverRoute(){if(window.driverRouteLayer&&map){map.removeLayer(window.driverRouteLayer);window.driverRouteLayer=null}drawTrafficSegments(null,null);window.driverRouteTarget=null;window.driverRouteSteps=[];window.driverRouteSummary=null;window.VaiNavigationEngine?.reset();toggleDriverNavigation(false)}
function openExternalNavigation(){
 const ride=window.activeDriverRide;
 const target=ride?.status==='in_progress'&&ride.destination_lat!=null
  ?{lat:Number(ride.destination_lat),lng:Number(ride.destination_lng)}
  :ride?.origin_lat!=null?{lat:Number(ride.origin_lat),lng:Number(ride.origin_lng)}:window.driverRouteTarget;
 if(!target)return;
 const url='https://www.google.com/maps/dir/?api=1&destination='+encodeURIComponent(target.lat+','+target.lng)+'&travelmode=driving';
 window.open(url,'_blank');
}
window.connectDemo=connectDemo;

window.acceptTourCall=acceptTourCall;

const VAI_MAP_STYLE='https://tiles.openfreemap.org/styles/bright';
function addMapBase(target){
 return L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(target);
}
const destinationIcon=()=>L.divIcon({className:'vcMarker',html:'<div class="vcMarkerPin"><span></span></div>',iconSize:[40,48],iconAnchor:[20,44],popupAnchor:[0,-43]});
function setHomeMapState(state,message=''){
 const card=document.querySelector('#home .mapCard'),status=document.getElementById('mapStatus');
 if(card)card.dataset.mapState=state;
 if(status)status.textContent=message;
 const expand=document.getElementById('mapExpand');
 if(expand)expand.disabled=state==='error';
 const perspective=document.getElementById('mapPerspective');
 if(perspective)perspective.disabled=state!=='ready'||!map?.native;
 for(const button of [document.querySelector('#home .mapPick'),document.querySelector('#home .pickupEdit:not(#pickupReset)')]){
  if(button){button.disabled=state!=='ready';button.title=state==='error'?'Mapa indisponível; use a busca de endereço.':''}
 }
}
function startRasterMap(){
 if(!window.L)return false;
 try{
  if(map?.native){map.pending.length=0;map.gl.remove();map=null;me=null;accuracyCircle=null;pickupMarker=null;routeLine=null;}
  window.VaiMapEngine?.restoreLeaflet();
  const perspective=document.getElementById('mapPerspective');if(perspective)perspective.hidden=true;
  map=L.map('map',{zoomControl:false,preferCanvas:true,minZoom:3}).setView(petr,14);
  window.map=map;
  let tileErrors=0;
  const tiles=addMapBase(map);
  tiles.on('tileload',()=>{tileErrors=0;setHomeMapState('ready','');});
  tiles.on('tileerror',()=>{if(++tileErrors>=6)setHomeMapState('error','Os mapas não carregaram nesta conexão. A busca por endereço continua disponível.');});
  setTimeout(()=>{if(document.querySelector('#home .mapCard')?.dataset.mapState==='loading')setHomeMapState('error','Os mapas não carregaram nesta conexão. A busca por endereço continua disponível.')},14000);
  if(window.vaiLatestGps)updatePosition({coords:{latitude:window.vaiLatestGps.lat,longitude:window.vaiLatestGps.lng,accuracy:window.vaiLatestGps.accuracy}});
  return true;
 }catch(error){console.error('Falha no mapa básico',error);setHomeMapState('error','Mapa indisponível nesta conexão. A busca por endereço continua disponível.');return false}
}
function initMap(){
 setHomeMapState('loading','Carregando mapa…');
 try{
  if(window.maplibregl?.supported()&&window.VaiMapEngine){try{map=window.VaiMapEngine.create()}catch(error){console.warn('Mapa vetorial indisponível',error)}}
  if(map?.native){
   const vectorMap=map;
   vectorMap.onUnrecoverable=()=>{if(map===vectorMap)startRasterMap()};
   vectorMap.gl.once('load',()=>{if(map===vectorMap)setHomeMapState('ready','')});
   setTimeout(()=>{if(map===vectorMap&&!vectorMap.ready)startRasterMap()},10000);
  }
  if(!map&&window.L)startRasterMap();
  if(!map)setHomeMapState('error','Mapa indisponível nesta conexão. A busca por endereço continua disponível.');
  window.map=map;
  const tools=document.querySelector('.mapTools');if(tools&&window.L)L.DomEvent.disableClickPropagation(tools);
 }catch(error){
  console.error('Falha ao iniciar mapa',error);
  if(!startRasterMap())setHomeMapState('error','Mapa indisponível nesta conexão. A busca por endereço continua disponível.');
 }
 try{
  if(window.VAI_GEO||navigator.geolocation)watchId=(window.VAI_GEO||navigator.geolocation).watchPosition(updatePosition,failGPS,{enableHighAccuracy:true,maximumAge:5000,timeout:10000});
  else failGPS();
 }catch(error){failGPS(error)}
}
function toggleLargeMap(){
 if(!map){setHomeMapState('error','Mapa indisponível nesta conexão. A busca por endereço continua disponível.');return}
 const panel=document.querySelector('.mapCard'),button=document.getElementById('mapExpand');
 panel.classList.toggle('mapExpanded');const open=panel.classList.contains('mapExpanded');
 button.setAttribute('aria-label',open?'Fechar mapa ampliado':'Ampliar mapa');button.title=open?'Fechar mapa':'Ampliar mapa';
 document.body.classList.toggle('mapIsExpanded',open);
 setTimeout(()=>map?.invalidateSize?.(),260);
}
function toggleMapPerspective(){
 if(!map?.native||!map.ready)return;
 const button=document.getElementById('mapPerspective'),active=button?.getAttribute('aria-pressed')!=='true';
 map.gl.easeTo({pitch:active?53:0,bearing:active?-13:0,duration:800});
 if(button){button.setAttribute('aria-pressed',String(active));button.textContent=active?'3D':'2D';button.title=active?'Ver mapa plano':'Ver mapa em 3D'}
}
let driverNavigationActive=false;
let navigationVoiceEnabled=true,navigationLastSpoken='',navigationLastSpeechAt=0;
function toggleNavigationVoice(){
 navigationVoiceEnabled=!navigationVoiceEnabled;
 const button=document.getElementById('mapVoiceToggle');if(button){button.textContent=navigationVoiceEnabled?'🔊':'🔇';button.title=navigationVoiceEnabled?'Desativar voz':'Ativar voz';button.setAttribute('aria-label',button.title)}
 if(!navigationVoiceEnabled)window.speechSynthesis?.cancel();
}
window.VaiNavigationEngine=window.VaiNavigation?.create(async point=>{
 if(!window.driverRouteTarget||!map)return;
 const box=document.getElementById('driverNavInstruction');if(box)box.textContent='Recalculando rota…';
 await buildDriverRouteFrom(point.lat,point.lng,window.driverRouteTarget.lat,window.driverRouteTarget.lng,window.driverRouteSummary?.label||'Destino');
});
function toggleDriverNavigation(force){
 if(force&&activeVaiArea()!=='driver')return;
 driverNavigationActive=Boolean(force);
 const panel=document.querySelector('#home .searchPanel'),close=document.getElementById('mapNavClose'),guide=document.getElementById('driverNavGuidance'),voice=document.getElementById('mapVoiceToggle');
 if(panel)panel.dataset.navigation=driverNavigationActive?'driver':'off';
 if(close)close.hidden=!driverNavigationActive;
 if(guide)guide.hidden=!driverNavigationActive;
 if(voice)voice.hidden=!driverNavigationActive;
 if(!driverNavigationActive){window.speechSynthesis?.cancel();navigationLastSpoken=''}
 if(driverNavigationActive){tab('home',0);const p=window.vaiLatestGps;if(p)updateDriverGuidance({lat:p.lat,lng:p.lng,accuracy:p.accuracy});}
 else if(document.getElementById('home')?.classList.contains('active')&&window.activeDriverRide)tab('driver',2);
 setTimeout(()=>map?.invalidateSize?.(),250);
}
function updateDriverGuidance(point){
 if(!driverNavigationActive)return;
 const guide=window.VaiNavigationEngine?.update(point);
 const instruction=document.getElementById('driverNavInstruction'),distance=document.getElementById('driverNavDistance'),eta=document.getElementById('driverNavEta');
 if(!guide||guide.state==='gps-imprecise'){if(instruction)instruction.textContent='Aguardando GPS preciso e rota';return}
 if(instruction)instruction.textContent=guide.state==='off-route'?'Fora da rota · recalculando se persistir':guide.next;
 if(distance)distance.textContent=guide.maneuverMeters<1000?Math.round(guide.maneuverMeters)+' m':(guide.maneuverMeters/1000).toFixed(1).replace('.',',')+' km';
 if(eta)eta.textContent='Restam '+Math.max(1,guide.etaMinutes)+' min';
 if(navigationVoiceEnabled&&guide.state==='on-route'&&guide.maneuverMeters<250&&window.speechSynthesis&&window.SpeechSynthesisUtterance){
  const key=guide.next+'|'+(guide.maneuverMeters<65?'agora':'proximo');
  if(key!==navigationLastSpoken&&Date.now()-navigationLastSpeechAt>9000){
   try{window.speechSynthesis.cancel();const speech=new SpeechSynthesisUtterance((guide.maneuverMeters<65?'Agora, ':'Em '+Math.round(guide.maneuverMeters/10)*10+' metros, ')+guide.next.toLowerCase());speech.lang='pt-BR';window.speechSynthesis.speak(speech);navigationLastSpoken=key;navigationLastSpeechAt=Date.now()}catch(error){console.warn('Voz indisponível',error)}
  }
 }
 if(map?.native&&map.ready)map.gl.easeTo({center:[guide.snapped.lng,guide.snapped.lat],zoom:16.6,pitch:53,bearing:guide.bearing,duration:700});
 else map?.panTo?.([guide.snapped.lat,guide.snapped.lng],{animate:true});
}
function updatePosition(p){const lat=p.coords.latitude,lng=p.coords.longitude,acc=p.coords.accuracy||0;lastGpsError=null;window.vaiLatestGps={lat,lng,accuracy:acc};document.getElementById('gpsStatus').textContent='GPS ativo';document.getElementById('accuracy').textContent='± '+Math.round(acc)+' m';document.querySelector('#home .searchPanel')?.setAttribute('data-gps-state','ready');if(map&&window.L){if(!me)me=L.circleMarker([lat,lng],{radius:10,color:'#fff',fillColor:'#2b5fbd',fillOpacity:1,weight:3,className:'vcUserMarker'}).addTo(map).bindPopup('Você está aqui');else me.setLatLng([lat,lng]);if(!accuracyCircle)accuracyCircle=L.circle([lat,lng],{radius:acc,color:'#437bcc',fillColor:'#437bcc',fillOpacity:.08,weight:1}).addTo(map);else accuracyCircle.setLatLng([lat,lng]).setRadius(acc);if(!window.centered){map.setView([lat,lng],15);window.centered=true}}updateDriverGuidance({lat,lng,accuracy:acc,heading:Number.isFinite(p.coords.heading)?p.coords.heading:undefined});describePickup({lat,lng},false)}
function failGPS(error){lastGpsError=error?.code||null;document.getElementById('gpsStatus').textContent=lastGpsError===1?'GPS sem permissão':'GPS indisponível';document.getElementById('accuracy').textContent=lastGpsError===1?'Permita localização':lastGpsError===3?'GPS demorou a responder':'Sem localização';document.querySelector('#home .searchPanel')?.setAttribute('data-gps-state','error');const detail=document.getElementById('pickupDetail');if(detail&&!selectedPickup)detail.textContent=lastGpsError===1?'Permita a localização ou digite o ponto de partida.':'Digite o ponto de partida ou tente localizar novamente.'}
function locate(){if(me&&map)map.setView(me.getLatLng(),16);else (window.VAI_GEO||navigator.geolocation)?.getCurrentPosition(updatePosition,failGPS,{enableHighAccuracy:true,timeout:10000})}
function setPickupText(value){const label=document.getElementById('pickupLabel'),input=document.getElementById('originSearch');if(label)label.textContent=value;if(input&&document.activeElement!==input)input.value=value}
function setPickupFromSearch(place){if(!Number.isFinite(place?.lat)||!Number.isFinite(place?.lng))return false;selectedPickup={lat:place.lat,lng:place.lng};if(map&&window.L){if(pickupMarker)pickupMarker.setLatLng([place.lat,place.lng]);else pickupMarker=map.native?L.marker([place.lat,place.lng],{draggable:true,onDrag:p=>{selectedPickup=p;resetQuoteForPickup();describePickup(p,true)}}).addTo(map):L.circleMarker([place.lat,place.lng],{radius:11,color:'#fff',weight:3,fillColor:'#b68c51',fillOpacity:1}).addTo(map);map.setView([place.lat,place.lng],16)}setPickupText(place.name);document.getElementById('pickupDetail').textContent=place.address||'Partida escolhida na busca';document.getElementById('pickupReset').hidden=false;resetQuoteForPickup();return true}
let pickupReverseController=null,pickupReverseLast=0;
async function describePickup(point,manual){
 if(!point||(!manual&&selectedPickup)||!window.VaiCitySearch?.reverse)return;
 if(!manual&&Date.now()-pickupReverseLast<20000)return;
 pickupReverseLast=Date.now();pickupReverseController?.abort();pickupReverseController=new AbortController();
 const detail=document.getElementById('pickupDetail');
 if(detail)detail.textContent='Localizando o nome da rua…';
 try{const result=await window.VaiCitySearch.reverse(point,{signal:pickupReverseController.signal});
  if(!result||(!manual&&selectedPickup))throw new Error('no_address');
  setPickupText(result.label);
  if(detail)detail.textContent=result.area+(manual?' · arraste o pino para ajustar':' · localização pelo GPS');
 }catch(error){if(error.name==='AbortError')return;
  setPickupText(manual?'Ponto escolhido no mapa':'Sua localização atual');
  if(detail)detail.textContent=map?'Confira o pino no mapa antes de solicitar.':'Confira o endereço de partida antes de solicitar.';
 }
}
function resetQuoteForPickup(){quoteGeneration++;routeQuote=null;document.getElementById('routeQuote').style.display='none';const request=document.getElementById('requestRideButton');if(request){request.disabled=true;request.classList.remove('ready')}}
function goTo(lat,lng,name,details={}){selectedDestination={...details,name,lat,lng};resetQuoteForPickup();document.getElementById('dest').value=name;document.getElementById('dest').blur();hidePlaceSuggestions();window.VaiRecents?.add({name,lat,lng});window.VaiPlaceUI?.destinationSelected({name,lat,lng,address:details.address||details.area||'Petrópolis - RJ',category:details.category||'address'});if(map&&window.L){if(destinationMarker)destinationMarker.setLatLng([lat,lng]);else destinationMarker=L.marker([lat,lng],{icon:destinationIcon()}).addTo(map);destinationMarker.bindPopup('Destino: '+escapeHtml(name)).openPopup();map.setView([lat,lng],16)}setTimeout(()=>{if(document.getElementById('dest')?.value===name&&selectedDestination?.lat===lat&&selectedDestination?.lng===lng)calculateRouteQuote()},120)}
function resetPickup(){selectedPickup=null;if(pickupMarker&&map)map.removeLayer(pickupMarker);pickupMarker=null;setPickupText('Identificando sua localização…');describePickup(window.vaiLatestGps,false);document.getElementById('pickupReset').hidden=true;resetQuoteForPickup();document.getElementById('msg').textContent='Localização do GPS restaurada. Consulte a rota novamente.'}
function choosePickupOnMap(){
 if(!map||document.querySelector('#home .mapCard')?.dataset.mapState!=='ready'){document.getElementById('msg').textContent='Mapa indisponível agora. Digite o ponto de partida na busca acima.';return}
 cancelCitySearch();hidePlaceSuggestions();
 if(pendingMapSelection){map.off('click',pendingMapSelection);pendingMapSelection=null}
 document.getElementById('msg').textContent='Toque no ponto exato onde o motorista deve encontrar você. Evite marcar o outro lado da rua.';
 document.getElementById('map').scrollIntoView({behavior:'smooth',block:'center'});
 pendingMapSelection=event=>{
  const {lat,lng}=event.latlng;
  if(lat < -22.70||lat > -22.25||lng < -43.65||lng > -42.93){document.getElementById('msg').textContent='O ponto está fora da área atendida em Petrópolis. Toque em outro lugar no mapa.';return}
  map.off('click',pendingMapSelection);pendingMapSelection=null;
  selectedPickup={lat,lng};
  if(pickupMarker)pickupMarker.setLatLng([lat,lng]);else pickupMarker=map.native?L.marker([lat,lng],{draggable:true,onDrag:p=>{if(p.lat < -22.70||p.lat > -22.25||p.lng < -43.65||p.lng > -42.93){pickupMarker.setLatLng(selectedPickup);return}selectedPickup=p;resetQuoteForPickup();describePickup(p,true)}}).addTo(map):L.circleMarker([lat,lng],{radius:11,color:'#fff',weight:3,fillColor:'#b68c51',fillOpacity:1}).addTo(map);
  pickupMarker.bindPopup('Ponto de encontro escolhido').openPopup();
  setPickupText('Ponto escolhido no mapa');document.getElementById('originSearch').value='Ponto escolhido no mapa';describePickup({lat,lng},true);
  document.getElementById('pickupReset').hidden=false;resetQuoteForPickup();
  document.getElementById('msg').textContent='Ponto de encontro confirmado no mapa. Consulte a rota novamente antes de solicitar.';
 };
 map.on('click',pendingMapSelection);
}
function chooseDestinationOnMap(){
 if(!map||document.querySelector('#home .mapCard')?.dataset.mapState!=='ready'){document.getElementById('msg').textContent='Mapa indisponível agora. Use a busca de destinos acima.';return}
 const input=document.getElementById('dest');
 if(!input.value.trim()){input.focus();document.getElementById('msg').textContent='Digite o nome do destino antes de marcar o ponto no mapa.';return}
 cancelCitySearch();hidePlaceSuggestions();if(pendingMapSelection){map.off('click',pendingMapSelection);pendingMapSelection=null}
 document.getElementById('msg').textContent='Toque no ponto exato do destino no mapa. Você poderá conferir o marcador antes de calcular a rota.';
 document.getElementById('map').scrollIntoView({behavior:'smooth',block:'center'});
 pendingMapSelection=event=>{
  const {lat,lng}=event.latlng;
  if(lat < -22.70||lat > -22.25||lng < -43.65||lng > -42.93){document.getElementById('msg').textContent='O ponto está fora da área atendida em Petrópolis. Toque em outro lugar no mapa.';return}
  map.off('click',pendingMapSelection);pendingMapSelection=null;
  const name=input.value.trim();goTo(lat,lng,name);
  document.getElementById('msg').textContent='Ponto marcado no mapa. Confira o marcador e consulte a rota.';
 };map.on('click',pendingMapSelection);
}
const LOCAL_PLACES=window.VaiPlaces.places;
const foldPlace=window.VaiPlaces.fold;
function hidePlaceSuggestions(){window.VaiPlaceUI?.hide()}
function showRecentChoices(){window.VaiPlaceUI?.showRecent()}
function showPlaceChoices(places){window.VaiPlaceUI?.show(places)}
async function selectPlaceChoice(place){if(Number.isFinite(place.lat)&&Number.isFinite(place.lng)){goTo(place.lat,place.lng,place.name);return}const matches=await searchLocalMap(place.query||place.name,{hint:place.name});showPlaceChoices(matches)}
const citySearchCache=new Map();
function cancelCitySearch(){window.VaiPlaceUI?.cancel()}
async function fetchWithTimeout(url, options={}, timeoutMs=12000){
 const controller=new AbortController();
 const timer=setTimeout(()=>controller.abort(),timeoutMs);
 try{return await fetch(url,{...options,signal:controller.signal});}
 finally{clearTimeout(timer)}
}
async function geocodeDestination(name){
 const clean=String(name||'').trim();
 if(!clean)return null;
 if(selectedDestination && selectedDestination.name===clean)return selectedDestination;
 if(window.VaiPlaceUI){const choice=await window.VaiPlaceUI.resolve(clean);if(choice){selectedDestination=choice;return choice}return null;}
 const cached=citySearchCache.get(foldPlace(clean));
 let cityMatches=cached?.places||[];
 if(!cityMatches.length){
  try{cityMatches=await window.VaiCitySearch.search(clean)}catch(e){console.warn('[VaiComigo] endereço',e)}
 }
 if(!cityMatches.length&&/petropolis|petrópolis|rio de janeiro|,\s*rj\b/i.test(clean)){
  const shorter=clean.replace(/,?\s*(petrópolis|petropolis|rio de janeiro|rj)\b/ig,'').replace(/,\s*,/g,',').replace(/[\s,]+$/,'').trim();
  if(shorter.length>=3)try{cityMatches=await window.VaiCitySearch.search(shorter)}catch(e){console.warn('[VaiComigo] endereço simplificado',e)}
 }
 const exact=cityMatches.find(p=>foldPlace(p.name)===foldPlace(clean)&&(!/\d/.test(clean)||p.hasHouseNumber));
 if(exact){selectedDestination=exact;return exact}
 if(cityMatches.length){showPlaceChoices(cityMatches);document.getElementById('msg').textContent='Escolha o bairro, a rua ou o endereço correto na lista.';return null}
 const known=window.VaiPlaces.rank(clean).find(x=>foldPlace(x.name)===foldPlace(clean));
 if(known){
  if(Number.isFinite(known.lat)&&Number.isFinite(known.lng)){selectedDestination=known;return selectedDestination}
  let found=[];try{found=await searchLocalMap(known.query||known.name,{hint:known.name});if(!found.length&&known.query)found=await searchLocalMap(known.name,{hint:known.name})}catch(e){console.warn('[VaiComigo] place lookup',e)}
  if(found.length===1){selectedDestination={...found[0],name:known.name};return selectedDestination}
  if(found.length>1){showPlaceChoices(found);document.getElementById('msg').textContent='Escolha o ponto correto entre as opções locais.'}
  return null;
 }
 return null;
}
async function searchLocalMap(query,{hint=''}={}){
 const matches=await window.VaiCitySearch.search(query);
 if(!hint)return matches;
 const terms=foldPlace(hint).split(' ').filter(x=>x.length>2&&!['rodoviaria','terminal'].includes(x));
 return terms.length?matches.filter(x=>terms.some(term=>foldPlace(x.name+' '+x.area).includes(term))):matches;
}
async function calculateRouteQuote(){
 const msg=document.getElementById('msg');
 const destinationEl=document.getElementById('dest');
 const button=document.querySelector('button[onclick="calculateRouteQuote()"]');
 const destination=destinationEl?.value.trim()||'';
 const pickupAtStart=selectedPickup;
 if(!destination){if(msg)msg.innerHTML='<div class="msg">Informe o destino.</div>';return null;}
 resetQuoteForPickup();
 const generation=quoteGeneration;
 const ensureCurrent=()=>{if(generation!==quoteGeneration)throw new Error('stale_quote')};
 hidePlaceSuggestions();
 if(msg)msg.innerHTML='<div class="msg">⏳ Localizando você e preparando a rota…</div>';
 if(button){button.disabled=true;button.dataset.originalText=button.textContent;button.textContent='⏳ Calculando…';}
 try{
  const origin=selectedPickup||window.vaiLatestGps||await getPosition();
  ensureCurrent();
  if(!origin||!Number.isFinite(Number(origin.lat))||!Number.isFinite(Number(origin.lng)))throw new Error('gps');
  if(msg)msg.innerHTML='<div class="msg">🔎 Procurando o destino: <b>'+escapeHtml(destination)+'</b>…</div>';
  const target=await geocodeDestination(destination);
  ensureCurrent();
  if(!target){
   if(msg&&!document.getElementById('placeSuggestions')?.children.length)msg.innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318"><b>Destino não encontrado.</b><br>Tente outro nome ou um endereço em Petrópolis.</div>';
   return null;
  }
  if(msg)msg.innerHTML='<div class="msg">🗺️ Calculando a rota…</div>';
  const j=await requestNavigationRoute(origin,target);
  ensureCurrent();
  const route=j.route;
  if(!route)throw new Error('route_empty');
  if(destinationEl.value.trim()!==destination && destinationEl.value.trim()!==target.name)throw new Error('destination_changed');
  if(selectedPickup!==pickupAtStart)throw new Error('pickup_changed');
  const distanceKm=route.distance/1000, durationMin=route.duration/60;
  let fare=Math.max(10,6+distanceKm*2.4+durationMin*.35); fare=Math.round(fare*100)/100;
  routeQuote={origin,target,destinationInput:document.getElementById('dest').value.trim(),distanceKm,durationMin,fare,geometry:route.geometry,steps:route.legs?.[0]?.steps||[]};
  if(routeLine&&map)map.removeLayer(routeLine);
  if(map&&window.L&&document.querySelector('#home .mapCard')?.dataset.mapState==='ready'){
   try{
    routeLine=L.geoJSON(route.geometry,{style:{color:'#a47d46',weight:7,opacity:.94,lineCap:'round',lineJoin:'round'}}).addTo(map);
    map.fitBounds(routeLine.getBounds(),{padding:[24,24]});
    if(map.native){const coords=route.geometry?.coordinates||[];if(coords.length>2){const a=coords[0],b=coords[Math.min(12,coords.length-1)];const bearing=Math.atan2((b[0]-a[0])*Math.cos(a[1]*Math.PI/180),b[1]-a[1])*180/Math.PI;map.gl.once('moveend',()=>map.gl.easeTo({bearing,pitch:52,duration:1250}))}}
   }catch(drawError){console.warn('Não foi possível desenhar a rota no mapa',drawError)}
  }
  drawTrafficSegments(route,j.traffic);
  document.getElementById('routeQuote').style.display='block';
  document.getElementById('quoteMain').textContent=formatMoney(fare);
  document.getElementById('quoteDistance').textContent=distanceKm.toFixed(1).replace('.',',')+' km';
  document.getElementById('quoteDuration').textContent=Math.max(1,Math.round(durationMin))+' min';
  document.getElementById('quotePayment').textContent=paymentLabel(currentPaymentMethod());
  document.getElementById('quotePickup').textContent=!map?'Mapa indisponível: confira o endereço de partida e o destino antes de solicitar.':selectedPickup?'Partida: ponto escolhido no mapa. Confirme o marcador antes de solicitar.':Number(origin.accuracy)>100?'Seu GPS está impreciso (± '+Math.round(origin.accuracy)+' m). Ajuste o ponto de encontro no mapa.':'Partida: sua localização atual. Confira se o marcador está no lado certo da rua.';
  document.getElementById('quoteStatus').textContent=j.traffic?'Trânsito considerado':'Rota calculada';
  const request=document.getElementById('requestRideButton');if(request){request.disabled=false;request.classList.add('ready')}
  if(msg)msg.textContent='';
  document.getElementById('routeQuote')?.scrollIntoView({behavior:'smooth',block:'nearest'});
  return routeQuote;
 }catch(e){
  if(e?.message==='stale_quote'||generation!==quoteGeneration)return null;
  console.error('[VaiComigo] calculateRouteQuote',e);
  const text=e?.name==='AbortError'?'A rota demorou demais. Confira sua conexão e tente novamente.':e?.message==='gps'?lastGpsError===1?'Permita a localização no navegador ou ajuste o ponto de encontro no mapa.':lastGpsError===3?'O GPS demorou a responder. Tente novamente ou ajuste o ponto no mapa.':'Não foi possível obter sua localização. Ajuste o ponto de encontro no mapa.':e?.message==='pickup_changed'?'O ponto de encontro mudou. Consulte a rota novamente.':'Não foi possível calcular a rota agora. Confira sua conexão e tente novamente.';
  if(msg)msg.innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318"><b>Não foi possível calcular.</b><br>'+text+'<br><button class="btn secondary" style="margin-top:9px" onclick="calculateRouteQuote()">Tentar novamente</button></div>';
  return null;
 }finally{
  if(button&&generation===quoteGeneration){button.disabled=false;button.textContent='Consultar rota e valor ↗';}
 }
}
async function notifyRideDriversPush(rideId){
  if(!window.supabaseClient||!window.currentUser||!rideId)return;
  try{
    const {error}=await window.supabaseClient.functions.invoke('push-notify',{body:{action:'ride_request',ride_id:rideId}});
    if(error)console.warn('push-notify',error);
  }catch(e){console.warn('push-notify',e)}
}
async function enableDriverPush(){
  try{
    if(!window.supabaseClient){alert('Conecte sua conta primeiro.');return}
    const user=await ensureUser(true);
    if(!user)return;
    // A chave pública VAPID é configuração interna (js/config.js → vapidPublicKey); o usuário nunca precisa colar nada.
    const key=window.VAI_VAPID_PUBLIC_KEY||'';
    if(!key){
      console.error('[VaiComigo] vapidPublicKey ausente em js/config.js: alertas de corrida indisponíveis.');
      const st0=document.getElementById('driverPushStatus');
      if(st0)st0.textContent='Alertas de corrida ainda não estão disponíveis neste ambiente.';
      return;
    }
    await window.vaiComigoDriver?.subscribeWebPush(key.trim());
    const st=document.getElementById('driverPushStatus');
    const btn=document.getElementById('driverPushButton');
    if(st)st.textContent='✓ Alertas de corrida ativados para este dispositivo.';
    if(btn)btn.textContent='✓ Alertas ativados';
  }catch(e){
    const st=document.getElementById('driverPushStatus');
    if(st)st.textContent='Não foi possível ativar os alertas: '+String(e.message||e);
    console.warn('driver push',e);
  }
}
async function ride(){
  if(rideRequestPending)return;
  const request=document.getElementById('requestRideButton');if(request){request.disabled=true;request.classList.remove('ready')}
  document.getElementById('msg').innerHTML='<div class="msg">⏳ Calculando rota e tarifa…</div>';
  const user=await ensureUser(true);
  if(!user||!window.supabaseClient){document.getElementById('msg').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">Entre na sua conta para solicitar uma corrida.</div>';if(request&&routeQuote){request.disabled=false;request.classList.add('ready')}return}
  const destination=document.getElementById('dest').value.trim();
  if(!destination){document.getElementById('msg').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">Informe o destino antes de solicitar.</div>';return}
  const q=routeQuote && routeQuote.destinationInput===destination?routeQuote:await calculateRouteQuote();
  if(!q)return;
  if(request){request.disabled=true;request.classList.remove('ready')}
  rideRequestPending=true;
  try{
    const {data,error}=await window.supabaseClient.rpc('create_ride_with_destination',{
      p_origin_lat:q.origin.lat,p_origin_lng:q.origin.lng,p_destination_name:destination,
      p_destination_lat:q.target.lat,p_destination_lng:q.target.lng,
      p_distance_km:q.distanceKm,p_duration_min:q.durationMin,p_payment_method:currentPaymentMethod()
    });
    if(error)throw error;
    window.activeRide=data;subscribeRide(data.id);notifyRideDriversPush(data.id);
    document.getElementById('msg').innerHTML='<div class="msg"><b>✓ Solicitação enviada</b><br>Procurando motorista próximo de você…<br><strong>'+formatMoney(data.estimated_price??data.fare_estimate)+'</strong> • '+q.distanceKm.toFixed(1).replace('.',',')+' km</div>';
    document.getElementById('quoteMain').textContent=formatMoney(data.estimated_price??data.fare_estimate);
    showActiveRidePanel(data);
  }catch(error){
    const rejectedByServer=!!error?.code;
    document.getElementById('msg').innerHTML=rejectedByServer?'<div class="msg" style="background:#fff0f0;color:#b42318">Não foi possível solicitar a corrida.<br>'+escapeHtml(error.message||'Tente novamente.')+'</div>':'<div class="msg" style="background:#fff0f0;color:#b42318"><b>Não foi possível confirmar o pedido.</b><br>Abra Minhas viagens para verificar se a corrida foi criada antes de tentar novamente.</div>';
    if(rejectedByServer&&request&&routeQuote){request.disabled=false;request.classList.add('ready')}
  }finally{rideRequestPending=false}
}

async function getPosition(){
 return new Promise(resolve=>{
  lastGpsError=null;
  if(!(window.VAI_GEO||navigator.geolocation)) return resolve(null);
  (window.VAI_GEO||navigator.geolocation).getCurrentPosition(p=>resolve({lat:p.coords.latitude,lng:p.coords.longitude,accuracy:p.coords.accuracy}),error=>{lastGpsError=error?.code||null;resolve(null)},{enableHighAccuracy:true,timeout:10000,maximumAge:5000});
 });
}

// VaiComigo v35 — perfil público seguro do motorista
async function loadPublicDriverProfile(driverId){
  const box=document.getElementById('driverPublicCard');
  if(!box||!driverId||!window.supabaseClient)return;
  box.innerHTML='<div class="msg">🚗 Carregando dados do motorista…</div>';
  const {data,error}=await window.supabaseClient.rpc('get_public_driver_profile',{p_driver_id:driverId});
  if(error||!data?.length){box.innerHTML='';return;}
  const d=data[0];
  if(!d.approved){box.innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">O motorista não está disponível para esta corrida.</div>';return;}
  const initials=escapeHtml((d.full_name||'M').split(/\s+/).slice(0,2).map(x=>x[0]).join('').toUpperCase());
  const avatar=d.avatar_url?'<img src="'+escapeHtml(d.avatar_url)+'" alt="Foto do motorista">':initials;
  const vehicle=[d.vehicle_model,d.vehicle_color,d.vehicle_year].filter(Boolean).map(escapeHtml).join(' • ');
  const plate=d.vehicle_plate?'<span class="plate">'+escapeHtml(d.vehicle_plate)+'</span>':'';
  const rating=Number(d.rating||0).toFixed(1).replace('.',',');
  box.innerHTML='<div class="publicDriver"><div class="avatar">'+avatar+'</div><div class="publicDriverMain"><div class="publicDriverName">'+escapeHtml(d.full_name||'Motorista VaiComigo')+'</div><div class="publicDriverMeta">'+(vehicle||'Veículo cadastrado')+plate+'</div><div class="verified">✓ Motorista aprovado • ⭐ '+rating+' ('+Number(d.rating_count||0)+' avaliações)</div></div></div>';
}
function showDriverFound(){
  const r=window.activeRide||{};
  document.getElementById('msg').innerHTML='<div class="call"><div class="head"><b>🚗 Motorista encontrado</b><span class="status">Aceitou sua corrida</span></div><div style="color:#667085;font-size:13px">Confira os dados do motorista abaixo. A localização será atualizada em tempo real.</div><div class="mapAction"><button class="btn secondary" onclick="trackDriver()">📍 Acompanhar</button><button class="btn" onclick="tab(\'home\',0)">Voltar ao mapa</button></div></div>';
  if(r.driver_id)loadPublicDriverProfile(r.driver_id);
}

function subscribeRide(id){
 if(!window.supabaseClient)return;
 if(window.rideChannel) window.supabaseClient.removeChannel(window.rideChannel);
 window.rideChannel=window.supabaseClient.channel('ride-'+id)
 .on('postgres_changes',{event:'UPDATE',schema:'public',table:'rides',filter:'id=eq.'+id},async payload=>{
   const r=payload.new; window.activeRide=r;
   if(r.status==='accepted'){ showDriverFound(); if(r.driver_id) subscribeDriverLocation(r.driver_id); }
   if(r.status==='arriving'){ if(r.driver_id) subscribeDriverLocation(r.driver_id); document.getElementById('msg').innerHTML='<div class="call"><div class="head"><b>🚗 Motorista a caminho</b><span class="status">Em deslocamento</span></div><div style="color:#667085;font-size:13px">A localização do motorista está sendo atualizada em tempo real.</div><button class="btn" style="margin-top:10px" onclick="trackDriver()">Acompanhar no mapa</button></div>'; }
   if(r.status==='in_progress') document.getElementById('msg').innerHTML='<div class="msg">🚗 Corrida em andamento.</div>';
   if(r.status==='completed') stopDriverLocationTracking();
   if(r.status==='cancelled') stopDriverLocationTracking();
 }).subscribe();
}
function subscribeDriverLocation(driverId){
 if(!window.supabaseClient||!driverId||!window.activeRide?.id)return;
 stopDriverLocationTracking(false);
 const id=window.activeRide.id;
 window.supabaseClient.realtime.setAuth();
 window.driverLocationChannel=window.supabaseClient.channel('ride-location:'+id,{config:{private:true}})
  .on('broadcast',{event:'position'},message=>updateDriverMarker(message.payload))
  .subscribe(state=>{if(state==='SUBSCRIBED')refreshDriverSnapshot(id);else if(state==='CHANNEL_ERROR'||state==='TIMED_OUT')setDriverLocationStatus('Sinal interrompido · aguardando reconexão')});
 window.driverStaleTimer=setInterval(()=>{if(window.driverLastTimestamp&&Date.now()-window.driverLastTimestamp>45000)setDriverLocationStatus('Localização antiga · aguardando GPS do motorista')},10000);
 refreshDriverSnapshot(id);
}
async function refreshDriverSnapshot(id){const {data,error}=await window.supabaseClient.rpc('ride_driver_location',{p_ride_id:id});if(!error&&data&&window.activeRide?.id===id)updateDriverMarker(data)}
function setDriverLocationStatus(text){const el=document.getElementById('mapStatus');if(el)el.textContent=text}
let driverFollowActive=false,driverFollowLastFrame=0;
function followDriverPosition(point,heading){
 if(!driverFollowActive||!map||!point||!Number.isFinite(point.lat)||!Number.isFinite(point.lng))return;
 if(map.native&&map.ready){
  const options={center:[point.lng,point.lat],zoom:16.5,pitch:53,duration:650,essential:true};
  if(Number.isFinite(heading))options.bearing=heading;
  map.gl.easeTo(options);
 }else map.panTo?.([point.lat,point.lng],{animate:true,duration:.65});
}
function toggleDriverFollow(force){
 driverFollowActive=typeof force==='boolean'?force:!driverFollowActive;
 const panel=document.querySelector('#home .searchPanel'),button=document.getElementById('mapFollow');
 if(panel)panel.dataset.navigation=driverFollowActive?'active':'off';
 if(button)button.hidden=!driverFollowActive;
 if(driverFollowActive&&window.driverLiveMarker)followDriverPosition(window.driverLiveMarker.getLatLng(),Number(window.driverLastLocation?.heading));
 if(map) setTimeout(()=>map?.invalidateSize?.(),250);
}
function updateDriverMarker(d){
 if(!d||d.lat==null||d.lng==null||!Number.isFinite(Number(d.lat))||!Number.isFinite(Number(d.lng)))return;
 const timestamp=Date.parse(d.location_updated_at||d.updated_at||'');if(Number.isFinite(timestamp)&&Date.now()-timestamp>45000){setDriverLocationStatus('Última posição antiga · aguardando GPS do motorista');return}
 const sampleTime=Number.isFinite(timestamp)?timestamp:Date.now();
 if(Number.isFinite(timestamp)&&timestamp<=(window.driverLastTimestamp||0))return;
 window.driverLastTimestamp=sampleTime;setDriverLocationStatus('Motorista em tempo real');
 window.driverLastLocation=d;
 if(!map||!window.L)return;
 const target=L.latLng(Number(d.lat),Number(d.lng));
 if(!window.driverLiveMarker){
   window.driverLiveMarker=L.marker(target,{title:'Motorista VaiComigo',car:true}).addTo(map).bindPopup('🚗 Motorista VaiComigo');
   if(driverFollowActive)followDriverPosition({lat:target.lat,lng:target.lng},Number(d.heading));
 } else {
   const from=window.driverLiveMarker.getLatLng();
   animateDriverMarker(from,target,Math.min(3500,Math.max(650,sampleTime-(window.driverPreviousTimestamp||sampleTime))));
 }
 window.driverPreviousTimestamp=sampleTime;window.driverLiveMarker.setHeading?.(Number(d.heading)||0);
 window.driverLastLocation=d;
}
function animateDriverMarker(from,to,duration){
 if(window.driverAnimFrame)cancelAnimationFrame(window.driverAnimFrame);
 const start=performance.now();
 const tick=now=>{
   const t=Math.min(1,(now-start)/duration);
   const e=t*(2-t);
   const lat=from.lat+(to.lat-from.lat)*e,lng=from.lng+(to.lng-from.lng)*e;
   window.driverLiveMarker.setLatLng([lat,lng]);
   if(driverFollowActive&&now-driverFollowLastFrame>450){driverFollowLastFrame=now;followDriverPosition({lat,lng},Number.isFinite(Number(window.driverLastLocation?.heading))?Number(window.driverLastLocation.heading):undefined)}
   if(t<1)window.driverAnimFrame=requestAnimationFrame(tick);
 };
 window.driverAnimFrame=requestAnimationFrame(tick);
}
function trackDriver(){
 if(!map){document.getElementById('msg').textContent='Mapa indisponível. Os dados da corrida continuam sendo atualizados.';return}
 if(!window.driverLiveMarker){document.getElementById('msg').innerHTML='<div class="msg">Aguardando a primeira localização real do motorista…</div>';return;}
 if(map.native&&!map.followDragListener){map.gl.on('dragstart',()=>toggleDriverFollow(false));map.followDragListener=true}
 toggleDriverFollow(true);
 document.getElementById('msg').innerHTML='<div class="call"><div class="head"><b>🚗 Motorista a caminho</b><span class="status">GPS em tempo real</span></div><div style="color:#667085;font-size:13px">A posição do motorista é atualizada automaticamente conforme ele se desloca.</div></div>';
}
function stopDriverLocationTracking(removeMarker=true){
 toggleDriverFollow(false);
 if(window.driverLocationChannel&&window.supabaseClient){window.supabaseClient.removeChannel(window.driverLocationChannel);window.driverLocationChannel=null;}
 if(window.driverAnimFrame)cancelAnimationFrame(window.driverAnimFrame);
 if(window.driverStaleTimer){clearInterval(window.driverStaleTimer);window.driverStaleTimer=null;}
 window.driverLastTimestamp=0;window.driverPreviousTimestamp=0;setDriverLocationStatus('');
 if(removeMarker&&window.driverLiveMarker){map?.removeLayer(window.driverLiveMarker);window.driverLiveMarker=null;}
 const box=document.getElementById('driverPublicCard'); if(box) box.innerHTML='';
}
function tour(){
 document.getElementById('tourModal').classList.add('on');
 const d=new Date();d.setDate(d.getDate()+1);
 document.getElementById('date').value=d.toISOString().slice(0,10);
 updateTourSummary();
}
function closeTour(){document.getElementById('tourModal').classList.remove('on')}
async function shareActiveTrip(){
 const user=await ensureUser(true);
 if(!user||!window.supabaseClient){document.getElementById('shareResult').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">Conecte sua conta para compartilhar.</div>';return}
 const rideId=window.activeRide?.id||null;
 if(!rideId){document.getElementById('shareResult').innerHTML='<div class="msg">Solicite uma corrida primeiro para gerar um acompanhamento.</div>';return}
 const {data,error}=await window.supabaseClient.rpc('create_trip_share',{p_ride_id:rideId});
 if(error){document.getElementById('shareResult').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">Não foi possível gerar o compartilhamento.<br>'+escapeHtml(error.message||'Tente novamente.')+'</div>';return}
 const url=new URL(location.href);url.hash='share='+encodeURIComponent(data.token);
 document.getElementById('shareResult').innerHTML='<div class="msg"><b>✓ Link de acompanhamento criado</b><div class="shareBox" style="margin-top:8px">'+url+'</div><button class="btn" style="margin-top:8px" onclick="copyShareLink('+JSON.stringify(url)+')">Copiar link</button></div>';
}
async function copyShareLink(url){try{await navigator.clipboard.writeText(url);document.getElementById('shareResult').insertAdjacentHTML('beforeend','<div style="font-size:12px;margin-top:6px">✓ Link copiado.</div>')}catch(e){prompt('Copie o link:',url)}}
async function openSharedView(token){
 const modal=document.getElementById('sharedView'),box=document.getElementById('sharedContent'); if(!modal)return; modal.classList.add('on'); box.innerHTML='<p style="color:#667085">Carregando localização…</p>';
 const {data,error}=await window.supabaseClient.rpc('get_shared_trip',{p_token:token});
 if(error||!data){box.innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">Link inválido, expirado ou viagem encerrada.</div>';return}
 renderSharedTrip(data); window.sharedToken=token; if(window.sharedPoll)clearInterval(window.sharedPoll); window.sharedPoll=setInterval(async()=>{const r=await window.supabaseClient.rpc('get_shared_trip',{p_token:token});if(r.data)renderSharedTrip(r.data);},5000);
}
function renderSharedTrip(t){
 const status=({requested:'Procurando motorista',accepted:'Motorista encontrado',arriving:'Motorista a caminho',in_progress:'Viagem em andamento',completed:'Viagem concluída',cancelled:'Viagem cancelada'})[t.status]||t.status;
 document.getElementById('sharedContent').innerHTML='<div class="call"><b>VaiComigo</b><div style="margin-top:6px"><strong>'+status+'</strong></div><div style="color:#667085;font-size:13px;margin-top:5px">Destino: '+escapeHtml(t.destination_name||'Não informado')+'</div><div style="color:#667085;font-size:12px;margin-top:5px">Última atualização: '+new Date(t.updated_at).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit',second:'2-digit'})+'</div></div>';
 if(t.lat!=null&&t.lng!=null){if(!window.L){document.getElementById('sharedMap').textContent='Mapa indisponível nesta conexão. Informações da viagem acima continuam disponíveis.';return}if(!window.sharedMapObj){window.sharedMapObj=L.map('sharedMap',{zoomControl:false}).setView([t.lat,t.lng],15);addMapBase(window.sharedMapObj);window.sharedMarker=L.marker([t.lat,t.lng],{icon:destinationIcon()}).addTo(window.sharedMapObj);}else{window.sharedMapObj.setView([t.lat,t.lng]);window.sharedMarker.setLatLng([t.lat,t.lng]);}}
}
function closeSharedView(){document.getElementById('sharedView').classList.remove('on');if(window.sharedPoll)clearInterval(window.sharedPoll)}
function checkShareHash(){const m=location.hash.match(/^#share=(.+)$/);if(m&&window.supabaseClient)openSharedView(decodeURIComponent(m[1]))}

async function sos(){
 if(!window.supabaseClient){document.getElementById('msg').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318"><b>SOS indisponível</b><br>O VaiComigo está indisponível no momento.</div>';return}
 const user=await ensureUser(true); if(!user)return;
 const pos=await getPosition();
 const rideId=window.activeRide?.id||null;
 if(!pos){document.getElementById('msg').textContent='Não foi possível obter sua localização para registrar o SOS. Se houver perigo imediato, acione o serviço de emergência.';return}
 if(!confirm('Acionar o SOS agora? A ocorrência será registrada com sua localização.'))return;
 const {data,error}=await window.supabaseClient.rpc('create_sos_event',{p_ride_id:rideId,p_lat:pos.lat,p_lng:pos.lng,p_message:'SOS acionado pelo passageiro'});
 if(error){document.getElementById('msg').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318"><b>Não foi possível registrar o SOS.</b><br>'+String(error.message||'Tente novamente.')+'</div>';return}
 document.getElementById('msg').innerHTML='<div class="msg" style="background:#fff0f0;color:#991b1b"><b>🆘 SOS registrado</b><br>Localização enviada ao sistema de segurança.<br><span style="font-size:12px">Se houver risco imediato, procure também o serviço de emergência local.</span></div>';
}
function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function isAdmin(){
 if(!window.supabaseClient)return false;
 const user=await ensureUser(); if(!user)return false;
 const {data,error}=await window.supabaseClient.rpc('is_admin');
 return !error&&data===true;
}
async function refreshAdminEntry(){
 const entry=document.getElementById('adminEntry'),nav=document.getElementById('n4');
 if(entry)entry.style.display='none';
 if(nav)nav.style.display=activeVaiArea()==='admin'?'flex':'none';
 return activeVaiArea()==='admin'&&Boolean(window.currentUser)&&await isAdmin();
}
async function openAdmin(){if(!(await refreshAdminEntry()))return;tab('admin',4)}
function toggleAdminDetails(){
 const box=document.getElementById('adminContent'),button=document.getElementById('adminMoreToggle');
 const open=box?.dataset.details!=='open';if(box)box.dataset.details=open?'open':'closed';
 if(button){button.textContent=open?'Ocultar dados adicionais':'Ver mais dados da operação';button.setAttribute('aria-expanded',String(open));}
}
function adminStatus(v){return '<span class="adminBadge">'+escapeHtml(v||'—')+'</span>'}
async function loadAdminDashboard(){
 const guard=document.getElementById('adminGuard'),content=document.getElementById('adminContent'); if(!guard||!content)return;
 const ok=await refreshAdminEntry(); if(!ok){guard.className='msg adminDanger';guard.textContent='Acesso negado. Esta conta não é administradora.';content.style.display='none';return}
 guard.className='msg';guard.textContent='✓ Acesso administrativo autorizado.';content.style.display='flex';
 const {data,error}=await window.supabaseClient.rpc('admin_dashboard');
 if(error){guard.className='msg adminDanger';guard.innerHTML='<b>Não foi possível carregar o painel.</b><br><span style="font-size:12px">'+escapeHtml(error.message)+'</span>';return}
 const d=data||{};
 document.getElementById('aCompleted').textContent=d.completed_rides??0; document.getElementById('aActive').textContent=d.active_rides??0; document.getElementById('aTours').textContent=d.requested_tours??0; document.getElementById('aDrivers').textContent=d.available_drivers??0; document.getElementById('aUsers').textContent=d.users??0; document.getElementById('aGross').textContent=formatMoney(d.gross_completed||0); document.getElementById('adminCommission').value=d.commission_percent??20;
 const dl=d.drivers||[], rl=d.rides||[], tl=d.tours||[];
 document.getElementById('adminDriversList').innerHTML=dl.length?'<table class="adminTable"><tr><th>Motorista</th><th>Status</th><th>Documentos</th><th>Ação</th></tr>'+dl.map(x=>'<tr><td>'+escapeHtml(x.full_name||'Sem nome')+'<br><small>'+escapeHtml([x.vehicle_model,x.vehicle_plate].filter(Boolean).join(' • ')||'—')+'</small></td><td>'+adminStatus(x.status)+'</td><td>'+adminStatus(x.document_status||'pending')+'</td><td><button class="btn secondary" style="min-height:36px;padding:7px 9px" onclick="document.getElementById(&quot;adminDocumentsList&quot;).scrollIntoView({behavior:&quot;smooth&quot;})">Ver documentos</button> <button class="btn secondary" style="min-height:36px;padding:7px 9px;color:#b42318" onclick="adminReviewDriverStatus(\''+x.id+'\',\'rejected\')">Reprovar</button></td></tr>').join('')+'</table>':'<p style="color:#667085;font-size:13px">Nenhum motorista cadastrado.</p>';
 document.getElementById('adminRidesList').innerHTML=rl.length?'<table class="adminTable"><tr><th>Data</th><th>Status</th><th>Destino</th><th>Valor</th></tr>'+rl.map(x=>'<tr><td>'+escapeHtml(x.created_at?formatDateTime(x.created_at):'—')+'</td><td>'+adminStatus(x.status)+'</td><td>'+escapeHtml(x.destination_name||'—')+'</td><td>'+formatMoney(x.amount||0)+'</td></tr>').join('')+'</table>':'<p style="color:#667085;font-size:13px">Nenhuma corrida encontrada.</p>';
 document.getElementById('adminToursList').innerHTML=tl.length?'<table class="adminTable"><tr><th>Data</th><th>Status</th><th>Duração</th><th>Valor</th></tr>'+tl.map(x=>'<tr><td>'+escapeHtml(x.start_at?formatDateTime(x.start_at):'—')+'</td><td>'+adminStatus(x.status)+'</td><td>'+escapeHtml((x.duration_hours||0)+'h')+'</td><td>'+formatMoney(x.price||0)+'</td></tr>').join('')+'</table>':'<p style="color:#667085;font-size:13px">Nenhum Tour encontrado.</p>';
}

async function adminReviewDriverStatus(id,status){
 const ok=await isAdmin(); if(!ok){alert('Acesso negado.');return}
 const label=status==='approved'?'aprovar':'reprovar';
 if(!confirm('Deseja '+label+' este motorista?'))return;
 const {error}=await window.supabaseClient.rpc('admin_set_driver_document_status',{p_driver_id:id,p_status:status});
 if(error){alert('Não foi possível atualizar: '+error.message);return}
 loadAdminDashboard();
}
async function saveAdminCommission(){
 const ok=await isAdmin();if(!ok){alert('Acesso negado.');return} const v=Number(document.getElementById('adminCommission').value);if(!Number.isFinite(v)||v<0||v>100){alert('Informe uma comissão entre 0 e 100%.');return}
 const {data,error}=await window.supabaseClient.rpc('admin_set_commission',{p_percent:v});
 if(error){alert('Não foi possível salvar: '+error.message);return}
 document.getElementById('adminGuard').textContent='✓ Comissão atualizada para '+Number(data).toFixed(2)+'%.';loadAdminDashboard();
}
const VAI_ENTRY_KEY='vai_entry_role';
function activeVaiArea(){return document.body.dataset.entryRole||null}
function renderMode(){
 const area=activeVaiArea();appMode=area||'passenger';
 document.body.classList.toggle('vai-authenticated',Boolean(window.currentUser));
 const label=document.getElementById('modeLabel');if(label)label.textContent=area==='admin'?'Administração':area==='driver'?'Motorista':'Passageiro';
 const exit=document.getElementById('exitAreaButton');if(exit){exit.hidden=!area;exit.textContent=window.currentUser?'Sair da conta':'Voltar às áreas';}
 const name=document.getElementById('profileName');if(name&&!window.currentUser)name.textContent=area==='driver'?'Motorista VaiComigo':area==='admin'?'Administração VaiComigo':'Passageiro VaiComigo';
 const onboarding=document.getElementById('driverOnboarding');if(onboarding)onboarding.hidden=area!=='driver'||Boolean(window.currentUser);
 const welcome=document.getElementById('adminWelcome');if(welcome)welcome.hidden=area!=='admin'||Boolean(window.currentUser);
 const content=document.getElementById('adminContent');if(content && area==='admin'&&!window.currentUser)content.style.display='none';
 const guard=document.getElementById('adminGuard');if(guard&&area==='admin'&&!window.currentUser)guard.textContent='Entre com sua conta de diretor para continuar.';
 const nav=document.getElementById('n4');if(nav)nav.style.display=area==='admin'?'flex':'none';
 updateDriverJourney();
}
function updateDriverJourney(){
 const box=document.getElementById('driverJourneyStatus'),toggle=document.getElementById('driverToggle');
 if(!box||activeVaiArea()!=='driver')return;
 const registered=Boolean(window.appContext?.has_driver_profile),docs=window.appContext?.driver_document_status;
 if(toggle)toggle.disabled=!driverAvailable&&(!window.currentUser||!registered||docs!=='approved'||window.vaiIdentityApproved!==true||window.appContext?.driver_status==='suspended');
 const status=document.getElementById('driverStatus');if(status&&window.appContext?.driver_status==='suspended')status.textContent='Suspenso';
 if(!window.currentUser){box.textContent='Passo 1: entre ou crie sua conta.';return}
 if(!registered){box.textContent='Passo 2: preencha seus dados e os do veículo abaixo.';return}
 if(window.appContext?.driver_status==='suspended'){box.textContent='Conta suspensa: o diretor deve reativá-la na Administração. Envie CNH e CRLV abaixo e aguarde análise; confira também a identidade no Perfil.';return}
 if(docs==='rejected'){box.textContent='Seus documentos precisam de correção. Veja o motivo no Perfil e envie arquivos novos.';return}
 if(docs!=='approved'){box.textContent='Passo 3: envie CNH e CRLV e aguarde a análise. Confira sua identidade no Perfil.';return}
 if(window.vaiIdentityApproved!==true){box.textContent='Documentos do veículo aprovados. Verifique sua identidade no Perfil para receber corridas.';return}
 if(driverAvailable){box.textContent=window.VAI_NATIVE_APP?'Você está online. O Android mantém uma notificação de GPS; deixe a localização permitida e abra o app para aceitar chamadas.':'Você está online. Mantenha o GPS ativo para receber chamadas próximas.';return}
 box.textContent='Cadastro aprovado. Toque em Ficar disponível para receber corridas.';
}
window.updateDriverJourney=updateDriverJourney;
function enterVaiArea(area){
 if(!['driver','passenger','admin'].includes(area)||window.VAI_FIXED_ROLE&&area!==window.VAI_FIXED_ROLE)return;
 localStorage.setItem(VAI_ENTRY_KEY,area);document.body.dataset.entryRole=area;
 if(area==='passenger'||(area==='driver'&&window.currentUser))ensureVaiMapStarted();
 renderMode();tab(area==='admin'?'admin':area==='driver'?'driver':'home',area==='admin'?4:area==='driver'?2:0);
 if(area==='driver'&&window.currentUser){loadDriverProfileReal();loadMyDriverDocuments();loadDriverFinance();loadDriverEarnings();}
}
async function leaveVaiArea(){
 const buttons=document.querySelectorAll('button[onclick="leaveVaiArea()"]');buttons.forEach(button=>button.disabled=true);
 try{
  if(activeVaiArea()==='driver'&&driverAvailable){
   if(!(await window.vaiComigoDriver?.setAvailability(false))){alert('Não foi possível ficar offline. Verifique sua conexão antes de sair.');return}
  }
  if(window.supabaseClient||window.currentUser)await signOutVai();
  if(typeof toggleDriverNavigation==='function'&&driverNavigationActive)toggleDriverNavigation(false);
  localStorage.removeItem(VAI_ENTRY_KEY);localStorage.removeItem('vai_mode');
  delete document.body.dataset.entryRole;
  document.querySelectorAll('.page').forEach(el=>el.classList.remove('active'));
  document.querySelectorAll('nav button').forEach(el=>el.classList.remove('active'));
  renderMode();if(window.VAI_FIXED_ROLE)enterVaiArea(window.VAI_FIXED_ROLE);window.scrollTo(0,0);
 }catch(error){alert('Não foi possível encerrar a sessão. Tente novamente antes de entrar em outra conta.');console.error('Saída da conta',error)}
 finally{buttons.forEach(button=>button.disabled=false)}
}
async function switchMode(mode){
 if(mode===activeVaiArea())return;
 await leaveVaiArea();
}
async function loadAdminHealth(){
 const box=document.getElementById('adminHealth'); if(!box||!window.supabaseClient)return;
 const {data,error}=await window.supabaseClient.rpc('admin_system_health');
 if(error){box.innerHTML='<div class="msg adminDanger">Não foi possível carregar o diagnóstico operacional.</div>';return}
 const checks=[['Motoristas aprovados',data.approved_drivers],['Disponíveis',data.available_drivers],['Em corrida',data.busy_drivers],['Corridas ativas',data.active_rides],['Corridas aguardando >15 min',data.stale_requested_rides],['SOS abertos',data.open_sos],['Documentos pendentes',data.pending_documents],['Pagamentos pendentes',data.pending_payments]];
 box.innerHTML='<div class="metricGrid">'+checks.map(x=>'<div class="metric"><small>'+escapeHtml(x[0])+'</small><b>'+escapeHtml(x[1])+'</b></div>').join('')+'</div>';
}
function tab(id,n){
 const area=activeVaiArea();if(!area)return;
 const allowed=area==='admin'?(id==='admin'||id==='profile'):area==='driver'?(id==='driver'||id==='profile'||(id==='home'&&driverNavigationActive)):(id==='home'||id==='trips'||id==='profile');
 if(!allowed)return;
 const page=document.getElementById(id),button=document.getElementById('n'+n);if(!page||!button)return;
 document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));page.classList.add('active');
 document.querySelectorAll('nav button').forEach(x=>x.classList.remove('active'));button.classList.add('active');
 scrollTo(0,0);if(id==='trips'){loadTripHistory();loadMyTours()}if(id==='admin'&&window.currentUser)loadAdminDashboard();if(id==='driver'&&window.currentUser){loadMyDriverDocuments();refreshAppContext().then(renderMode)}
}
let vaiMapStarted=false;
function ensureVaiMapStarted(){
 if(vaiMapStarted)return;vaiMapStarted=true;
 try{initMap()}catch(error){
  console.error('Falha ao iniciar mapa',error);
  const status=document.getElementById('mapStatus');
  if(status)status.textContent='Mapa indisponível. Atualize o aplicativo para tentar novamente.';
  failGPS();
 }
}
window.addEventListener('load',async()=>{
  const savedArea=localStorage.getItem(VAI_ENTRY_KEY);
  if(window.VAI_FIXED_ROLE)enterVaiArea(window.VAI_FIXED_ROLE);
  else if(['passenger','driver','admin'].includes(savedArea))enterVaiArea(savedArea);else renderMode();
  if(window.supabaseClient){
    try{
      const {data}=await window.supabaseClient.auth.getSession();
      if(data?.session?.user){
        window.currentUser=data.session.user;
        await loadProfileRole();
        await refreshAppContext();
        const area=activeVaiArea(),admin=window.appContext?.is_admin===true||currentRole==='admin';
        const driver=window.appContext?.has_driver_profile===true||currentRole==='driver'||window.currentUser.user_metadata?.requested_area==='driver';
        if((area==='admin'&&!admin)||(area==='passenger'&&(admin||driver))||(area==='driver'&&!driver)){
          await rejectWrongArea('Esta conta pertence a outra área. Escolha a opção correta para entrar.');return;
        }
        await refreshAccountUI();renderMode();
        refreshAdminEntry();
        if(activeVaiArea()==='driver'){ensureVaiMapStarted();loadDriverProfileReal();loadMyDriverDocuments();loadDriverFinance();loadDriverEarnings();}if(activeVaiArea()==='admin')loadAdminDashboard();
        document.getElementById('connectionStatus').textContent='✓ Conta conectada ao VaiComigo.';
      }
    }catch(e){console.warn('session',e)}
  }
  setTimeout(checkShareHash,500);
});

/* ================= VaiComigo v31 — experiência de corrida ================= */
function v31RideStatus(status){return ({requested:'Procurando motorista',accepted:'Motorista encontrado',arriving:'Motorista a caminho',in_progress:'Corrida em andamento',completed:'Corrida concluída',cancelled:'Corrida cancelada'})[status]||'Atualizando corrida'}
function v31Money(v){return formatMoney(v==null?0:v)}
function renderActiveRidePanel(r){
  const box=document.getElementById('activeRidePanel'); if(!box)return;
  if(!r || ['completed','cancelled'].includes(r.status)){box.style.display='none';return}
  box.style.display='block';
  const eta=r.status==='requested'?'Buscando motorista…':r.status==='accepted'?'Motorista aceitou a corrida':r.status==='arriving'?'Chegando ao ponto de embarque':'Viagem em andamento';
  const action=r.status==='requested'
    ? '<button class="btn secondary" onclick="cancelActiveRide()">Cancelar solicitação</button>'
    : '<button class="btn" onclick="trackDriver()">📍 Acompanhar motorista</button>';
  box.innerHTML=`<div class="liveHead"><div class="liveIcon">${r.status==='in_progress'?'🚗':'🚕'}</div><div><div class="liveTitle">${v31RideStatus(r.status)}</div><div class="liveSub">${escapeHtml(r.destination_name||'Seu destino')}</div></div></div><div class="liveStatus"><i></i></div><div class="liveGrid"><div class="liveInfo"><small>Status</small><b>${eta}</b></div><div class="liveInfo"><small>Valor estimado</small><b>${v31Money(r.final_price ?? r.estimated_price)}</b></div></div><div class="mapAction">${action}<button class="btn secondary" onclick="shareActiveTrip()">🔗 Compartilhar</button></div><button class="btn" style="margin-top:8px;background:#fff0f0;color:#b42318;box-shadow:none" onclick="sos()">🆘 Emergência / SOS</button>`;
}
async function cancelActiveRide(){
  const r=window.activeRide;if(!r||!window.supabaseClient)return;
  if(!confirm('Cancelar esta solicitação de corrida?'))return;
  const {data,error}=await window.supabaseClient.rpc('cancel_ride',{p_ride_id:r.id});
  if(error){document.getElementById('msg').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">Não foi possível cancelar a corrida.</div>';return}
  window.activeRide=data||{...r,status:'cancelled'};renderActiveRidePanel(window.activeRide);document.getElementById('msg').innerHTML='<div class="msg">Corrida cancelada.</div>';
}
async function showPassengerCompletedRide(r){
  const box=document.getElementById('msg'); if(!box)return;
  const price=r.final_price ?? r.estimated_price;
  let rating=null;
  if(window.supabaseClient){const q=await window.supabaseClient.from('ride_ratings').select('rating,comment').eq('ride_id',r.id).maybeSingle();rating=q.data}
  if(rating){box.innerHTML='<div class="msg"><b>✓ Corrida concluída</b><br>'+v31Money(price)+'<br><span style="font-size:12px;color:#667085">Avaliação enviada: '+('★'.repeat(rating.rating))+'</span></div>';return}
  const stars=[1,2,3,4,5].map(n=>'<button class="star" id="star'+n+'" onclick="selectRideRating('+n+')">★</button>').join('');
  box.innerHTML='<div class="card" style="margin:10px 0 0;border:1px solid #dbe5f4"><b>Como foi sua corrida?</b><div class="ratingRow">'+stars+'</div><textarea id="rideRatingComment" placeholder="Comentário opcional" style="width:100%;min-height:70px;border:1px solid var(--line);border-radius:13px;padding:10px;font:inherit"></textarea><button class="btn" style="margin-top:9px" onclick="submitRideRating(\''+r.id+'\')">Enviar avaliação</button></div>';
}
let v31SelectedRating=0;
function selectRideRating(n){v31SelectedRating=n;for(let i=1;i<=5;i++){const e=document.getElementById('star'+i);if(e)e.classList.toggle('on',i<=n)}}
async function submitRideRating(id){
 if(!window.supabaseClient||!v31SelectedRating){document.getElementById('msg').innerHTML='<div class="msg">Escolha uma nota de 1 a 5.</div>';return}
 const comment=document.getElementById('rideRatingComment')?.value||'';
 const {data,error}=await window.supabaseClient.rpc('rate_completed_ride',{p_ride_id:id,p_rating:v31SelectedRating,p_comment:comment});
 if(error){document.getElementById('msg').innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">Não foi possível enviar a avaliação.<br><small>'+escapeHtml(error.message)+'</small></div>';return}
 document.getElementById('msg').innerHTML='<div class="msg"><b>⭐ Obrigado pela avaliação!</b><br>Seu feedback ajuda a melhorar o VaiComigo.</div>';v31SelectedRating=0;loadTripHistory();
}
async function v31RefreshActiveRide(){
 if(!window.supabaseClient||!window.currentUser)return;
 const {data}=await window.supabaseClient.from('rides').select('id,created_at,updated_at,status,destination_name,estimated_price,fare_estimate,final_price,origin_lat,origin_lng,driver_id,payment_status,payment_method,accepted_at,arrived_at,started_at,completed_at,cancelled_at').eq('passenger_id',window.currentUser.id).in('status',['requested','accepted','arriving','in_progress']).order('created_at',{ascending:false}).limit(1).maybeSingle();
 if(data){window.activeRide=data;renderActiveRidePanel(data);subscribeRide(data.id)}else renderActiveRidePanel(null);
}
const v31OldRide=ride;
ride=async function(){
 await v31OldRide();
 if(window.activeRide)renderActiveRidePanel(window.activeRide);
};
const v31OldSubscribeRide=subscribeRide;
subscribeRide=function(id){
 v31OldSubscribeRide(id);
 if(!window.supabaseClient||!id)return;
 if(window.v31RideChannel&&window.supabaseClient)window.supabaseClient.removeChannel(window.v31RideChannel);
 window.v31RideChannel=window.supabaseClient.channel('v31-passenger-ride-'+id).on('postgres_changes',{event:'UPDATE',schema:'public',table:'rides',filter:'id=eq.'+id},async payload=>{
   window.activeRide=payload.new;renderActiveRidePanel(payload.new);
   if(payload.new.status==='completed'){stopDriverLocationTracking();await showPassengerCompletedRide(payload.new);}
   if(payload.new.status==='cancelled'){stopDriverLocationTracking();document.getElementById('msg').innerHTML='<div class="msg">A corrida foi cancelada.</div>';}
 }).subscribe();
};
const v31OldConnect=connectDemo;
connectDemo=async function(){const r=await v31OldConnect();if(window.currentUser){setTimeout(v31RefreshActiveRide,250)}return r};
window.addEventListener('load',()=>setTimeout(v31RefreshActiveRide,700));

// Documentos são exibidos pelo status real do servidor. Reenvio só após reprovação ou vencimento.
window.driverDocumentReview={cnh:null,crlv:null};
function documentState(row){
 if(!row)return 'missing';
 if(row.status==='approved'&&row.expires_at&&row.expires_at<new Date().toISOString().slice(0,10))return 'expired';
 return row.status||'pending';
}
function renderDriverDocuments(rows){
 const box=document.getElementById('myDriverDocs');if(!box)return;
 const mostRecent={cnh:null,crlv:null};
 for(const row of rows||[]){if(['cnh','crlv'].includes(row.document_type)&&!mostRecent[row.document_type])mostRecent[row.document_type]=row;}
 window.driverDocumentReview=mostRecent;
 const profileStatus=document.getElementById('driverApproval');
 if(profileStatus&&window.appContext?.has_driver_profile){
   profileStatus.textContent=Object.values(mostRecent).some(row=>row?.status==='rejected')?'Corrigir documentos':Object.values(mostRecent).some(row=>row?.status==='pending')?'Em análise':window.appContext?.driver_document_status==='approved'?'Aprovado':'Aguardando documentos';
 }
 box.replaceChildren();
 for(const [type,title,field] of [['cnh','CNH','Cnh'],['crlv','CRLV','Crlv']]){
  const row=mostRecent[type],state=documentState(row),locked=state==='pending'||state==='approved';
  const send=document.getElementById('driverSend'+field),file=document.getElementById('doc'+field),expiry=document.getElementById('doc'+field+'Expiry');
  const label=document.getElementById('driverDoc'+field+'Status');
  if(send){send.disabled=locked;send.textContent=state==='rejected'||state==='expired'?'Enviar documento corrigido':'Enviar '+title;}
  if(file)file.disabled=locked;
  if(expiry)expiry.disabled=locked;
  const notes={missing:'Ainda não enviado. Selecione o arquivo e a validade.',pending:'Enviado. Aguardando análise do diretor.',approved:'Aprovado. Nenhum novo envio é necessário.',rejected:'Reprovado. Confira o motivo e envie um arquivo corrigido.',expired:'Vencido. Envie o documento atualizado.'};
  if(label)label.textContent=notes[state]||'Confira a análise deste documento.';
  if(!row)continue;
  const line=document.createElement('div');line.className='docRow';
  const info=document.createElement('div'),head=document.createElement('b');head.textContent=title;
  const name=document.createElement('div');name.className='mini';name.textContent=row.file_name+(row.expires_at?' · validade '+formatDate(row.expires_at):'');
  info.append(head,name);
  if(row.rejection_reason&&state==='rejected'){
   const reason=document.createElement('p');reason.className='mini';reason.textContent='Motivo: '+row.rejection_reason;info.append(reason);
  }
  const badge=document.createElement('span');badge.className='docStatus '+state;
  badge.textContent={pending:'Em análise',approved:'Aprovado',rejected:'Reprovado',expired:'Vencido'}[state]||state;
  line.append(info,badge);box.append(line);
 }
}
async function loadMyDriverDocuments(){
 const box=document.getElementById('myDriverDocs');if(!box||!window.supabaseClient||!window.currentUser)return;
 try{
  const {data,error}=await window.supabaseClient.rpc('get_my_driver_documents');
  if(error)throw error;
  renderDriverDocuments(data||[]);
 }catch(error){box.textContent='Não foi possível atualizar os documentos. Tente novamente.';}
}
async function uploadDriverDocument(type,inputId,expiryId){
 const user=await ensureUser(true);if(!user||!window.supabaseClient)return;
 const note=document.getElementById('driverJourneyStatus'),field=type==='cnh'?'Cnh':'Crlv';
 const button=document.getElementById('driverSend'+field),input=document.getElementById(inputId),file=input?.files?.[0];
 const state=documentState(window.driverDocumentReview?.[type]);
 if(state==='pending'||state==='approved'){if(note)note.textContent='Este documento já foi enviado. Aguarde a análise ou confira o resultado abaixo.';return;}
 if(!window.appContext?.has_driver_profile){if(note)note.textContent='Salve seus dados e os do veículo antes de enviar documentos.';return;}
 if(!file){if(note)note.textContent='Escolha a foto ou PDF da '+type.toUpperCase()+' antes de enviar.';return;}
 if(file.size>8*1024*1024||file.size===0){if(note)note.textContent='O arquivo deve ter entre 1 byte e 8 MB.';return;}
 const mime=file.type||({'jpg':'image/jpeg','jpeg':'image/jpeg','png':'image/png','pdf':'application/pdf'}[file.name.split('.').pop().toLowerCase()]);
 if(!['image/jpeg','image/png','application/pdf'].includes(mime)){if(note)note.textContent='Use uma imagem JPG/PNG ou PDF. Outros formatos não podem ser analisados.';return;}
 const expires=document.getElementById(expiryId)?.value||null;
 if(expires&&expires<new Date().toISOString().slice(0,10)){if(note)note.textContent='A validade informada já passou. Confira a data do documento.';return;}
 const ext={'image/jpeg':'jpg','image/png':'png','application/pdf':'pdf'}[mime];
 const path=user.id+'/'+type+'-'+crypto.randomUUID()+'.'+ext;
 if(button){button.disabled=true;button.textContent='Enviando…';}
 if(note)note.textContent='Enviando '+type.toUpperCase()+' de forma privada. Mantenha esta tela aberta.';
 try{
  const {error:up}=await window.supabaseClient.storage.from('driver-documents').upload(path,file,{contentType:mime,upsert:false});
  if(up)throw Error('Falha ao enviar o arquivo: '+up.message);
  const {error}=await window.supabaseClient.from('driver_documents').insert({driver_id:user.id,document_type:type,file_path:path,file_name:file.name,mime_type:mime,expires_at:expires,status:'pending'});
  if(error){await window.supabaseClient.storage.from('driver-documents').remove([path]).catch(()=>{});throw Error('Arquivo enviado, mas cadastro não concluído: '+error.message);}
  input.value='';await loadMyDriverDocuments();await refreshAppContext();renderMode();
  if(note)note.textContent=type.toUpperCase()+' recebido. Você não precisa reenviar enquanto estiver em análise.';
 }catch(error){if(note)note.textContent='Não foi possível enviar '+type.toUpperCase()+': '+(error.message||'tente novamente.');await loadMyDriverDocuments();}
 finally{if(button&&documentState(window.driverDocumentReview?.[type])!=='pending'&&documentState(window.driverDocumentReview?.[type])!=='approved'){button.disabled=false;button.textContent='Enviar '+type.toUpperCase();}}
}
function formatDate(v){try{return new Date(v+'T00:00:00').toLocaleDateString('pt-BR')}catch{return v}}
async function loadAdminDriverDocuments(){
 const box=document.getElementById('adminDocumentsList'); if(!box||!window.supabaseClient)return;
 const {data,error}=await window.supabaseClient.rpc('admin_driver_documents'); if(error){box.innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">'+escapeHtml(error.message)+'</div>';return}
 if(!data?.length){box.innerHTML='<div class="secureNote">Nenhum documento enviado.</div>';return}
 box.innerHTML=data.map(x=>`<div class="docAdmin"><div><b>${escapeHtml(x.driver_name||'Motorista')}</b><div class="mini">${escapeHtml(x.document_type.toUpperCase())} • ${escapeHtml(x.file_name)}${x.expires_at?' • vence '+formatDate(x.expires_at):''}</div><span class="docStatus ${x.status}">${x.status}</span></div><div class="docBtns"><button class="action" onclick="viewDriverDoc(${escapeHtml(JSON.stringify(x.file_path))})">Ver</button>${x.status==='pending'?`<button class="action" onclick="reviewDriverDoc('${x.id}','approved')">Aprovar</button><button class="action red" onclick="reviewDriverDoc('${x.id}','rejected')">Reprovar</button>`:''}</div></div>`).join('');
}
async function viewDriverDoc(path){const {data,error}=await window.supabaseClient.storage.from('driver-documents').createSignedUrl(path,300);if(error){alert(error.message);return}window.open(data.signedUrl,'_blank','noopener')}
async function reviewDriverDoc(id,status){let reason=null;if(status==='rejected'){reason=prompt('Motivo da reprovação:');if(reason===null)return;reason=reason.trim();if(!reason){alert('Informe o motivo da reprovação para orientar o motorista.');return}}const {error}=await window.supabaseClient.rpc('admin_review_driver_document',{p_document_id:id,p_status:status,p_reason:reason});if(error){alert(error.message);return}await loadAdminDriverDocuments();await loadAdminDashboard();alert(status==='approved'?'Documento aprovado.':'Documento reprovado.');}

// ===== V37 — Central de Operações =====
async function loadAdminOperations(){
  const guard=document.getElementById('adminGuard');
  if(!guard||!window.supabaseClient)return;
  const ok=await isAdmin();
  if(!ok){guard.innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318"><b>Acesso negado</b><br>Esta conta não possui perfil administrativo.</div>';return;}
  document.getElementById('adminContent').style.display='flex';
  guard.innerHTML='<div class="msg">✓ Conta administrativa autorizada.</div>';
  const {data,error}=await window.supabaseClient.rpc('admin_operations_dashboard');
  if(error){guard.innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">'+escapeHtml(error.message)+'</div>';return;}
  const d=data||{};
  const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v;};
  set('aCompleted',d.completed_rides??0);set('aActive',d.active_rides??0);set('aTours',d.requested_tours??0);set('aDrivers',d.available_drivers??0);set('aUsers',d.users??0);set('aGross','R$ '+Number(d.gross_completed||0).toFixed(2).replace('.',','));set('aSOS',d.open_sos??0);set('aPendingPay',d.pending_payments??0);set('aPendingDocs',d.pending_documents??0);
  const comm=document.getElementById('adminCommission');if(comm)comm.value=d.commission_percent??20;
  renderAdminDriversOps(d.drivers||[]);renderAdminRidesOps(d.rides||[]);renderAdminSos(d.sos||[]);renderAdminPayments(d.payments||[]);
}
function renderAdminDriversOps(rows){const b=document.getElementById('adminDriversList');if(!b)return;if(!rows.length){b.innerHTML='<div class="msg">Nenhum motorista cadastrado.</div>';return}b.innerHTML=rows.map(x=>`<div class="docAdmin"><div><b>${escapeHtml(x.full_name||'Motorista')}</b><br><span class="mini">${escapeHtml(x.vehicle_model||'Veículo não informado')} • ${escapeHtml(x.vehicle_plate||'Sem placa')} • Conta: ${escapeHtml(x.status||'offline')} • Documentos: ${escapeHtml(x.document_status||'pendente')}</span></div><div class="docBtns"><button class="action" onclick="document.getElementById('adminDocumentsList').scrollIntoView({behavior:'smooth'})">Ver documentos</button>${x.status==='suspended'?`<button class="action" onclick="adminDriverStatus('${x.id}','offline')">Reativar cadastro</button>`:`<button class="action" onclick="adminDriverStatus('${x.id}','suspended')">Suspender</button>`}</div></div>`).join('')}
function renderAdminRidesOps(rows){const b=document.getElementById('adminRidesList');if(!b)return;if(!rows.length){b.innerHTML='<div class="msg">Nenhuma corrida.</div>';return}b.innerHTML=rows.map(x=>`<div class="docAdmin"><div><b>${escapeHtml(x.destination_name||'Destino não informado')}</b><br><span class="mini">${new Date(x.created_at).toLocaleString('pt-BR')} • ${escapeHtml(x.status)} • R$ ${Number(x.amount||0).toFixed(2).replace('.',',')} • pagamento: ${escapeHtml(x.payment_status||'pending')}</span></div><div class="docBtns">${['requested','accepted','arriving','in_progress','offered'].includes(x.status)?`<button class="action" onclick="adminCancelRide('${x.id}')">Cancelar</button>`:''}</div></div>`).join('')}
function renderAdminSos(rows){const b=document.getElementById('adminSosList');if(!b)return;if(!rows.length){b.innerHTML='<div class="msg">Nenhuma ocorrência registrada.</div>';return}b.innerHTML=rows.map(x=>`<div class="docAdmin"><div><b>🚨 ${escapeHtml(x.status)}</b><br><span class="mini">${new Date(x.created_at).toLocaleString('pt-BR')} • ${Number(x.lat).toFixed(5)}, ${Number(x.lng).toFixed(5)}<br>${escapeHtml(x.message||'Sem mensagem')}</span></div><div class="docBtns">${x.status==='open'?`<button class="action" onclick="adminSos('${x.id}','acknowledged')">Assumir</button>`:''}${x.status!=='closed'?`<button class="action" onclick="adminSos('${x.id}','closed')">Encerrar</button>`:''}</div></div>`).join('')}
function renderAdminPayments(rows){const b=document.getElementById('adminPaymentsList');if(!b)return;if(!rows.length){b.innerHTML='<div class="msg">Nenhum pagamento registrado.</div>';return}b.innerHTML=rows.map(x=>`<div class="docAdmin"><div><b>R$ ${Number(x.amount||0).toFixed(2).replace('.',',')}</b><br><span class="mini">${escapeHtml(x.method)} • ${escapeHtml(x.status)} • ${escapeHtml(x.provider||'aguardando provedor')}<br>${new Date(x.created_at).toLocaleString('pt-BR')}</span></div><span class="adminBadge">${escapeHtml(x.status)}</span></div>`).join('')}
async function adminSos(id,status){const {error}=await window.supabaseClient.rpc('admin_resolve_sos',{p_sos_id:id,p_status:status});if(error){alert(error.message);return}await loadAdminOperations();await loadAdminDashboard()}
async function adminCancelRide(id){if(!confirm('Cancelar esta corrida pelo painel administrativo?'))return;const {error}=await window.supabaseClient.rpc('admin_cancel_ride',{p_ride_id:id});if(error){alert(error.message);return}await loadAdminOperations();await loadAdminDashboard()}
async function adminDriverStatus(id,status){if(!confirm(status==='suspended'?'Suspender este motorista?':'Reativar este cadastro? O motorista só ficará online após a aprovação de identidade, CNH e CRLV.'))return;const {error}=await window.supabaseClient.rpc('admin_set_driver_status',{p_driver_id:id,p_status:status});if(error){alert(error.message);return}await loadAdminOperations();await loadAdminDashboard()}
const _oldLoadAdminDashboard=window.loadAdminDashboard;
window.loadAdminDashboard=async function(){await loadAdminOperations(); if(typeof loadAdminDriverDocuments==='function') await loadAdminDriverDocuments();};

/* ===== V39 — Suporte e atendimento ===== */
function v39SupportShell(){
  if(document.getElementById('supportCard')) return;
  const home=document.getElementById('home');
  if(home){
    const c=document.createElement('div'); c.className='card'; c.id='supportCard';
    c.innerHTML='<div class="head"><h3 style="margin:0">🆘 Ajuda e suporte</h3><span class="status">Atendimento</span></div><p class="mini">Teve um problema com uma corrida, pagamento ou motorista? Abra um chamado e acompanhe a resposta aqui.</p><button class="btn" onclick="openSupportModal()">Abrir atendimento</button><div id="mySupportList" style="margin-top:10px"></div>';
    home.appendChild(c);
  }
  if(document.getElementById('adminContent') && !document.getElementById('adminSupportCard')){
    const admin=document.getElementById('adminContent'); const c=document.createElement('div'); c.className='card adminSecondary'; c.id='adminSupportCard';
    c.innerHTML='<div class="head"><h3 style="margin:0">🎧 Atendimento</h3><button class="btn secondary" style="width:auto;padding:8px 12px" onclick="loadAdminSupport()">Atualizar</button></div><div id="adminSupportSummary" class="adminGrid"></div><div id="adminSupportList">Carregando…</div>';
    admin.appendChild(c);
  }
  if(!document.getElementById('supportModal')){
    const m=document.createElement('div'); m.id='supportModal'; m.className='modal'; m.innerHTML='<div class="sheet"><div class="head"><h2>🆘 Atendimento</h2><button onclick="closeSupportModal()">×</button></div><label>Categoria</label><select id="supportCategory"><option value="ride">Corrida</option><option value="payment">Pagamento</option><option value="driver">Motorista</option><option value="safety">Segurança</option><option value="account">Conta</option><option value="tour">Tour</option><option value="other">Outro</option></select><label>Assunto</label><input id="supportSubject" placeholder="Ex.: cobrança incorreta"><label>Mensagem</label><textarea id="supportBody" rows="5" placeholder="Conte o que aconteceu"></textarea><label>Prioridade</label><select id="supportPriority"><option value="normal">Normal</option><option value="high">Alta</option><option value="urgent">Urgente</option></select><button class="btn" onclick="createSupportTicketUI()">Enviar chamado</button><div id="supportMsg" class="secureNote"></div></div></div>';
    document.body.appendChild(m);
  }
}
function openSupportModal(){v39SupportShell();document.getElementById('supportModal').classList.add('on')}
function closeSupportModal(){document.getElementById('supportModal')?.classList.remove('on')}
async function createSupportTicketUI(){
 const user=await ensureUser(); if(!user||!window.supabaseClient)return;
 const subject=document.getElementById('supportSubject').value.trim(),body=document.getElementById('supportBody').value.trim();
 const msg=document.getElementById('supportMsg'); if(subject.length<3||body.length<3){msg.textContent='Preencha assunto e mensagem.';return}
 const {error}=await window.supabaseClient.rpc('create_support_ticket',{p_category:document.getElementById('supportCategory').value,p_subject:subject,p_body:body,p_priority:document.getElementById('supportPriority').value,p_ride_id:window.activeRide?.id||null});
 if(error){msg.textContent=error.message;return} msg.textContent='Chamado enviado. O atendimento aparecerá no seu histórico.'; document.getElementById('supportSubject').value='';document.getElementById('supportBody').value=''; await loadMySupportTickets(); setTimeout(closeSupportModal,700)
}
async function loadMySupportTickets(){
 v39SupportShell(); const box=document.getElementById('mySupportList'); if(!box)return; const user=await ensureUser(); if(!user||!window.supabaseClient){box.innerHTML='<div class="secureNote">Entre na sua conta para ver atendimentos.</div>';return}
 const {data,error}=await window.supabaseClient.rpc('my_support_tickets'); if(error){box.innerHTML='<div class="secureNote">Não foi possível carregar os chamados.</div>';return}
 box.innerHTML=!data?.length?'<div class="secureNote">Nenhum atendimento aberto ou anterior.</div>':data.slice(0,5).map(t=>`<button class="action" style="display:block;width:100%;text-align:left;margin-top:6px" onclick="openSupportTicket('${t.id}')"><b>${escapeHtml(t.subject)}</b><br><span class="mini">${escapeHtml(t.status)} • ${escapeHtml(t.priority)} • ${t.message_count} mensagens</span></button>`).join('');
}
async function openSupportTicket(id){
 const {data,error}=await window.supabaseClient.rpc('support_ticket_messages',{p_ticket_id:id}); if(error){alert(error.message);return}
 const html=(data||[]).map(m=>`<div class="msg" style="margin:6px 0"><b>${m.is_admin?'Atendimento VaiComigo':'Você'}</b><br>${escapeHtml(m.body)}<div class="mini">${new Date(m.created_at).toLocaleString('pt-BR')}</div></div>`).join('');
 const body=prompt('Histórico do atendimento:\n\n'+(data||[]).map(m=>(m.is_admin?'Atendimento':'Você')+': '+m.body).join('\n\n')+'\n\nDigite uma nova mensagem ou deixe vazio:');
 if(body?.trim()){const r=await window.supabaseClient.rpc('add_support_message',{p_ticket_id:id,p_body:body.trim()});if(r.error)alert(r.error.message);else loadMySupportTickets()}
}
async function loadAdminSupport(){
 if(!window.supabaseClient||!(await isAdmin()))return; v39SupportShell();
 const {data,error}=await window.supabaseClient.rpc('admin_support_dashboard'); const box=document.getElementById('adminSupportList'),sum=document.getElementById('adminSupportSummary');
 if(error){if(box)box.innerHTML='<div class="msg" style="background:#fff0f0;color:#b42318">'+escapeHtml(error.message)+'</div>';return}
 sum.innerHTML=`<div class="metric"><small>Abertos</small><b>${data.open||0}</b></div><div class="metric"><small>Em atendimento</small><b>${data.in_progress||0}</b></div><div class="metric"><small>Urgentes</small><b>${data.urgent||0}</b></div>`;
 box.innerHTML=(data.tickets||[]).length?(data.tickets||[]).map(t=>`<div class="docAdmin"><div><b>${escapeHtml(t.subject)}</b><br><span class="mini">${escapeHtml(t.user_name||'Usuário')} • ${escapeHtml(t.category)} • ${escapeHtml(t.priority)} • ${t.message_count} mensagens</span><br><span class="docStatus ${t.status}">${escapeHtml(t.status)}</span></div><div class="docBtns"><button class="action" onclick="adminSupportStatus('${t.id}','in_progress')">Assumir</button><button class="action" onclick="adminSupportStatus('${t.id}','waiting_user')">Responder</button><button class="action" onclick="adminSupportStatus('${t.id}','resolved')">Resolver</button></div></div>`).join(''):'<div class="msg">Nenhum chamado pendente.</div>';
}
async function adminSupportStatus(id,status){const r=await window.supabaseClient.rpc('admin_update_support_ticket',{p_ticket_id:id,p_status:status});if(r.error){alert(r.error.message);return}await loadAdminSupport()}
const _v39oldLoad=window.loadAdminDashboard; window.loadAdminDashboard=async function(){if(_v39oldLoad)await _v39oldLoad();await loadAdminSupport()};
window.addEventListener('load',()=>setTimeout(()=>{v39SupportShell();loadMySupportTickets().catch(()=>{});},900));


/* ===== V40 — Notificações ===== */
function v40NotificationShell(){
 if(document.getElementById('v40NotifPanel'))return;
 const panel=document.createElement('div');panel.id='v40NotifPanel';panel.className='v40NotifPanel';panel.setAttribute('role','dialog');panel.setAttribute('aria-label','Notificações');panel.setAttribute('aria-modal','false');panel.innerHTML='<div class="head"><b>Notificações</b><div class="v40NotifActions"><button id="v40MarkAll" class="action" type="button" onclick="markAllV40Notifications()">Marcar todas</button><button class="v40NotifClose" type="button" aria-label="Fechar notificações" onclick="closeV40Notifications()">×</button></div></div><div id="v40NotifList"><div class="secureNote">Entre na conta para ver suas notificações.</div></div><div class="v40NotifPrefs"><label><input id="v40PushToggle" type="checkbox" onchange="toggleV40Push(this.checked)"> Alertas neste aparelho</label><div id="v40PushStatus" class="mini"></div></div>';document.body.appendChild(panel);
 if(window.VAI_NATIVE_APP&&window.VAI_FIXED_ROLE!=='driver')panel.querySelector('.v40NotifPrefs').style.display='none';
 document.addEventListener('pointerdown',event=>{if(panel.classList.contains('on')&&!panel.contains(event.target)&&!document.getElementById('v40NotifButton')?.contains(event.target))closeV40Notifications()});
 document.addEventListener('keydown',event=>{if(event.key==='Escape')closeV40Notifications()});
}
function closeV40Notifications(){const panel=document.getElementById('v40NotifPanel');panel?.classList.remove('on');document.getElementById('v40NotifButton')?.setAttribute('aria-expanded','false')}
function toggleV40Notifications(){
 v40NotificationShell();const panel=document.getElementById('v40NotifPanel');panel.classList.toggle('on');
 document.getElementById('v40NotifButton')?.setAttribute('aria-expanded',String(panel.classList.contains('on')));
 if(panel.classList.contains('on'))loadV40Notifications();
}
async function loadV40Notifications(){
 v40NotificationShell(); const box=document.getElementById('v40NotifList'); if(!box)return; const user=window.currentUser;
 const toggle=document.getElementById('v40PushToggle'),markAll=document.getElementById('v40MarkAll'),status=document.getElementById('v40PushStatus');
 if(toggle)toggle.disabled=!user;
 if(markAll)markAll.disabled=!user;
 if(!user){box.innerHTML='<div class="secureNote">Entre na conta para ver suas notificações.</div>';if(toggle)toggle.checked=false;if(status)status.textContent='Entre na conta para ativar os alertas de viagens neste aparelho.';return}
 if(!window.supabaseClient){box.innerHTML='<div class="secureNote">Conectando às notificações...</div>';return}
 const {data,error}=await window.supabaseClient.from('notifications').select('id,type,title,body,data,read_at,created_at').eq('user_id',user.id).order('created_at',{ascending:false}).limit(30);
 if(error){box.innerHTML='<div class="secureNote">Não foi possível carregar as notificações.</div>';return}
 const unread=(data||[]).filter(x=>!x.read_at).length;const count=document.getElementById('v40NotifCount');if(count){count.textContent=unread;count.style.display=unread?'block':'none'}
 box.innerHTML=(data||[]).length?(data||[]).map(n=>`<button class="v40NotifItem ${n.read_at?'':'unread'}" style="display:block;width:100%;text-align:left;border:0" onclick="readV40Notification('${n.id}')"><b>${escapeHtml(n.title)}</b><br><span class="mini">${escapeHtml(n.body)}</span><br><span class="mini">${new Date(n.created_at).toLocaleString('pt-BR')}</span></button>`).join(''):'<div class="secureNote">Você está em dia. Nenhuma notificação.</div>';
 const {data:p}=await window.supabaseClient.from('notification_preferences').select('push_enabled').eq('user_id',user.id).maybeSingle(); const t=document.getElementById('v40PushToggle');if(t)t.checked=window.VAI_NATIVE_APP?!!localStorage.getItem('vai_native_push_token'):!!p?.push_enabled&&'Notification' in window&&Notification.permission==='granted'&&!!window.VAI_VAPID_PUBLIC_KEY;
 if(status)status.textContent=window.VAI_NATIVE_APP?(t?.checked?'Alertas Android ativados neste aparelho.':'Ative para receber alertas Android quando o app estiver fechado.'):!window.VAI_VAPID_PUBLIC_KEY?'Alertas com o app fechado aguardam a configuração do serviço de envio.':t?.checked?'Alertas deste aparelho ativados.':'Ative para receber alertas mesmo com o app fechado.';
}
async function readV40Notification(id){if(!window.supabaseClient)return;await window.supabaseClient.rpc('mark_notification_read',{p_id:id});await loadV40Notifications()}
async function markAllV40Notifications(){if(!window.supabaseClient||!window.currentUser)return;const {error}=await window.supabaseClient.rpc('mark_all_notifications_read');if(error){const status=document.getElementById('v40PushStatus');if(status)status.textContent='Não foi possível marcar as notificações: '+error.message;return}await loadV40Notifications()}
async function setupV40Realtime(){
 if(!window.supabaseClient||!window.currentUser)return; const uid=window.currentUser.id;
 if(window.v40NotifChannel)window.supabaseClient.removeChannel(window.v40NotifChannel);
 window.v40NotifChannel=window.supabaseClient.channel('v40-notifications-'+uid).on('postgres_changes',{event:'INSERT',schema:'public',table:'notifications',filter:'user_id=eq.'+uid},payload=>{loadV40Notifications();showV40LocalNotification(payload.new.title,payload.new.body)}).subscribe();
}
async function showV40LocalNotification(title,body){
 try{if('Notification' in window && Notification.permission==='granted'){const reg=await navigator.serviceWorker?.ready;if(reg?.showNotification)await reg.showNotification(title,{body,icon:'./icon.svg',tag:'vai-comigo'});else new Notification(title,{body})}}catch(e){}
}
async function toggleV40Push(enabled){
 const status=document.getElementById('v40PushStatus'),toggle=document.getElementById('v40PushToggle');
 if(window.VAI_NATIVE_APP){try{if(enabled)await window.VaiNativePush.register();else await window.VaiNativePush.unregister();if(status)status.textContent=enabled?'Alertas Android ativados neste aparelho.':'Alertas desativados neste aparelho.'}catch(e){if(toggle)toggle.checked=!enabled;if(status)status.textContent=e.message||'Não foi possível alterar os alertas.'}return}
 if(!enabled){try{await window.unsubscribeWebPush?.();if(window.currentUser&&window.supabaseClient)await window.supabaseClient.from('notification_preferences').upsert({user_id:window.currentUser.id,push_enabled:false});if(status)status.textContent='Alertas desativados neste aparelho.'}catch(e){if(status)status.textContent='Não foi possível desativar: '+e.message}return}
 if(!('Notification' in window)||!('serviceWorker' in navigator)||!('PushManager' in window)){if(status)status.textContent='Este navegador não suporta alertas do aplicativo.';if(toggle)toggle.checked=false;return}
 const permission=Notification.permission==='granted'?'granted':await Notification.requestPermission();
 if(permission!=='granted'){if(status)status.textContent='Permissão não concedida. Você pode alterá-la nas configurações do navegador.';if(toggle)toggle.checked=false;return}
 if(!window.currentUser){if(status)status.textContent='Entre na conta para receber alertas vinculados às suas viagens.';if(toggle)toggle.checked=false;return}
 const key=window.VAI_VAPID_PUBLIC_KEY;
 if(!key){if(status)status.textContent='Permissão concedida. Alertas com o app fechado aguardam ativação do serviço de envio.';if(toggle)toggle.checked=false;return}
 try{if(typeof window.subscribeWebPush!=='function')throw new Error('O serviço de alertas ainda está carregando. Tente novamente.');await window.subscribeWebPush(key);if(status)status.textContent='✓ Alertas deste aparelho ativados.';if(toggle)toggle.checked=true}
 catch(e){if(status)status.textContent='Permissão concedida, mas não foi possível registrar o aparelho: '+e.message;if(toggle)toggle.checked=false}
}
function showNotificationInvite(){
 if(window.VAI_NATIVE_APP)return;
 if(document.getElementById('notificationInvite')||!window.currentUser||!window.isSecureContext||!('Notification' in window)||Notification.permission!=='default')return;
 const next=Number(localStorage.getItem('vai_notification_invite_after')||0);if(Date.now()<next)return;
 const invite=document.createElement('div');invite.id='notificationInvite';invite.className='notificationInvite';invite.innerHTML='<div class="inviteIcon" aria-hidden="true">◉</div><div><b>Fique por dentro da sua viagem</b><p>Ative os alertas de chamadas e atualizações neste aparelho.</p><div class="inviteActions"><button type="button" onclick="activateNotificationInvite()">Ativar alertas</button><button type="button" onclick="dismissNotificationInvite()">Agora não</button></div></div>';document.body.appendChild(invite);
}
function dismissNotificationInvite(){document.getElementById('notificationInvite')?.remove();localStorage.setItem('vai_notification_invite_after',String(Date.now()+7*86400000))}
async function activateNotificationInvite(){
 if(!window.currentUser){dismissNotificationInvite();return}
 // A chamada ao navegador precisa ocorrer diretamente no clique, antes de qualquer await.
 let request;try{request=Notification.requestPermission()}catch(e){document.getElementById('notificationInvite')?.remove();return}
 document.getElementById('notificationInvite')?.remove();
 const permission=await request.catch(()=> 'denied');
 if(permission!=='granted')return;
 v40NotificationShell();document.getElementById('v40NotifPanel').classList.add('on');
 document.getElementById('v40NotifButton')?.setAttribute('aria-expanded','true');
 await toggleV40Push(true);
}
const _v40oldConnect=connectDemo;
connectDemo=async function(){const r=await _v40oldConnect();if(window.currentUser){v40NotificationShell();await loadV40Notifications();await setupV40Realtime();showNotificationInvite()}else if(document.getElementById('v40NotifPanel')){await loadV40Notifications();closeV40Notifications()}return r};
window.addEventListener('load',()=>setTimeout(()=>{v40NotificationShell();showNotificationInvite();if(window.currentUser){loadV40Notifications();setupV40Realtime()}},900));

const _v46oldLoadAdminDashboard=window.loadAdminDashboard;
window.loadAdminDashboard=async function(){if(_v46oldLoadAdminDashboard)await _v46oldLoadAdminDashboard();await window.loadAdminIdentityQueue?.()};
