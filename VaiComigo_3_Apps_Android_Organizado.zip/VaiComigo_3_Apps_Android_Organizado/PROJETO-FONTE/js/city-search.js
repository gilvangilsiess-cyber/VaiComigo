/* Busca geográfica: ruas, bairros, imóveis e lugares. Photon aceita pesquisa incremental.
   Endpoint configurável para substituir a instância de demonstração na produção. */
(function(root){
 'use strict';
 const BBOX=[-43.65,-22.70,-42.93,-22.25];
 const CENTRE={lat:-22.51,lng:-43.18};
 const fold=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ').trim();
 const isPetropolis=s=>/^(municipio de )?petropolis$/.test(fold(s));
 function mapFeature(feature){
  const p=feature?.properties||{},coords=feature?.geometry?.coordinates;
  const lng=Number(coords?.[0]),lat=Number(coords?.[1]);
  if(!Number.isFinite(lat)||!Number.isFinite(lng)||lat<BBOX[1]||lat>BBOX[3]||lng<BBOX[0]||lng>BBOX[2])return null;
  if(p.countrycode&&fold(p.countrycode)!=='br')return null;
  if(p.state&&!['rio de janeiro','rj'].includes(fold(p.state)))return null;
  const municipalities=[p.city,p.county,p.municipality].filter(Boolean);
  if(municipalities.length&&!municipalities.some(isPetropolis))return null;
  // Sem município cadastrado, somente resultados que citam Petrópolis explicitamente.
  if(!municipalities.length&&!isPetropolis(p.locality)&&!isPetropolis(p.district))return null;
  const name=String(p.name||p.street||p.district||p.locality||'').trim();
  if(!name)return null;
  const number=p.housenumber||p.house_number;
  const primary=p.street&&number?`${p.street}, ${number}`:name;
  const area=[p.district||p.locality,p.city||p.county,p.state].filter(Boolean).filter((x,i,a)=>i===0||fold(x)!==fold(a[i-1])).join(' · ')||'Petrópolis · RJ';
  const kind=number?'Endereço':p.type==='street'?'Rua':['district','locality'].includes(p.type)?'Bairro':'Local';
  return {name:primary,area,kind,lat,lng,source:'photon',hasHouseNumber:!!number,streetOnly:kind==='Rua',id:String(p.osm_type||'')+':'+String(p.osm_id||'')};
 }
 function makeUrl(query,endpoint){
  const base=endpoint||root.VAI_GEOCODER_URL||'https://photon.komoot.io/api/';
  const url=new URL(base,root.location?.href||'https://vaicomigo.invalid/');
  if(!/^https?:$/.test(url.protocol))throw new Error('invalid_geocoder');
  url.searchParams.set('q',query);url.searchParams.set('lat',String(CENTRE.lat));url.searchParams.set('lon',String(CENTRE.lng));url.searchParams.set('bbox',BBOX.join(','));url.searchParams.set('countrycode','BR');url.searchParams.set('limit','20');return url.toString();
 }
 function validOrigin(p){return p&&Number.isFinite(p.lat)&&Number.isFinite(p.lng)&&p.lat>=BBOX[1]&&p.lat<=BBOX[3]&&p.lng>=BBOX[0]&&p.lng<=BBOX[2]}
 function distanceKm(a,b){const lat=(a.lat+b.lat)/2*Math.PI/180;return Math.hypot((a.lat-b.lat)*111.2,(a.lng-b.lng)*111.2*Math.cos(lat))}
 function reverseUrl(point,endpoint){
  if(!validOrigin(point))throw new Error('invalid_reverse_point');
  const base=endpoint||root.VAI_GEOCODER_URL||'https://photon.komoot.io/api/';
  const url=new URL(base,root.location?.href||'https://vaicomigo.invalid/');
  if(!/^https?:$/.test(url.protocol))throw new Error('invalid_geocoder');
  url.pathname=url.pathname.replace(/\/?(?:api|reverse)\/?$/,'')+'/reverse';
  url.search='';url.searchParams.set('lat',String(point.lat));url.searchParams.set('lon',String(point.lng));url.searchParams.set('radius','0.5');url.searchParams.set('limit','5');return url.toString();
 }
 function formatReverse(features,point){
  if(!validOrigin(point))return null;
  const candidates=(Array.isArray(features)?features:[]).map(feature=>({mapped:mapFeature(feature),properties:feature.properties||{}})).filter(x=>x.mapped&&distanceKm(x.mapped,point)<.35);
  const found=candidates.find(x=>x.properties.street)||candidates.find(x=>x.mapped.kind==='Rua')||candidates[0];
  if(!found)return null;
  const p=found.properties;const street=p.street||found.mapped.kind==='Rua'&&found.mapped.name;
  const label=street?`${street}${p.housenumber?', '+p.housenumber:''}`:p.district||p.locality?`${p.district||p.locality} · Petrópolis`:`Próximo de ${found.mapped.name}`;
  return label?{label,area:[p.district||p.locality,'Petrópolis'].filter(Boolean).join(' · ')}:null;
 }
 async function reverse(point,{signal,endpoint,fetcher=root.fetch}={}){
  const response=await fetcher(reverseUrl(point,endpoint),{signal,headers:{Accept:'application/json'}});
  if(!response.ok)throw new Error('reverse_http_'+response.status);
  const data=await response.json();return formatReverse(data.features,point);
 }
 function normalize(features,query){
  const q=fold(query).replace(/\bpetropolis\b|\brj\b|\brio de janeiro\b/g,'').trim();
  const terms=q.split(' ').filter(x=>x.length>1&&!['rua','avenida','av','bairro','estrada','numero'].includes(x));
  const scored=(Array.isArray(features)?features:[]).map(mapFeature).filter(Boolean).map(x=>{
   const hay=fold(x.name+' '+x.area);
   const hits=terms.filter(t=>hay.includes(t)).length;
   const score=(!terms.length?1:hits/terms.length)*100+(fold(x.name).startsWith(q)?25:0)+(x.hasHouseNumber?9:0);
   return {...x,score};
  }).filter(x=>x.score>=45).sort((a,b)=>b.score-a.score);
  const seen=new Set();return scored.filter(x=>{const k=fold(x.name+' '+x.area);if(seen.has(k))return false;seen.add(k);return true}).slice(0,8).map(({score,...x})=>x);
 }
 async function search(query,{signal,endpoint,fetcher=root.fetch}={}){
  const clean=String(query||'').trim();if(fold(clean).length<3)return [];
  const url=makeUrl(clean,endpoint);
  const response=await fetcher(url,{signal,headers:{Accept:'application/json'}});
  if(!response.ok)throw new Error('geocoder_http_'+response.status);
  const data=await response.json();return normalize(data.features,clean);
 }
 root.VaiCitySearch=Object.freeze({search,normalize,mapFeature,makeUrl,reverse,reverseUrl,formatReverse});
})(typeof window==='undefined'?globalThis:window);
