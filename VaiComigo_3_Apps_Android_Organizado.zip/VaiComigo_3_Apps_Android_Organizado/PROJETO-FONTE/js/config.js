// Configuração INTERNA do aplicativo — preenchida uma única vez pelo responsável técnico.
// Passageiros e motoristas nunca veem nem digitam nada disto.
//
// PODEM ficar aqui (públicos por natureza):
//   supabaseUrl      → URL do projeto (Project Settings → API → Project URL)
//   supabaseAnonKey  → chave "anon" (JWT eyJ...) ou "publishable" (sb_publishable_...)
//   vapidPublicKey   → chave PÚBLICA VAPID do Web Push
//
// NUNCA coloque aqui: service_role, sb_secret_*, senha do banco, VAPID_PRIVATE_KEY,
// MP_ACCESS_TOKEN, MP_WEBHOOK_SECRET. Esses valores ficam em "Secrets" das Edge Functions.
//
// Alternativa no Netlify (deploy por Git/CLI): defina SUPABASE_URL, SUPABASE_ANON_KEY,
// VAPID_PUBLIC_KEY e (opcional) VAI_ENVIRONMENT=test; o build regenera este arquivo
// (scripts/generate-config.mjs). Em deploy manual (arrastar ZIP), edite este arquivo.
//
// environment: 'production' (padrão) | 'test' (exibe o botão de Diagnóstico E2E no Perfil).
window.VAI_CONFIG = Object.assign({
  supabaseUrl: 'https://uuywjwmarjrmcjtvezbg.supabase.co',
  supabaseAnonKey: 'sb_publishable_jCbbrRjcQNc9oamjh4_Egg_lDeDV1tt',
  vapidPublicKey: 'BEQ_dVAwpZYJ1swt10VX_vgobKC8j6nm2CHKrhtF30Fsri1E4GOR5d7fAqb9qbBcxcizKu9IEyCFyTrXQ1PSx8M',
  paymentsEnabled: false,
  environment: 'production'
}, window.VAI_CONFIG || {});
