/* Verificação de identidade: fotos privadas, fila de revisão e bloqueio no servidor. */
(() => {
  'use strict';
  const bucket = 'vai-identity-private';
  const $ = id => document.getElementById(id);
  let pending = [];
  const safe = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const client = () => window.supabaseClient;
  function message(value) { if ($('identityMessage')) $('identityMessage').textContent = value; }
  function status(label, detail, editable) {
    const banner=$('passengerJourneyStatus'),txt=$('passengerJourneyText');
    if(banner)banner.hidden=!window.currentUser||document.body.dataset.entryRole!=='passenger'||label==='Aprovado';
    if(txt)txt.textContent=label==='Em análise'?'Cadastro em análise. Aguarde a aprovação.':label==='Correção necessária'?'Sua verificação precisa de correção.':label==='Indisponível'?'Não foi possível conferir seu cadastro.':'Verifique sua identidade para solicitar corridas.';
    if ($('identityStatus')) $('identityStatus').textContent = label;
    if ($('identityDetail')) $('identityDetail').textContent = detail;
    if ($('identityForm')) $('identityForm').hidden = !editable;
  }
  async function loadMine() {
    if (!client() || !window.currentUser) { window.vaiIdentityApproved=false; window.updateDriverJourney?.(); status('Entre na conta', 'Entre na sua conta para iniciar a análise de identidade.', false); return; }
    const {data, error} = await client().from('identity_reviews').select('status,rejection_reason').eq('user_id',window.currentUser.id).maybeSingle();
    if (error) { window.vaiIdentityApproved=false; window.updateDriverJourney?.(); status('Indisponível', 'Não foi possível consultar a análise. Tente novamente.', false); message(error.message); return; }
    window.vaiIdentityApproved=data?.status==='approved';window.updateDriverJourney?.();
    if (!data || data.status === 'draft') status('Não enviado', 'Envie as quatro fotos para análise do diretor antes de solicitar viagens.', true);
    else if (data.status === 'rejected') status('Correção necessária', `Motivo: ${data.rejection_reason || 'Consulte a administração.'} Envie quatro fotos atualizadas.`, true);
    else if (data.status === 'approved') status('Aprovado', 'Sua identidade foi analisada e aprovada.', false);
    else status('Em análise', 'O diretor receberá seu cadastro no painel administrativo. Aguarde a decisão.', false);
  }
  async function normalizedImage(file) {
    if (!file || !['image/jpeg','image/png','image/webp'].includes(file.type) || file.size > 8*1024*1024) throw Error('Envie cada foto em JPEG, PNG ou WebP com até 8 MB.');
    const bitmap = await createImageBitmap(file);
    try {
      if (bitmap.width < 600 || bitmap.height < 600) throw Error('A foto está pequena. Use uma imagem nítida com pelo menos 600 pixels por lado.');
      const ratio = Math.min(1, 2600 / Math.max(bitmap.width, bitmap.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(bitmap.width * ratio); canvas.height = Math.round(bitmap.height * ratio);
      const ctx = canvas.getContext('2d');
      if (!ctx) throw Error('Não foi possível preparar a foto neste aparelho.');
      ctx.fillStyle = '#fff'; ctx.fillRect(0,0,canvas.width,canvas.height);
      ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);
      const blob = await new Promise(resolve => canvas.toBlob(resolve,'image/jpeg',0.91));
      if (!blob || blob.size > 8*1024*1024) throw Error('A imagem ficou grande demais. Tire outra foto.');
      return blob; // Reencodificação remove metadados EXIF como a localização da câmera.
    } finally { bitmap.close(); }
  }
  async function submit() {
    const button = $('identitySubmit');
    if (!client() || !window.currentUser) { message('Entre na sua conta antes de enviar fotos.'); return; }
    if (!$('identityConsent').checked) { message('Leia o aviso e confirme antes de enviar as fotos.'); return; }
    const entries = [['identityFront','front'],['identityBack','back'],['identitySelfie','selfie'],['identityWithDoc','with-document']];
    if (entries.some(([id]) => !$(id)?.files?.[0])) { message('Selecione as quatro fotos antes de enviar.'); return; }
    button.disabled = true;
    const uploaded = {};
    try {
      for (const [id,kind] of entries) {
        message(`Preparando e enviando ${kind}…`);
        const blob = await normalizedImage($(id).files[0]);
        const path = `${window.currentUser.id}/${kind}/${crypto.randomUUID()}.jpg`;
        const {error} = await client().storage.from(bucket).upload(path,blob,{contentType:'image/jpeg',upsert:false});
        if (error) throw error;
        uploaded[kind] = path;
      }
      const {error} = await client().rpc('submit_my_identity',{p_kind:$('identityKind').value,p_front:uploaded.front,p_back:uploaded.back,p_selfie:uploaded.selfie,p_with_document:uploaded['with-document'],p_consent:true});
      if (error) throw error;
      message('Quatro fotos enviadas. Sua identidade está aguardando análise.');
      entries.forEach(([id]) => { $(id).value=''; });
      await loadMine();
    } catch(e) { message(`Não foi possível concluir o envio: ${e.message || e}. As fotos já enviadas ficam privadas; tente novamente.`); }
    finally { button.disabled = false; }
  }
  async function loadQueue() {
    const box = $('adminIdentityList'); if (!box || !client()) return;
    box.textContent = 'Buscando análises…';
    const {data,error} = await client().rpc('admin_identity_queue');
    if (error) { box.textContent = `Não foi possível consultar: ${error.message}`; return; }
    pending = data || [];
    box.replaceChildren();
    if (!pending.length) { box.textContent = 'Nenhuma solicitação recebida.'; return; }
    pending.forEach((row,index) => {
      const entry = document.createElement('div'); entry.className='identityQueueRow';
      const info=document.createElement('div');
      info.innerHTML=`<b>${safe(row.full_name || 'Conta sem nome')}</b> · ${safe(row.account_role || 'passageiro')}<br><small>${safe(row.review_status)} · ${safe(row.document_kind)} · ${row.submitted_at ? new Date(row.submitted_at).toLocaleString('pt-BR') : 'Sem data'}</small>`;
      const button=document.createElement('button'); button.type='button';button.className='btn secondary';button.textContent='Analisar fotos';button.addEventListener('click',()=>openReview(index));
      entry.append(info,button);box.append(entry);
    });
  }
  async function openReview(index) {
    const row=pending[index]; if (!row) return;
    const old=$('identityReviewModal');if(old)old.remove();
    const overlay=document.createElement('div');overlay.id='identityReviewModal';overlay.className='identityReviewOverlay';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','Análise de identidade');
    const panel=document.createElement('div');panel.className='identityReviewPanel';
    const heading=document.createElement('h2');heading.textContent=`Analisar: ${row.full_name || row.user_id}`;
    const note=document.createElement('p');note.textContent=`Documento: ${row.document_kind || '—'} · Conta: ${row.account_role || '—'}. Compare rosto, foto com documento e frente/verso antes de decidir. A análise visual não garante autenticidade ou prova de vida.`;
    const gallery=document.createElement('div');gallery.className='identityGallery';
    panel.append(heading,note,gallery);
    const close=document.createElement('button');close.className='btn secondary';close.textContent='Fechar';close.onclick=()=>overlay.remove();panel.append(close);
    if(row.review_status==='pending') {
      const approve=document.createElement('button');approve.className='btn';approve.textContent='Aprovar identidade';approve.onclick=()=>decide(index,'approved');
      const reject=document.createElement('button');reject.className='btn secondary';reject.textContent='Reprovar e pedir correção';reject.onclick=()=>decide(index,'rejected');
      panel.append(approve,reject);
    }
    overlay.append(panel);document.body.append(overlay);
    overlay.addEventListener('click',event=>{if(event.target===overlay)overlay.remove();});
    for(const [label,path] of [['Frente do documento',row.document_front_path],['Verso do documento',row.document_back_path],['Rosto',row.selfie_path],['Rosto com documento',row.selfie_with_document_path]]) {
      const card=document.createElement('figure');const caption=document.createElement('figcaption');caption.textContent=label;card.append(caption);gallery.append(card);
      if(!path) {card.append(document.createTextNode('Arquivo ausente'));continue;}
      const {data,error}=await client().storage.from(bucket).createSignedUrl(path,120);
      if(error || !data?.signedUrl){card.append(document.createTextNode('Falha ao carregar arquivo privado.'));continue;}
      const img=document.createElement('img');img.src=data.signedUrl;img.alt=label;img.loading='lazy';card.append(img);
    }
  }
  async function decide(index, decision) {
    const row=pending[index];if(!row)return;
    let reason=null;
    if(decision==='rejected') {reason=prompt('Informe o motivo da reprovação para que a pessoa possa corrigir o cadastro:');if(!reason?.trim())return;}
    else if(!confirm('Você verificou pessoalmente as quatro fotos e deseja aprovar esta identidade?'))return;
    const {error}=await client().rpc('admin_review_identity',{p_user_id:row.user_id,p_decision:decision,p_reason:reason});
    if(error){alert(`Não foi possível registrar a decisão: ${error.message}`);return;}
    $('identityReviewModal')?.remove();await loadQueue();await loadMine();
  }
  window.loadMyIdentityReview=loadMine;
  window.submitIdentityReview=submit;
  window.loadAdminIdentityQueue=loadQueue;
})();
