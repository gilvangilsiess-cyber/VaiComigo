/* Catálogo inicial de destinos usados em Petrópolis. Coordenadas ausentes exigem
   resolução específica antes da cotação: jamais usar um ponto aproximado. */
(function (root) {
  'use strict';
  const places = Object.freeze([
    { id:'castelo-itaipava', name:'Castelo de Itaipava', area:'Itaipava · BR-040, km 56',
      aliases:['castelo','castelo do barao','castelo de itaipava','hotel castelo'],
      lat:-22.36076, lng:-43.12510, priority:110 },
    { id:'rodoviaria-bingen', name:'Rodoviária do Bingen', area:'Terminal Gov. Leonel Brizola · Bingen',
      aliases:['rodoviaria','terminal','rodoviaria petropolis','terminal rodoviario','terminal bingen','leonel brizola','rodoviaria do bingen'],
      query:'Terminal Rodoviário Governador Leonel Brizola, Bingen, Petrópolis, RJ', priority:100 },
    { id:'rodoviaria-centro', name:'Rodoviária do Centro', area:'Terminal Imperatriz Leopoldina · Centro',
      aliases:['rodoviaria','terminal','terminal centro','rodoviaria antiga','rodoviaria do centro','imperatriz leopoldina'],
      query:'Terminal Rodoviário Imperatriz Leopoldina, Centro, Petrópolis, RJ', priority:90 },
    { id:'museu-imperial', name:'Museu Imperial', area:'Centro', aliases:['museu','museu imperial','palacio imperial'],
      lat:-22.5096, lng:-43.1779, priority:75 },
    { id:'catedral', name:'Catedral de São Pedro', area:'Centro', aliases:['catedral','sao pedro de alcantara'],
      lat:-22.5065, lng:-43.1785, priority:70 },
    { id:'quitandinha', name:'Palácio Quitandinha', area:'Quitandinha', aliases:['quitandinha','palacio quitandinha'],
      lat:-22.5215, lng:-43.2310, priority:70 },
    { id:'palacio-cristal', name:'Palácio de Cristal', area:'Centro', aliases:['palacio de cristal','cristal'],
      query:'Palácio de Cristal, Centro, Petrópolis, RJ', priority:60 },
    { id:'casa-santos-dumont', name:'Casa de Santos Dumont', area:'Centro', aliases:['santos dumont','a encantada','casa santos dumont'],
      query:'Museu Casa de Santos Dumont, Petrópolis, RJ', priority:55 }
  ]);
  function fold(value) {
    return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function oneTypoApart(a,b){
    if(a.length<5||b.length<5||Math.abs(a.length-b.length)>1)return false;
    let i=0,j=0,edits=0;
    while(i<a.length&&j<b.length){if(a[i]===b[j]){i++;j++;continue}if(++edits>1)return false;if(a.length>b.length)i++;else if(b.length>a.length)j++;else{i++;j++}}
    return edits+(a.length-i)+(b.length-j)<=1;
  }
  function rank(query) {
    const q = fold(query);
    if (q.length < 2) return [];
    return places.map(place => {
      const terms = [place.name, ...place.aliases].map(fold);
      const exact = terms.some(term => term === q);
      const prefix = terms.some(term => term.startsWith(q));
      const partial = terms.some(term => term.includes(q));
      const allTokens = q.split(' ').every(token => fold(place.name + ' ' + place.area + ' ' + place.aliases.join(' ')).includes(token));
      const typo=q.indexOf(' ')<0&&terms.some(term=>term.split(' ').some(word=>oneTypoApart(q,word)));
      const score = exact ? 300 : prefix ? 200 : partial ? 100 : allTokens ? 50 : typo ? 20 : 0;
      return { place, score: score + (score ? place.priority : 0) };
    }).filter(x => x.score).sort((a,b) => b.score-a.score || a.place.name.localeCompare(b.place.name,'pt-BR'))
      .map(x => x.place).slice(0, 8);
  }
  // Um resultado externo fora da região não vira destino, mesmo que o provedor o ranqueie primeiro.
  function isLocalResult(item) {
    const lat = Number(item?.lat), lng = Number(item?.lon ?? item?.lng);
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < -22.67 || lat > -22.30 || lng < -43.48 || lng > -43.02) return false;
    const address = item.address || {};
    const cities = [address.city,address.town,address.municipality,address.county].filter(Boolean).map(fold);
    return cities.length ? cities.some(city => city === 'petropolis' || city === 'municipio de petropolis')
      : /(^|,\s*)Petrópolis\s*(,|$)/i.test(item.display_name || '');
  }
  root.VaiPlaces = Object.freeze({ places, fold, rank, isLocalResult });
})(typeof window === 'undefined' ? globalThis : window);
