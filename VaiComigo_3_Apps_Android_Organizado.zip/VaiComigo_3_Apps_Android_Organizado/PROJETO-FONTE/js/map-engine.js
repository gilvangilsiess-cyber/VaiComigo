/* MapLibre nativo para o mapa principal. A camada de compatibilidade preserva
   os desenhos das rotas existentes durante a migração do restante do app. */
(function(root){
 'use strict';
 const leaflet=root.L;
 if (!leaflet || !root.maplibregl) {
  console.warn('Bibliotecas de mapa indisponíveis; controles de corrida permanecem ativos.');
  return;
 }
 const original={marker:leaflet.marker,circle:leaflet.circle,circleMarker:leaflet.circleMarker,polyline:leaflet.polyline,geoJSON:leaflet.geoJSON};
 const point=p=>Array.isArray(p)?{lat:Number(p[0]),lng:Number(p[1])}:{lat:Number(p.lat),lng:Number(p.lng)};
 const coordinates=p=>{const v=point(p);return [v.lng,v.lat]};
 const fitCoords=geometry=>{
  const positions=[];function walk(v){if(!Array.isArray(v))return;if(typeof v[0]==='number'){positions.push(v);return}v.forEach(walk)}walk(geometry.coordinates);return positions;
 };
 let sequence=0;
 function create(){
  const gl=new root.maplibregl.Map({container:'map',style:root.VAI_MAP_STYLE_URL||'https://tiles.openfreemap.org/styles/bright',center:[-43.18,-22.51],zoom:14.8,pitch:53,bearing:-13,attributionControl:true,canvasContextAttributes:{antialias:true}});
  const m={native:true,gl,ready:false,pending:[],setView(p,zoom){const v=point(p);gl.easeTo({center:[v.lng,v.lat],zoom:zoom||gl.getZoom(),duration:650});return m},fitBounds(b,o={}){let coords=Array.isArray(b)?b:b?.coords||[];if(coords.length===2&&typeof coords[0]?.[0]==='number'&&coords[0][0]<-20&&coords[0][0]>-24){coords=coords.map(coordinates)}else if(coords.length&&coords[0]?.lat!==undefined)coords=coords.map(coordinates);if(!coords.length)return m;const bounds=coords.reduce((a,c)=>a.extend(c),new root.maplibregl.LngLatBounds(coords[0],coords[0]));gl.fitBounds(bounds,{padding:o.padding?.[0]||32,maxZoom:16,duration:900,pitch:42});return m},on(name,cb){if(name==='click'){const wrapper=e=>cb({latlng:{lat:e.lngLat.lat,lng:e.lngLat.lng}});m.events.set(cb,wrapper);gl.on('click',wrapper)}else gl.on(name,cb);return m},off(name,cb){gl.off(name,m.events.get(cb)||cb);m.events.delete(cb);return m},events:new Map(),removeLayer(layer){layer?.remove();return m},invalidateSize(){gl.resize();return m}};
  gl.on('load',()=>{
   m.ready=true;
   while(m.pending.length)m.pending.shift()();
   if(rasterFallback)return;
   try{
    const style=gl.getStyle(),label=style.layers?.find(x=>x.type==='symbol'&&x.layout?.['text-field']);
    if(!gl.getSource('vc-buildings'))gl.addSource('vc-buildings',{type:'vector',url:'https://tiles.openfreemap.org/planet'});
    if(!gl.getLayer('vc-buildings-3d'))gl.addLayer({id:'vc-buildings-3d',type:'fill-extrusion',source:'vc-buildings','source-layer':'building',minzoom:15,filter:['!=',['get','hide_3d'],true],paint:{'fill-extrusion-color':'#c8ad88','fill-extrusion-height':['interpolate',['linear'],['zoom'],15,0,16,['coalesce',['get','render_height'],['get','height'],4]],'fill-extrusion-base':['coalesce',['get','render_min_height'],0],'fill-extrusion-opacity':0.83}},label?.id);
   }catch(e){console.warn('Edifícios 3D indisponíveis',e)}
   try{
    if(typeof gl.setTerrain==='function'&&!gl.getSource('vc-terrain')){
     gl.addSource('vc-terrain',{type:'raster-dem',tiles:['https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png'],tileSize:256,maxzoom:14,encoding:'terrarium',attribution:'© AWS Terrain Tiles'});
     gl.setTerrain({source:'vc-terrain',exaggeration:1.15});
    }
   }catch(e){console.warn('Relevo 3D indisponível',e)}
  });
  let rasterFallback=false,rasterErrors=0;
  gl.on('error',e=>{if(e?.sourceId==='vc-terrain'){try{gl.setTerrain(null);gl.removeSource('vc-terrain')}catch(_){}return}if(e?.sourceId==='vc-buildings')return;if(!m.ready&&!rasterFallback){rasterFallback=true;document.getElementById('mapStatus').textContent='Tentando mapa básico…';gl.setStyle({version:8,sources:{osm:{type:'raster',tiles:['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],tileSize:256,attribution:'© OpenStreetMap contributors'}},layers:[{id:'osm-raster',type:'raster',source:'osm'}]})}else if(rasterFallback&&++rasterErrors>=6){m.onUnrecoverable?.()} });
  return m;
 }
 function marker(p,opts={}){let location=point(p),element=document.createElement('span');element.className=opts.className||'vcGlPin';if(opts.icon?.options?.html)element.innerHTML=opts.icon.options.html;else element.textContent=opts.car?'🚗':'';let instance,popup;
  let disposed=false;const layer={addTo(m){if(!m.native)return original.marker(p,opts).addTo(m);layer.map=m;const add=()=>{if(disposed)return;instance=new root.maplibregl.Marker({element,draggable:!!opts.draggable,rotationAlignment:'map'}).setLngLat(coordinates(location)).addTo(m.gl);if(popup)instance.setPopup(popup);instance.on('dragend',()=>{location=point(instance.getLngLat());opts.onDrag?.(location)})};m.ready?add():m.pending.push(add);return layer},setLatLng(p){location=point(p);instance?.setLngLat(coordinates(location));return layer},getLatLng(){return location},bindPopup(html){popup=new root.maplibregl.Popup({offset:20}).setHTML(html);instance?.setPopup(popup);return layer},openPopup(){instance?.togglePopup();return layer},remove(){disposed=true;instance?.remove()},setHeading(deg){instance?.setRotation(deg||0);return layer}};return layer;
 }
 function line(geo,opts={}){const id='vc-geometry-'+(++sequence),geometry=geo.type==='Feature'?geo.geometry:geo;let host,disposed=false;const layer={coords:fitCoords(geometry),addTo(m){if(!m.native)return (geometry.type==='LineString'?original.polyline(geometry.coordinates.map(c=>[c[1],c[0]]),opts):original.geoJSON(geo,opts)).addTo(m);host=m;const add=()=>{if(disposed||m.gl.getSource(id))return;m.gl.addSource(id,{type:'geojson',data:{type:'Feature',geometry,properties:{}}});m.gl.addLayer({id,type:'line',source:id,paint:{'line-color':opts.style?.color||opts.color||'#b38b57','line-width':opts.style?.weight||opts.weight||5,'line-opacity':opts.style?.opacity||1,'line-dasharray':opts.dashArray?[2,2]:[1,0]}})};m.ready?add():m.pending.push(add);return layer},getBounds(){return {coords:layer.coords}},remove(){disposed=true;if(host?.ready&&host.gl.getLayer(id))host.gl.removeLayer(id);if(host?.ready&&host.gl.getSource(id))host.gl.removeSource(id)}};return layer;
 }
 leaflet.marker=function(p,opts){return marker(p,opts)};
 leaflet.circleMarker=function(p,opts={}){return marker(p,{className:'vcGlCircle',...opts})};
 leaflet.circle=function(p,opts={}){const v=marker(p,{className:'vcGlAccuracy'});v.setRadius=function(radius){v.radius=radius;return v};v.setRadius(opts.radius||0);return v};
 leaflet.polyline=function(pts,opts={}){return line({type:'LineString',coordinates:pts.map(coordinates)},opts)};
 leaflet.geoJSON=function(data,opts={}){return line(data,opts)};
 root.VaiMapEngine={create,point,restoreLeaflet(){Object.assign(leaflet,original)}};
})(window);
