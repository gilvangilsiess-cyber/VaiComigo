(function(){
'use strict';
/* VaiComigo v40 — Driver Module
 * Chamadas em tempo real + alerta sonoro/vibratório + aceite atômico.
 *
 * Contratos Supabase usados:
 * - nearest_requested_rides(lat,lng,radius)
 * - accept_ride(ride_id)
 * - update_ride_status(ride_id,status)
 * - set_driver_availability(available)
 * - update_driver_location(...)
 *
 * Push:
 * - solicita permissão e grava PushSubscription em v40.push_subscriptions;
 * - o servidor envia Web Push via Edge Function/VAPID; o SW trata push + ações.
 */

const gpsEngine=window.VaiComigoGPS;

let driverAvailable = false;
let offerChannel = null;
let offerPoll = null;
let alertTimer = null;
let audioContext = null;
let audioNodes = [];
let pendingRideId = null;
let initialized = false;

const state = {
  radiusKm: 10,
  pollMs: 8000,
  responseTimeoutMs: 30000
};

function el(id) {
  return document.getElementById(id);
}

function escapeHtml(value) {
  if (typeof window.escapeHtml === 'function') {
    return window.escapeHtml(value);
  }

  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function money(value) {
  const n = Number(value || 0);
  return n.toFixed(2).replace('.', ',');
}

function stopVibration() {
  try {
    navigator.vibrate?.(0);
  } catch (_) {}
}

function startVibrationLoop() {
  stopVibration();

  const tick = () => {
    if (!pendingRideId) return;

    try {
      // Alguns navegadores limitam chamadas contínuas; repetir por timer
      // é mais compatível que tentar uma vibração infinita.
      navigator.vibrate?.([800, 400, 800]);
    } catch (_) {}

    alertTimer = setTimeout(tick, 2200);
  };

  tick();
}

function stopAudioAlarm() {
  for (const node of audioNodes) {
    try { node.stop?.(); } catch (_) {}
    try { node.disconnect?.(); } catch (_) {}
  }
  audioNodes = [];

  try {
    if (audioContext?.state === 'running') {
      audioContext.suspend();
    }
  } catch (_) {}
}

async function ensureAudio() {
  if (!audioContext) {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return null;
    audioContext = new AudioCtx();
  }

  try {
    if (audioContext.state === 'suspended') {
      await audioContext.resume();
    }
  } catch (_) {}

  return audioContext;
}

async function playAlarmBurst() {
  const ctx = await ensureAudio();
  if (!ctx || !pendingRideId) return;

  const now = ctx.currentTime;

  // Dois tons curtos e audíveis sem arquivo externo.
  for (const [offset, freq] of [
    [0, 880],
    [0.28, 660]
  ]) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.value = freq;

    gain.gain.setValueAtTime(0.0001, now + offset);
    gain.gain.exponentialRampToValueAtTime(
      0.22,
      now + offset + 0.025
    );
    gain.gain.exponentialRampToValueAtTime(
      0.0001,
      now + offset + 0.22
    );

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now + offset);
    osc.stop(now + offset + 0.24);

    audioNodes.push(osc, gain);
  }
}

function startAudioAlarm() {
  stopAudioAlarm();

  const loop = async () => {
    if (!pendingRideId) return;

    await playAlarmBurst();

    if (pendingRideId) {
      alertTimer = setTimeout(loop, 1400);
    }
  };

  loop();
}

function startCallAlert(rideId) {
  stopCallAlert();
  pendingRideId = rideId;

  startVibrationLoop();
  startAudioAlarm();

  // Vibração/áudio em foreground dependem das políticas do navegador.
  // O push nativo é o caminho para tela bloqueada/background.
  showLocalRideNotification(rideId);
}

function stopCallAlert() {
  pendingRideId = null;

  if (alertTimer) {
    clearTimeout(alertTimer);
    alertTimer = null;
  }

  stopVibration();
  stopAudioAlarm();
}

async function showLocalRideNotification(rideId) {
  if (
    !('Notification' in window) ||
    Notification.permission !== 'granted'
  ) return;

  try {
    const registration = await navigator.serviceWorker?.ready;
    await registration?.showNotification?.('Nova corrida', {
      body: 'Há uma corrida disponível próxima de você.',
      icon: './icon.svg',
      badge: './icon.svg',
      tag: `ride-${rideId}`,
      requireInteraction: true,
      data: {
        type: 'ride_request',
        ride_id: rideId,
        url: './'
      },
      actions: [
        { action: 'accept-ride', title: 'Aceitar corrida' },
        { action: 'reject-ride', title: 'Recusar' }
      ]
    });
  } catch (_) {}
}

function getPosition() {
  return new Promise((resolve, reject) => {
    if (!(window.VAI_GEO||navigator.geolocation)) {
      reject(new Error('Geolocalização não suportada.'));
      return;
    }

    (window.VAI_GEO||navigator.geolocation).getCurrentPosition(
      p => resolve(p),
      reject,
      {
        enableHighAccuracy: true,
        maximumAge: 3000,
        timeout: 15000
      }
    );
  });
}

async function getDriverPosition() {
  try {
    return await getPosition();
  } catch (_) {
    // GPS engine pode continuar armazenando pontos mesmo quando o
    // primeiro getCurrentPosition falha.
    throw new Error('Não foi possível obter a localização do motorista.');
  }
}

async function loadDriverRequests() {
  const sb = window.supabaseClient;
  const user = window.currentUser;
  const box = el('driverCall');

  if (!sb || !user || !driverAvailable) return;
  if (!box) return;

  let pos;

  try {
    pos = await getDriverPosition();
  } catch (error) {
    box.innerHTML =
      '<div class="msg" style="background:#fff0f0;color:#b42318">' +
      escapeHtml(error.message) +
      '</div>';
    return;
  }

  const { data, error } = await sb.rpc(
    'nearest_requested_rides',
    {
      p_lat: Number(pos.coords.latitude),
      p_lng: Number(pos.coords.longitude),
      p_radius_km: state.radiusKm
    }
  );

  if (error) {
    box.innerHTML =
      '<div class="msg" style="background:#fff0f0;color:#b42318">' +
      'Não foi possível buscar chamadas.' +
      '</div>';
    return;
  }

  const ride = data?.[0];

  if (!ride) {
    // Não remove uma chamada já aceita.
    if (!window.activeDriverRide) {
      box.innerHTML =
        '<div class="msg">Nenhuma corrida disponível próxima no momento.</div>';
    }
    return;
  }

  renderRideOffer(ride);
}

function renderRideOffer(ride) {
  const box = el('driverCall');
  if (!box) return;

  startCallAlert(ride.id);

  box.innerHTML = `
    <div class="call" data-ride-id="${escapeHtml(ride.id)}">
      <div class="head">
        <b>🔔 Nova chamada</b>
        <span class="status">${Number(ride.distance_km || 0).toFixed(1)} km</span>
      </div>
      <p>
        <strong>${escapeHtml(ride.destination_name || 'Destino não informado')}</strong><br>
        <span style="color:#667085;font-size:13px">
          Corrida estimada R$ ${money(ride.estimated_price)}
        </span>
      </p>
      <div class="actions">
        <button class="action" type="button"
          data-action="reject-ride">Recusar</button>
        <button class="btn" type="button"
          data-action="accept-ride">Aceitar corrida</button>
      </div>
      <div id="driverOfferCountdown"
        style="margin-top:8px;color:#667085;font-size:11px">
        Toque em aceitar para interromper o alerta.
      </div>
    </div>
  `;

  const accept = box.querySelector('[data-action="accept-ride"]');
  const reject = box.querySelector('[data-action="reject-ride"]');

  accept?.addEventListener('click', () => acceptRide(ride.id));
  reject?.addEventListener('click', () => rejectRide(ride.id));

  let left = Math.ceil(state.responseTimeoutMs / 1000);
  const countdown = el('driverOfferCountdown');

  const timer = setInterval(() => {
    if (!pendingRideId || pendingRideId !== ride.id) {
      clearInterval(timer);
      return;
    }

    left -= 1;

    if (countdown) {
      countdown.textContent =
        left > 0
          ? `A chamada expira em ${left}s.`
          : 'Chamada expirada.';
    }

    if (left <= 0) {
      clearInterval(timer);
      if (pendingRideId === ride.id) {
        stopCallAlert();
        box.innerHTML =
          '<div class="msg">A chamada expirou.</div>';
      }
    }
  }, 1000);
}

async function acceptRide(id) {
  const sb = window.supabaseClient;
  if (!sb) return;

  stopCallAlert();

  const { data, error } = await sb.rpc('accept_ride', {
    p_ride_id: id
  });

  if (error) {
    el('driverCall').innerHTML =
      '<div class="msg" style="background:#fff0f0;color:#b42318">' +
      escapeHtml(error.message || 'Não foi possível aceitar a corrida.') +
      '</div>';
    await loadDriverRequests();
    return;
  }

  window.activeDriverRide = data;
  window.renderDriverRideState(data);

  if (
    data?.origin_lat != null &&
    data?.origin_lng != null &&
    typeof window.buildDriverRoute === 'function'
  ) {
    await window.buildDriverRoute(
      Number(data.origin_lat),
      Number(data.origin_lng),
      'Buscar passageiro'
    );
  }
}

async function rejectRide(id) {
  if (pendingRideId === id) stopCallAlert();

  const box = el('driverCall');
  if (box) {
    box.innerHTML =
      '<div class="msg">Chamada recusada. Procurando outra corrida…</div>';
  }

  // O v40 não possui RPC de recusa de oferta porque "requested" é uma
  // fila pública; apenas deixa de apresentar esta oferta ao motorista.
  // A corrida continua disponível para outros motoristas.
  await loadDriverRequests();
}

function renderDriverRideState(data) {
  if (!data) return;

  window.activeDriverRide = data;
  stopCallAlert();

  const box = el('driverCall');
  if (!box) return;

  if (data.status === 'accepted') {
    box.innerHTML = `
      <div class="msg">
        <b>✓ Corrida aceita.</b><br>
        O passageiro foi avisado em tempo real.
        <div id="driverRouteInfo"
          style="margin-top:8px;color:#667085;font-size:13px">
          Calculando rota até o passageiro…
        </div>
        <button class="btn secondary" style="margin-top:10px"
          id="driverFitRoute">Ver rota no mapa</button>
        <button class="btn" style="margin-top:10px"
          id="driverInternalNavigation">Iniciar navegação VaiComigo</button>
        <button class="btn" style="margin-top:10px"
          id="driverExternalNavigation">Navegar até o passageiro</button>
        <button class="btn" style="margin-top:10px"
          id="driverArriving">Estou a caminho</button>
      </div>
    `;

    el('driverFitRoute')?.addEventListener('click', () =>
      window.fitDriverRoute?.()
    );
    el('driverInternalNavigation')?.addEventListener('click', () =>
      window.toggleDriverNavigation?.(true)
    );
    el('driverExternalNavigation')?.addEventListener('click', () =>
      window.openExternalNavigation?.()
    );
    el('driverArriving')?.addEventListener('click', () =>
      setRideStatus(data.id, 'arriving')
    );

  } else if (data.status === 'arriving') {
    box.innerHTML = `
      <div class="msg">
        🚗 Você está a caminho do passageiro.
        <div id="driverRouteInfo"
          style="margin-top:8px;color:#667085;font-size:13px">
          Rota ativa no mapa.
        </div>
        <button class="btn secondary" style="margin-top:10px"
          id="driverFitRoute">Ver rota</button>
        <button class="btn" style="margin-top:10px"
          id="driverInternalNavigation">Iniciar navegação VaiComigo</button>
        <button class="btn" style="margin-top:10px"
          id="driverExternalNavigation">Abrir navegação</button>
        <button class="btn" style="margin-top:10px"
          id="driverInProgress">Iniciar corrida</button>
      </div>
    `;

    el('driverFitRoute')?.addEventListener('click', () =>
      window.fitDriverRoute?.()
    );
    el('driverInternalNavigation')?.addEventListener('click', () =>
      window.toggleDriverNavigation?.(true)
    );
    el('driverExternalNavigation')?.addEventListener('click', () =>
      window.openExternalNavigation?.()
    );
    el('driverInProgress')?.addEventListener('click', () =>
      setRideStatus(data.id, 'in_progress')
    );

    if (
      data.origin_lat != null &&
      data.origin_lng != null &&
      typeof window.buildDriverRoute === 'function'
    ) {
      window.buildDriverRoute(
        Number(data.origin_lat),
        Number(data.origin_lng),
        'Passageiro'
      );
    }

  } else if (data.status === 'in_progress') {
    box.innerHTML = `
      <div class="msg">
        🚗 Corrida em andamento.
        <button class="btn secondary" style="margin-top:10px"
          id="driverInternalNavigation">Navegar até o destino</button>
        <button class="btn" style="margin-top:10px"
          id="driverCompleted">Finalizar corrida</button>
      </div>
    `;

    el('driverInternalNavigation')?.addEventListener('click', async () => {
      if(data.destination_lat!=null&&data.destination_lng!=null){
        await window.buildDriverRoute?.(Number(data.destination_lat),Number(data.destination_lng),'Destino');
      }
      window.toggleDriverNavigation?.(true);
    });

    el('driverCompleted')?.addEventListener('click', () =>
      setRideStatus(data.id, 'completed')
    );

  } else if (data.status === 'completed') {
    window.clearDriverRoute?.();

    const cash = data.payment_method === 'cash';

    box.innerHTML = `
      <div class="msg">
        <b>✓ Corrida finalizada.</b>
        ${
          cash
            ? `<br><button class="btn" style="margin-top:10px"
                 id="driverCashPayment">Confirmar recebimento em dinheiro</button>`
            : `<br><span style="font-size:12px;color:#667085">
                 Pagamento: ${escapeHtml(data.payment_method || 'pix')}
                 • aguardando provedor
               </span>`
        }
      </div>
    `;

    el('driverCashPayment')?.addEventListener('click', () =>
      confirmCashPayment(data.id)
    );
  } else if (data.status === 'cancelled') {
    window.clearDriverRoute?.();
    window.activeDriverRide = null;
    box.innerHTML =
      '<div class="msg"><b>Corrida cancelada.</b><br>' +
      'Você continua disponível para novas chamadas.</div>';
  }
}

// complete_ride/cancel não devolvem o motorista para "available" no banco, mas a tela
// continua mostrando "Disponível". Alinha o banco com a tela.
async function restoreAvailabilityIfOnline() {
  const sb = window.supabaseClient;
  if (!sb || !driverAvailable) return;
  const { error } = await sb.rpc('set_driver_availability', { p_available: true });
  if (error) console.warn('restore availability', error);
}

async function setRideStatus(id, status) {
  const sb = window.supabaseClient;
  if (!sb) return;

  let data;
  let error;

  if (status === 'completed') {
    ({
      data,
      error
    } = await sb.rpc('complete_ride', {
      p_ride_id: id,
      p_final_price:
        window.activeDriverRide?.final_price ??
        window.activeDriverRide?.estimated_price ??
        window.activeDriverRide?.fare_estimate ??
        null
    }));
  } else {
    ({
      data,
      error
    } = await sb.rpc('update_ride_status', {
      p_ride_id: id,
      p_status: status
    }));
  }

  if (error) {
    const box = el('driverCall');
    if (box) {
      box.innerHTML =
        '<div class="msg" style="background:#fff0f0;color:#b42318">' +
        escapeHtml(error.message || 'Não foi possível atualizar o status.') +
        '</div>';
    }
    return;
  }

  if (data) {
    window.activeDriverRide = data;
    window.renderDriverRideState(data);
  } else {
    // Algumas RPCs podem não retornar linha em instalações antigas.
    window.activeDriverRide = {
      ...(window.activeDriverRide || {}),
      status
    };
    window.renderDriverRideState(window.activeDriverRide);
  }

  if (status === 'completed' || status === 'cancelled') {
    await restoreAvailabilityIfOnline();
  }
}

async function confirmCashPayment(id) {
  const sb = window.supabaseClient;
  if (!sb) return;

  const { data, error } = await sb.rpc(
    'confirm_cash_payment',
    { p_ride_id: id }
  );

  if (error) {
    el('driverCall').innerHTML =
      '<div class="msg" style="background:#fff0f0;color:#b42318">' +
      'Não foi possível confirmar o pagamento em dinheiro.' +
      '</div>';
    return;
  }

  el('driverCall').innerHTML =
    '<div class="msg"><b>✓ Pagamento em dinheiro confirmado</b>' +
    (data?.amount != null
      ? `<br>R$ ${money(data.amount)} registrado como pago.`
      : '') +
    '</div>';
}

async function setAvailability(available) {
  const sb = window.supabaseClient;
  const user = window.currentUser;

  if (!sb || !user) return false;

  if (available) {
    try { await getDriverPosition(); }
    catch (error) {
      const note=el('driverJourneyStatus');
      if(note)note.textContent='Para ficar online, permita o GPS preciso neste aparelho e tente novamente.';
      if(el('driverGps'))el('driverGps').textContent=error.message||'GPS indisponível.';
      return false;
    }
  }
  const { error } = await sb.rpc(
    'set_driver_availability',
    { p_available: !!available }
  );

  if (error) {
    el('driverStatus') &&
      (el('driverStatus').textContent = 'Offline');
    el('driverGps') &&
      (el('driverGps').textContent = error.message || 'Não foi possível ficar disponível.');
    const note=el('driverJourneyStatus');if(note)note.textContent=error.message||'Não foi possível ficar disponível.';
    window.refreshAppContext?.().then(window.renderMode).catch(()=>{});
    return false;
  }

  driverAvailable = !!available;
  window.onVaiDriverAvailabilityChanged?.(driverAvailable);

  if (driverAvailable) {
    try {
      if(window.VAI_NATIVE_APP)await window.VaiNativeLocation.start();
      await gpsEngine.start({
      onStatus: ({ status, point, code }) => {
        const gps = el('driverGps');
        const sync = el('driverLocationSync');

        if(status==='geolocation-error' && code===1){
          setAvailability(false).then(()=>{const note=el('driverJourneyStatus');if(note)note.textContent='GPS negado. Autorize a localização nas configurações do aparelho e tente novamente.';}).catch(()=>{});
        }
        if (status === 'published') {
          if (gps && point) {
            gps.textContent =
              `GPS ativo • precisão ±${Math.round(point.accuracy || 0)} m`;
          }
          if (sync) sync.textContent = '✓ GPS sincronizado';
        } else if (
          status === 'offline-buffered' ||
          status === 'queued'
        ) {
          if (sync) {
            sync.textContent =
              '⚠ Sem conexão • GPS armazenado para sincronização';
          }
        }
      }
    }); } catch(error){
      if(window.VAI_NATIVE_APP)await window.VaiNativeLocation.stop().catch(()=>{});
      gpsEngine.stop();driverAvailable=false;window.onVaiDriverAvailabilityChanged?.(false);
      await sb.rpc('set_driver_availability',{p_available:false});
      const note=el('driverJourneyStatus');if(note)note.textContent='Não foi possível iniciar o GPS: '+(error.message||'tente novamente.');
      updateDriverControls();return false;
    }

    startOfferMonitoring();
    await loadDriverRequests();
    await window.loadDriverTourRequests?.();

  } else {
    stopOfferMonitoring();
    gpsEngine.stop();
    if(window.VAI_NATIVE_APP)await window.VaiNativeLocation.stop().catch(console.warn);

    await sb.rpc('set_driver_availability', {
      p_available: false
    });

    stopCallAlert();

    if (el('driverCall')) el('driverCall').innerHTML = '';
    if (el('driverStatus')) el('driverStatus').textContent = 'Offline';
    if (el('driverGps')) el('driverGps').textContent =
      'Aguardando disponibilidade.';
    if (el('driverLocationSync')) el('driverLocationSync').textContent =
      'Localização não publicada enquanto estiver offline.';
  }

  updateDriverControls();window.updateDriverJourney?.();
  return true;
}

function updateDriverControls() {
  const button = el('driverToggle');
  const status = el('driverStatus');

  if (button) {
    button.textContent =
      driverAvailable ? 'Ficar offline' : 'Ficar disponível';
  }

  if (status) {
    status.textContent =
      driverAvailable ? 'Disponível' : 'Offline';
    status.style.color =
      driverAvailable ? '#16a34a' : '#667085';
  }
}

async function toggleDriver() {
  if (!window.currentUser) {
    if (typeof window.ensureUser === 'function') {
      await window.ensureUser(true);
    }
  }

  if (!window.currentUser || !window.supabaseClient) return;

  await setAvailability(!driverAvailable);
}

function startOfferMonitoring() {
  stopOfferMonitoring();

  const sb = window.supabaseClient;
  const user = window.currentUser;

  if (!sb || !user) return;

  offerChannel = sb.channel(`driver-offers-v40-${user.id}`)
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'rides',
        filter: 'status=eq.requested'
      },
      () => loadDriverRequests()
    )
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'rides',
        filter: `driver_id=eq.${user.id}`
      },
      payload => {
        const ride = payload.new;

        if (ride?.driver_id === user.id) {
          window.activeDriverRide = ride;

          if (ride.status !== 'requested') {
            stopCallAlert();
            window.renderDriverRideState(ride);
          }
        }
      }
    )
    .on('postgres_changes',{
      event:'INSERT',schema:'public',table:'tour_bookings',filter:'status=eq.requested'
    },()=>window.loadDriverTourRequests?.())
    .subscribe();

  offerPoll = setInterval(() => {
    if (driverAvailable){loadDriverRequests();window.loadDriverTourRequests?.()}
  }, state.pollMs);
}

function stopOfferMonitoring() {
  if (offerPoll) {
    clearInterval(offerPoll);
    offerPoll = null;
  }

  if (offerChannel && window.supabaseClient) {
    window.supabaseClient.removeChannel(offerChannel);
  }

  offerChannel = null;
}

async function subscribeWebPush(vapidPublicKey) {
  if(window.VAI_NATIVE_APP)return window.VaiNativePush.register();
  vapidPublicKey = String(vapidPublicKey || window.VAI_VAPID_PUBLIC_KEY || '').trim();
  if (
    !('serviceWorker' in navigator) ||
    !('PushManager' in window) ||
    !window.supabaseClient ||
    !window.currentUser
  ) {
    throw new Error('Web Push não é suportado neste navegador.');
  }

  const registration = await navigator.serviceWorker.ready;

  const permission = await Notification.requestPermission();
  if (permission !== 'granted') {
    throw new Error('Permissão de notificação não concedida.');
  }

  let subscription =
    await registration.pushManager.getSubscription();

  if (!subscription) {
    if (!vapidPublicKey) {
      throw new Error(
        'Informe a chave pública VAPID antes de criar a subscription.'
      );
    }

    const applicationServerKey =
      urlBase64ToUint8Array(vapidPublicKey);

    subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey
    });
  }

  const json = subscription.toJSON();

  const { error } = await window.supabaseClient
    .from('push_subscriptions')
    .upsert({
      user_id: window.currentUser.id,
      endpoint: json.endpoint,
      p256dh: json.keys?.p256dh || '',
      auth: json.keys?.auth || '',
      user_agent: navigator.userAgent
    }, {
      onConflict: 'user_id,endpoint'
    });

  if (error) throw error;

  const { error: preferenceError } = await window.supabaseClient
    .from('notification_preferences')
    .upsert({
      user_id: window.currentUser.id,
      push_enabled: true
    });
  if (preferenceError) throw preferenceError;

  return subscription;
}

async function unsubscribeWebPush() {
  if(window.VAI_NATIVE_APP)return window.VaiNativePush.unregister();
  const registration = await navigator.serviceWorker?.ready;
  const subscription =
    await registration?.pushManager?.getSubscription();

  if (!subscription) return;

  const endpoint = subscription.endpoint;

  await subscription.unsubscribe();

  if (window.supabaseClient && window.currentUser) {
    await window.supabaseClient
      .from('push_subscriptions')
      .delete()
      .eq('user_id', window.currentUser.id)
      .eq('endpoint', endpoint);

    await window.supabaseClient
      .from('notification_preferences')
      .upsert({
        user_id: window.currentUser.id,
        push_enabled: false
      });
  }
}

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');

  const rawData = atob(base64);
  return Uint8Array.from([...rawData].map(char => char.charCodeAt(0)));
}

async function handleServiceWorkerMessage(event) {
  const data = event.data || {};

  if (data.type !== 'RIDE_NOTIFICATION_ACTION') return;
  if (!data.rideId) return;

  if (data.action === 'accept') {
    await acceptRide(data.rideId);
  }

  if (data.action === 'reject') {
    await rejectRide(data.rideId);
  }
}

async function handleDeepLinkAction() {
  const params = new URLSearchParams(location.search);
  const action = params.get('action');
  const rideId = params.get('ride_id');

  if (!rideId || !action) return;

  // Remove os parâmetros sem recarregar a página.
  history.replaceState({}, document.title, location.pathname);

  if (action === 'accept-ride') {
    await acceptRide(rideId);
  } else if (action === 'reject-ride') {
    await rejectRide(rideId);
  }
}

function bindLegacyGlobals() {
  window.toggleDriver = toggleDriver;
  window.acceptRealCall = acceptRide;
  window.setRideStatus = setRideStatus;
  window.acceptDriverCall = acceptRide;
  window.renderDriverRideState = renderDriverRideState;
  window.startDriverOfferMonitoring = startOfferMonitoring;
  window.stopDriverOfferMonitoring = stopOfferMonitoring;
  window.loadDriverRequests = loadDriverRequests;
  window.subscribeWebPush = subscribeWebPush;
  window.unsubscribeWebPush = unsubscribeWebPush;
  window.vaiComigoDriver = {
    toggleDriver,
    setAvailability,
    loadDriverRequests,
    acceptRide,
    rejectRide,
    setRideStatus,
    subscribeWebPush,
    unsubscribeWebPush,
    startOfferMonitoring,
    stopOfferMonitoring
  };
}

async function init() {
  if (initialized) return;
  initialized = true;

  if (!window.VAI_NATIVE_APP && 'serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js', {
      scope: './'
    }).catch(() => {});

    navigator.serviceWorker.addEventListener(
      'message',
      handleServiceWorkerMessage
    );
  }

  // O app atual inicializa auth de forma assíncrona; só tentamos monitorar
  // depois que a sessão existir.
  window.addEventListener('online', () => {
    if (driverAvailable) loadDriverRequests();
  });

  window.addEventListener('pointerdown', () => {
    // Garante que um gesto do motorista possa desbloquear o AudioContext.
    if (audioContext?.state === 'suspended') {
      audioContext.resume().catch(() => {});
    }
  }, { passive: true });

  bindLegacyGlobals();

  // URL de ação gerada pelo SW quando a página estava fechada.
  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', handleDeepLinkAction, {
      once: true
    });
  } else {
    handleDeepLinkAction();
  }
}

init().catch(error=>console.warn('Motorista',error));

})();
