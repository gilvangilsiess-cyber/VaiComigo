(function(){
'use strict';
/* VaiComigo — Diagnóstico E2E
 * Abre com ?diag=1, com environment:'test' em js/config.js (botão no Perfil) ou VaiDiag.open().
 * Regra: nada é marcado OK sem evidência. Sem evidência = PENDENTE; sem configuração = BLOQUEADO.
 * Não guarda nem exibe segredos (só prefixo/tipo da chave pública).
 */
const ST = {
  ok: ['✅', 'OK'],
  fail: ['❌', 'FALHOU'],
  blocked: ['⛔', 'BLOQUEADO — configuração externa necessária'],
  pending: ['⏳', 'PENDENTE'],
  warn: ['⚠️', 'ATENÇÃO'],
  na: ['➖', 'N/A neste celular']
};

const RPC_FILE = {
  get_my_app_context: 'v38-integration-hardening.sql',
  get_test_mode: 'v46-test-lab.sql',
  test_prepare_my_driver: 'v46-test-lab.sql',
  test_e2e_report: 'v47-e2e-support.sql',
  register_driver: 'v47-e2e-support.sql',
  cancel_ride: 'v47-e2e-support.sql',
  create_ride_quote: 'v33-auth-fare-payment.sql / v46-test-lab.sql',
  set_driver_availability: 'v30-driver-availability-admin.sql',
  update_driver_location: 'v41-production-hardening.sql',
  nearest_requested_rides: 'v21-ride-flow.sql',
  accept_ride: 'v38-integration-hardening.sql',
  update_ride_status: 'v38-integration-hardening.sql',
  complete_ride: 'v26-history-receipt.sql',
  confirm_cash_payment: 'v27-payment-finance.sql',
  sync_external_payment: 'v45-payment-state-hardening.sql',
  push_ride_candidates: 'v41-production-hardening.sql'
};

const TABLE_FILE = {
  profiles: 'schema base (anterior à v12 — não vem no ZIP)',
  drivers: 'schema base (anterior à v12 — não vem no ZIP)',
  rides: 'schema base (anterior à v12 — não vem no ZIP)',
  platform_settings: 'v28-driver-finance.sql',
  payment_transactions: 'v27-payment-finance.sql',
  push_subscriptions: 'v40-notifications.sql',
  driver_location_history: 'v41-production-hardening.sql',
  ride_push_queue: 'v41-production-hardening.sql'
};

const r = (status, message, extra = {}) => ({ status, message, ...extra });
const sb = () => window.supabaseClient;
const fmtTime = v => (v ? new Date(v).toLocaleTimeString('pt-BR') : '—');
const ageSec = v => (v ? Math.round((Date.now() - new Date(v).getTime()) / 1000) : null);
const short = id => (id ? String(id).slice(0, 8) : '—');

function classify(err, fn, file) {
  const m = String(err?.message || err || '');
  const c = String(err?.code || '');
  const all = m + ' ' + c;
  if (/Could not find the function|PGRST202|42883/.test(all))
    return { cause: `A função ${fn} não existe no banco: migração não aplicada.`, file: RPC_FILE[fn] || file };
  if (/PGRST205|42P01|does not exist|Could not find the table/.test(all))
    return { cause: 'Tabela ausente: migração/schema base não aplicado.', file: file || TABLE_FILE[fn] };
  if (/permission denied|42501|row-level security/i.test(all))
    return { cause: 'Permissão/RLS negou o acesso (política ou grant ausente).', file: file || RPC_FILE[fn] };
  if (/JWT|401|invalid claim|expired/i.test(all))
    return { cause: 'Sessão inválida/expirada ou chave anon de outro projeto.', file: 'js/config.js' };
  if (/Failed to fetch|NetworkError|Load failed/i.test(all))
    return { cause: 'Sem rede, CORS ou URL do Supabase incorreta.', file: 'js/config.js' };
  return { cause: 'Erro não classificado — veja a mensagem.', file: file || RPC_FILE[fn] || '—' };
}
const failFrom = (label, err, fn, file) => {
  const c = classify(err, fn, file);
  return r('fail', label, { error: String(err?.message || err), cause: c.cause, file: c.file });
};

async function rpc(name, args) {
  const { data, error } = await sb().rpc(name, args);
  return { data, error };
}

// IndexedDB do SW (evidência de push). Cria os mesmos stores caso o banco ainda não exista.
function readLastPush() {
  return new Promise(resolve => {
    try {
      const req = indexedDB.open('vai-comigo-gps-v1', 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('queue')) {
          const st = db.createObjectStore('queue', { keyPath: 'id', autoIncrement: true });
          st.createIndex('created_at', 'created_at', { unique: false });
        }
        if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta', { keyPath: 'key' });
      };
      req.onerror = () => resolve(null);
      req.onsuccess = () => {
        try {
          const g = req.result.transaction('meta', 'readonly').objectStore('meta').get('last_push');
          g.onsuccess = () => resolve(g.result?.value || null);
          g.onerror = () => resolve(null);
        } catch (_) { resolve(null); }
      };
    } catch (_) { resolve(null); }
  });
}

async function fnStatus(name, body) {
  const { error } = await sb().functions.invoke(name, { body });
  if (!error) return { status: 200, body: {} };
  const status = error.context?.status;
  let payload = {};
  try { payload = await error.context.json(); } catch (_) {}
  return { status, body: payload, message: error.message };
}

async function latestRide(ctx) {
  const col = ctx.role === 'driver' ? 'driver_id' : 'passenger_id';
  const base = 'id,created_at,status,payment_method,payment_status,driver_id,accepted_at,arrived_at,started_at,completed_at,cancelled_at,final_price,estimated_price';
  let q = await sb().from('rides').select(base + ',test_run').eq(col, ctx.user.id)
    .order('created_at', { ascending: false }).limit(1).maybeSingle();
  if (q.error) {
    q = await sb().from('rides').select(base).eq(col, ctx.user.id)
      .order('created_at', { ascending: false }).limit(1).maybeSingle();
  }
  return q;
}

const needSession = ctx => (!sb() ? r('blocked', 'Supabase não configurado (item 1).', { file: 'js/config.js' })
  : !ctx.user ? r('pending', 'Sem sessão neste celular: entre ou crie a conta.') : null);

const CHECKS = [
  /* ---------------- Checklist E2E ---------------- */
  { id: 'supabase', group: 'E2E', title: 'Supabase conectado', async run(ctx) {
    const cfg = window.VAI_CONFIG || {};
    if (!cfg.supabaseUrl || !cfg.supabaseAnonKey)
      return r('blocked', 'supabaseUrl/supabaseAnonKey vazios.', {
        cause: 'Credenciais públicas não foram preenchidas no deploy.',
        file: 'js/config.js (ou variáveis SUPABASE_URL / SUPABASE_ANON_KEY no Netlify)' });
    const key = cfg.supabaseAnonKey;
    if (/^sb_secret_/.test(key)) return r('fail', 'Chave SECRETA no frontend.', { cause: 'Foi colocada uma sb_secret_* em config.js.', file: 'js/config.js' });
    if (key.split('.').length === 3) {
      try {
        const role = JSON.parse(atob(key.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).role;
        if (role !== 'anon') return r('fail', `Chave com role="${role}" no frontend.`, { cause: 'service_role/outra chave secreta exposta.', file: 'js/config.js' });
      } catch (_) { return r('fail', 'Chave anon ilegível.', { cause: 'JWT inválido.', file: 'js/config.js' }); }
    }
    if (!sb()) return r('fail', 'Cliente Supabase não foi criado.', { cause: 'CDN do supabase-js não carregou.', file: 'index.html' });
    try {
      const h = await fetch(cfg.supabaseUrl + '/auth/v1/health', { headers: { apikey: key } });
      if (!h.ok) return r('fail', `Auth respondeu HTTP ${h.status}.`, { cause: 'URL/chave de projetos diferentes ou projeto pausado.', file: 'js/config.js' });
      const s = await fetch(cfg.supabaseUrl + '/auth/v1/settings', { headers: { apikey: key } });
      ctx.settings = s.ok ? await s.json() : null;
    } catch (e) { return failFrom('Não alcançou o servidor.', e, 'connect', 'js/config.js'); }
    const kind = key.startsWith('sb_publishable_') ? 'publishable' : 'anon';
    return r('ok', `Servidor alcançado (${new URL(cfg.supabaseUrl).host}, chave ${kind}).`);
  } },

  { id: 'auth', group: 'E2E', title: 'Autenticação funcionando', async run(ctx) {
    if (!sb()) return r('blocked', 'Depende do item 1.');
    const { data } = await sb().auth.getSession();
    if (!data?.session) return r('pending', 'Nenhuma sessão: entre ou crie a conta neste celular.');
    const { data: u, error } = await sb().auth.getUser();
    if (error || !u?.user) return failFrom('Servidor rejeitou a sessão.', error, 'auth.getUser', 'js/config.js');
    ctx.user = u.user;
    return r('ok', `Sessão validada pelo servidor (${u.user.email || short(u.user.id)}).`);
  } },

  { id: 'signup', group: 'E2E', title: 'Criação de usuário', async run(ctx) {
    const s = ctx.settings;
    if (!s) return sb() ? r('pending', 'Configuração de Auth não pôde ser lida.') : r('blocked', 'Depende do item 1.');
    if (s.disable_signup) return r('fail', 'Cadastro de novos usuários está desativado.', { cause: 'Auth → "Allow new users to sign up" desligado.', file: 'Painel Supabase → Authentication' });
    if (s.external && s.external.email === false) return r('fail', 'Provedor de e-mail desativado.', { cause: 'Auth → Providers → Email desligado.', file: 'Painel Supabase → Authentication' });
    const confirm = s.mailer_autoconfirm === false;
    if (ctx.user) return r(confirm ? 'warn' : 'ok', `Conta existente criada em ${new Date(ctx.user.created_at).toLocaleString('pt-BR')}.` + (confirm ? ' Confirmação de e-mail está LIGADA (novas contas só entram após confirmar).' : ''));
    return r(confirm ? 'warn' : 'pending', confirm
      ? 'Cadastro habilitado, mas a confirmação de e-mail está ligada: no projeto de TESTE desligue "Confirm email".'
      : 'Cadastro habilitado e sem confirmação de e-mail (configuração lida do servidor). A criação real só é comprovada quando a conta existir.');
  } },

  { id: 'profile', group: 'E2E', title: 'Criação de perfil', async run(ctx) {
    const n = needSession(ctx); if (n) return n;
    const { data, error } = await sb().from('profiles').select('id,full_name,role').eq('id', ctx.user.id).maybeSingle();
    if (error) return failFrom('Não leu profiles.', error, 'profiles');
    if (!data) return r('fail', 'Usuário autenticado sem linha em profiles.', { cause: 'ensureProfileData não gravou (política de INSERT em profiles?).', file: 'app.js (ensureProfileData) / schema base' });
    return r('ok', `Perfil ${data.full_name || '(sem nome)'} • papel ${data.role || 'passenger'}.`);
  } },

  { id: 'passenger', group: 'E2E', title: 'Passageiro funcionando', async run(ctx) {
    const n = needSession(ctx); if (n) return n;
    const a = await rpc('get_my_app_context');
    if (a.error) return failFrom('get_my_app_context falhou.', a.error, 'get_my_app_context');
    ctx.appCtx = a.data;
    // Sonda: validação recusa distância negativa ANTES do INSERT, sem criar corrida.
    const p = await rpc('create_ride_quote', { p_origin_lat: 0, p_origin_lng: 0, p_destination_name: '[DIAG] sonda', p_distance_km: -1, p_duration_min: 1, p_payment_method: 'cash' });
    if (!p.error) {
      if (p.data?.id) await rpc('cancel_ride', { p_ride_id: p.data.id });
      return r('warn', 'create_ride_quote aceitou distância negativa (sonda cancelada).', { cause: 'Validação alterada.', file: 'v46-test-lab.sql' });
    }
    if (!/Distância inválida/.test(p.error.message)) return failFrom('create_ride_quote inacessível.', p.error, 'create_ride_quote');
    return r('ok', 'Contexto carregado e create_ride_quote acessível/validando (nenhuma corrida criada).');
  } },

  { id: 'driver', group: 'E2E', title: 'Motorista funcionando', async run(ctx) {
    if (ctx.role !== 'driver') return r('na', 'Selecione "Motorista" acima no celular do motorista.');
    const n = needSession(ctx); if (n) return n;
    if (!ctx.appCtx) { const a = await rpc('get_my_app_context'); if (a.error) return failFrom('get_my_app_context falhou.', a.error, 'get_my_app_context'); ctx.appCtx = a.data; }
    if (!ctx.appCtx?.has_driver_profile) return r('pending', 'Sem cadastro de motorista: Perfil → Cadastrar motorista (ou Preparar como motorista de teste).');
    return r('ok', `Cadastro de motorista existe (documentos: ${ctx.appCtx.driver_document_status || '—'}).`);
  } },

  { id: 'approval', group: 'E2E', title: 'Aprovação de teste funcionando', async run(ctx) {
    const n = needSession(ctx); if (n) return n;
    const t = await rpc('get_test_mode');
    if (t.error) return failFrom('get_test_mode falhou.', t.error, 'get_test_mode');
    ctx.testMode = t.data === true;
    if (!ctx.testMode) {
      const g = await rpc('test_prepare_my_driver', {});
      let guard;
      if (!g.error) guard = 'ALERTA: a preparação de teste FUNCIONOU com o laboratório desligado (aprovação automática vazando).';
      else if (/desligado/i.test(g.error.message)) guard = 'Trava de produção verificada: a aprovação automática foi recusada.';
      else guard = 'Trava não confirmada: ' + g.error.message;
      if (!g.error) return r('fail', guard, { cause: 'test_prepare_my_driver não checa test_mode.', file: 'v46-test-lab.sql' });
      return r('blocked', `Laboratório DESLIGADO. ${guard}`, { cause: 'Modo de teste é opt-in.', file: "SQL: update public.platform_settings set test_mode_enabled=true where id=true;" });
    }
    if (ctx.role !== 'driver') return r('na', 'Laboratório LIGADO (corridas serão marcadas como teste).');
    if (ctx.appCtx?.driver_document_status === 'approved') return r('ok', 'Laboratório ligado e motorista aprovado.');
    return r('pending', 'Laboratório ligado, mas o motorista ainda não está aprovado: use "Preparar esta conta como motorista de teste" ou Cadastrar motorista.');
  } },

  { id: 'online', group: 'E2E', title: 'Motorista online', async run(ctx) {
    if (ctx.role !== 'driver') return r('na', 'Item do celular do motorista.');
    const n = needSession(ctx); if (n) return n;
    const a = await rpc('get_my_app_context'); if (a.error) return failFrom('get_my_app_context falhou.', a.error, 'get_my_app_context');
    ctx.appCtx = a.data;
    const s = a.data?.driver_status;
    if (s === 'available' || s === 'busy') return r('ok', `Status no servidor: ${s}.`);
    if (s === 'suspended') return r('fail', 'Motorista suspenso.', { cause: 'Status suspended.', file: 'v37-admin-operations.sql' });
    return r('pending', `Status no servidor: ${s || 'sem cadastro'}. Toque em "Ficar disponível".`);
  } },

  { id: 'gps', group: 'E2E', title: 'GPS funcionando', async run(ctx) {
    if (!window.isSecureContext) return r('fail', 'Página fora de HTTPS.', { cause: 'GPS/Push exigem contexto seguro.', file: 'Netlify (use https://)' });
    if (!navigator.geolocation) return r('fail', 'Navegador sem geolocalização.', { cause: 'Navegador não suportado.', file: '—' });
    try {
      const st = await navigator.permissions?.query({ name: 'geolocation' });
      if (st?.state === 'denied') return r('fail', 'Permissão de localização negada.', { cause: 'Bloqueada nas configurações do navegador.', file: 'Ajustes do navegador' });
    } catch (_) {}
    const pos = await new Promise(res => navigator.geolocation.getCurrentPosition(p => res({ p }), e => res({ e }), { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }));
    if (pos.e) return r('fail', `Não obteve posição: ${pos.e.message}`, { cause: pos.e.code === 1 ? 'Permissão negada.' : 'Sinal indisponível/timeout.', file: 'js/modules/gps-engine.js' });
    ctx.pos = pos.p.coords;
    const local = `Posição obtida (±${Math.round(pos.p.coords.accuracy)} m).`;
    if (ctx.role !== 'driver') return r('ok', local);
    const n = needSession(ctx); if (n) return r('ok', local + ' Servidor: sem sessão.');
    const d = await sb().from('drivers').select('lat,lng,location_updated_at').eq('id', ctx.user.id).maybeSingle();
    if (d.error) return failFrom('Não leu a posição publicada.', d.error, 'drivers');
    const age = ageSec(d.data?.location_updated_at);
    const online = ['available', 'busy'].includes(ctx.appCtx?.driver_status);
    if (age == null) return r(online ? 'fail' : 'pending', local + ' Nada publicado no servidor ainda.', online ? { cause: 'update_driver_location não chegou ao banco.', file: 'js/modules/gps-engine.js / v41-production-hardening.sql' } : {});
    if (age > 180) return r(online ? 'fail' : 'pending', `${local} Posição publicada há ${age}s (limite de elegibilidade: 180s).`, online ? { cause: 'Publicação parou (app em segundo plano/aba suspensa).', file: 'js/modules/gps-engine.js (heartbeat)' } : {});
    return r('ok', `${local} Publicada no servidor há ${age}s.`);
  } },

  { id: 'ride', group: 'E2E', title: 'Criação de corrida', async run(ctx) {
    const n = needSession(ctx); if (n) return n;
    if (ctx.role === 'driver') {
      const mine = await latestRide(ctx);
      if (mine.data) { ctx.ride = mine.data; return r('ok', `Corrida ${short(mine.data.id)} atribuída a este motorista (${mine.data.status}).`); }
      if (ctx.pos) {
        const q = await rpc('nearest_requested_rides', { p_lat: ctx.pos.latitude, p_lng: ctx.pos.longitude, p_radius_km: 10 });
        if (q.error) return failFrom('nearest_requested_rides falhou.', q.error, 'nearest_requested_rides');
        if (q.data?.length) return r('ok', `${q.data.length} corrida(s) solicitada(s) visível(is) a menos de 10 km.`);
      }
      return r('pending', 'Nenhuma corrida solicitada num raio de 10 km ainda.');
    }
    const q = await latestRide(ctx);
    if (q.error) return failFrom('Não leu rides.', q.error, 'rides');
    if (!q.data) return r('pending', 'Nenhuma corrida criada por esta conta.');
    ctx.ride = q.data;
    const extra = ctx.testMode && q.data.test_run === false ? ' Não foi marcada como teste.' : '';
    return r(extra ? 'warn' : 'ok', `Corrida ${short(q.data.id)} criada às ${fmtTime(q.data.created_at)} (${q.data.status}, ${q.data.payment_method}).${extra}`, extra ? { cause: 'create_ride_quote sem a coluna test_run.', file: 'v46-test-lab.sql' } : {});
  } },

  { id: 'found', group: 'E2E', title: 'Motorista encontrado', async run(ctx) {
    const n = needSession(ctx); if (n) return n;
    if (!ctx.testMode) return r('blocked', 'Relatório de despacho exige laboratório ligado.', { file: 'v47-e2e-support.sql (test_e2e_report)' });
    const rep = ctx.report;
    if (ctx.reportErr) return failFrom('test_e2e_report falhou.', ctx.reportErr, 'test_e2e_report');
    if (!rep?.has_ride) return r('pending', 'Sem corrida visível para esta conta (conclusivo no celular da passageira).');
    if (rep.ride.has_driver) return r('ok', 'Motorista atribuído à corrida.');
    const d = rep.dispatch;
    if (rep.ride.status !== 'requested') return r('pending', `Corrida ${rep.ride.status}.`);
    if (d.eligible_now > 0) return r('ok', `${d.eligible_now} motorista(s) elegível(is) agora (${d.eligible_with_push_subscription} com push).`);
    if (d.available_nearby_any_gps_age > 0) return r('fail', 'Há motorista disponível perto, mas com GPS desatualizado (>180s).', { cause: 'Publicação de GPS parada.', file: 'js/modules/gps-engine.js' });
    if (d.available_total === 0) return r('fail', 'Nenhum motorista com status "available".', { cause: 'Motorista offline, não aprovado ou não ficou disponível.', file: 'app.js/driver.js (toggleDriver) / v30' });
    return r('fail', 'Motoristas disponíveis, mas fora do raio de 10 km.', { cause: 'Origem da corrida longe do motorista.', file: 'v41-production-hardening.sql (push_ride_candidates)' });
  } },

  { id: 'queue', group: 'E2E', title: 'Fila de push', async run(ctx) {
    const n = needSession(ctx); if (n) return n;
    if (!ctx.testMode) return r('blocked', 'Leitura da fila exige laboratório ligado.', { file: 'v47-e2e-support.sql' });
    if (ctx.reportErr) return failFrom('test_e2e_report falhou.', ctx.reportErr, 'test_e2e_report');
    const q = ctx.report?.push_queue;
    if (!ctx.report?.has_ride) return r('pending', 'Sem corrida visível.');
    if (!q?.exists) return r('fail', 'Corrida sem item na fila.', { cause: 'Trigger trg_enqueue_ride_push ausente.', file: 'v41-production-hardening.sql' });
    if (q.processed_at) return r('ok', `Fila processada às ${fmtTime(q.processed_at)} (tentativas: ${q.attempts}).`);
    if (/VAPID/i.test(q.last_error || '')) return r('blocked', q.last_error, { cause: 'Secrets VAPID ausentes na Edge Function.', file: 'supabase/functions/push-notify (Secrets)' });
    if (q.last_error) {
      const soft = /Nenhum motorista elegível|sem inscrição/i.test(q.last_error);
      return r(soft ? 'warn' : 'fail', `Última tentativa: ${q.last_error} (tentativas ${q.attempts}/${q.max_attempts}, próxima ${fmtTime(q.next_attempt_at)}).`, { cause: soft ? 'Fila funciona; falta motorista elegível/inscrito.' : 'Erro na Edge Function.', file: 'supabase/functions/push-notify/index.ts' });
    }
    if ((ageSec(q.created_at) || 0) < 20) return r('pending', 'Aguardando o primeiro processamento.');
    return r('blocked', 'Ninguém processou a fila (0 tentativas).', { cause: 'push-notify não implantada/inalcançável; sem Webhook/cron para retry.', file: 'supabase/functions/push-notify + Database Webhook' });
  } },

  { id: 'push', group: 'E2E', title: 'Push', async run(ctx) {
    const n = needSession(ctx); if (n) return n;
    if (ctx.role !== 'driver') {
      if (!ctx.testMode) return r('blocked', 'Evidência do servidor exige laboratório ligado.');
      const q = ctx.report?.push_queue, rd = ctx.report?.ride;
      if (!q?.exists) return r('pending', 'Sem fila para avaliar.');
      const cut = [rd.accepted_at, rd.cancelled_at].filter(Boolean).map(x => new Date(x).getTime());
      const before = q.processed_at && (!cut.length || new Date(q.processed_at).getTime() < Math.min(...cut));
      return before ? r('ok', 'Servidor entregou push ao serviço enquanto a corrida estava solicitada.') : r('pending', 'Sem confirmação de entrega (veja o celular do motorista).');
    }
    if (!window.VAI_CONFIG?.vapidPublicKey) return r('blocked', 'vapidPublicKey ausente.', { cause: 'Chave pública VAPID não configurada.', file: 'js/config.js' });
    const perm = 'Notification' in window ? Notification.permission : 'unsupported';
    if (perm === 'unsupported') return r('fail', 'Navegador sem Notification.', { cause: 'iOS exige PWA instalado na tela inicial.', file: '—' });
    if (perm === 'denied') return r('fail', 'Notificações bloqueadas.', { cause: 'Permissão negada.', file: 'Ajustes do navegador' });
    const reg = await navigator.serviceWorker?.getRegistration();
    const sub = await reg?.pushManager?.getSubscription();
    if (perm !== 'granted' || !sub) return r('pending', 'Alertas não ativados neste aparelho (Ativar alertas de corrida).');
    const row = await sb().from('push_subscriptions').select('id', { count: 'exact', head: true }).eq('user_id', ctx.user.id);
    if (row.error) return failFrom('Não leu push_subscriptions.', row.error, 'push_subscriptions');
    if (!row.count) return r('fail', 'Inscrição existe no aparelho mas não no banco.', { cause: 'subscribeWebPush não gravou.', file: 'js/modules/driver.js (subscribeWebPush)' });
    const lp = await readLastPush();
    const since = ctx.ride ? new Date(ctx.ride.created_at).getTime() : Date.now() - 15 * 60000;
    if (lp && lp.at >= since) return r('ok', `Push recebido neste aparelho às ${fmtTime(lp.at)}.`);
    return r('pending', 'Inscrito e pronto; ainda não chegou push desde a última corrida.');
  } },

  { id: 'accept', group: 'E2E', title: 'Aceite', async run(ctx) {
    const n = needSession(ctx); if (n) return n;
    const q = ctx.ride || (await latestRide(ctx)).data;
    if (!q) return r('pending', 'Sem corrida.');
    ctx.ride = q;
    if (q.driver_id && q.accepted_at) return r('ok', `Aceita às ${fmtTime(q.accepted_at)} (accept_ride atômico).`);
    return r('pending', `Status ${q.status}: aguardando aceite.`);
  } },

  { id: 'status', group: 'E2E', title: 'Atualização de status', async run(ctx) {
    const q = ctx.ride; if (!q) return r('pending', 'Sem corrida.');
    if (q.arrived_at && q.started_at) return r('ok', `a caminho ${fmtTime(q.arrived_at)} → em andamento ${fmtTime(q.started_at)}.`);
    if (q.status === 'cancelled') return r('warn', 'Corrida cancelada.');
    return r('pending', `Status ${q.status}: faltam "a caminho"/"iniciar".`);
  } },

  { id: 'finish', group: 'E2E', title: 'Finalização', async run(ctx) {
    const q = ctx.ride; if (!q) return r('pending', 'Sem corrida.');
    if (q.status === 'completed' && q.completed_at) return r('ok', `Finalizada às ${fmtTime(q.completed_at)} (valor ${q.final_price ?? q.estimated_price ?? '—'}).`);
    return r('pending', `Status ${q.status}.`);
  } },

  { id: 'payment', group: 'E2E', title: 'Pagamento de teste', async run(ctx) {
    const q = ctx.ride; if (!q) return r('pending', 'Sem corrida.');
    if (q.status !== 'completed') return r('pending', 'Só após finalizar a corrida.');
    if (q.payment_status === 'paid') return r('ok', `Pago (${q.payment_method}).`);
    if (q.payment_method === 'cash') return r('pending', 'Motorista deve tocar "Confirmar recebimento em dinheiro".');
    const p = await fnStatus('create-payment', {});
    if (p.status === 500 && /MP_ACCESS_TOKEN/.test(JSON.stringify(p.body))) return r('blocked', 'MP_ACCESS_TOKEN não configurado.', { cause: 'Pix/cartão dependem do Mercado Pago.', file: 'supabase/functions/create-payment (Secrets) — para o teste use pagamento em dinheiro' });
    if (p.status === 400) return r('pending', 'Gateway acessível; pagamento ainda não confirmado pelo webhook.');
    return r('blocked', `create-payment respondeu ${p.status ?? 'sem resposta'}.`, { cause: 'Função não implantada ou secrets ausentes.', file: 'supabase/functions/create-payment' });
  } },

  /* ---------------- Infraestrutura e segurança ---------------- */
  { id: 'schema', group: 'INFRA', title: 'Banco: tabelas', async run(ctx) {
    const n = needSession(ctx); if (n) return n;
    const missing = [];
    for (const t of Object.keys(TABLE_FILE)) {
      const { error } = await sb().from(t).select('*', { head: true, count: 'exact' }).limit(1);
      if (error && /PGRST205|42P01|does not exist|Could not find the table/.test(error.message + error.code)) missing.push(t);
    }
    if (missing.length) return r('fail', 'Tabelas ausentes: ' + missing.join(', '), { cause: 'Migração/schema base não aplicado.', file: [...new Set(missing.map(t => TABLE_FILE[t]))].join(' | ') });
    return r('ok', 'Todas as tabelas esperadas existem.');
  } },

  { id: 'realtime', group: 'INFRA', title: 'Realtime conectado', async run() {
    if (!sb()) return r('blocked', 'Depende do item 1.');
    return new Promise(resolve => {
      const ch = sb().channel('diag-' + Math.random().toString(36).slice(2));
      let done = false;
      const end = res => { if (done) return; done = true; clearTimeout(t); try { sb().removeChannel(ch); } catch (_) {} resolve(res); };
      const t = setTimeout(() => end(r('fail', 'Não conectou em 8 s.', { cause: 'Realtime desativado, rede bloqueando WebSocket ou JWT inválido.', file: 'Painel Supabase → Realtime' })), 8000);
      ch.subscribe(s => {
        if (s === 'SUBSCRIBED') end(r('ok', 'Canal Realtime assinado.'));
        else if (['CHANNEL_ERROR', 'TIMED_OUT', 'CLOSED'].includes(s)) end(r('fail', 'Realtime: ' + s, { cause: 'Falha de WebSocket/autorização.', file: 'Painel Supabase → Realtime' }));
      });
    });
  } },

  { id: 'edge', group: 'INFRA', title: 'Edge Function push-notify', async run(ctx) {
    const n = needSession(ctx); if (n) return n;
    const f = await fnStatus('push-notify', { action: 'diag_ping' });
    if (f.status === 400) return r('ok', 'Implantada e autenticando (respondeu "ação não suportada" ao ping).');
    if (f.status === 401) return r('fail', 'Função recusou a sessão (401).', { cause: 'Sessão inválida.', file: 'supabase/functions/push-notify/index.ts' });
    if (f.status === 500) return r('fail', 'Erro interno: ' + JSON.stringify(f.body), { cause: 'Secrets ausentes (SUPABASE_SERVICE_ROLE_KEY...).', file: 'supabase/functions/push-notify/index.ts' });
    return r('blocked', `Sem resposta útil (${f.status ?? 'rede/404'}).`, { cause: 'Função não implantada.', file: 'supabase functions deploy push-notify' });
  } },

  { id: 'security', group: 'INFRA', title: 'Segurança das RPCs', async run(ctx) {
    const n = needSession(ctx); if (n) return n;
    const issues = [];
    const pay = await rpc('sync_external_payment', { p_provider: 'diag', p_provider_reference: 'diag-' + Date.now(), p_status: 'pending' });
    if (pay.error && /Transação não encontrada/.test(pay.error.message)) issues.push('usuário autenticado executa sync_external_payment');
    const cand = await rpc('push_ride_candidates', { p_ride_id: '00000000-0000-0000-0000-000000000000' });
    if (!cand.error) issues.push('usuário autenticado executa push_ride_candidates');
    const cfg = window.VAI_CONFIG || {};
    try {
      const a = await fetch(cfg.supabaseUrl + '/rest/v1/rpc/nearest_requested_rides', { method: 'POST', headers: { apikey: cfg.supabaseAnonKey, Authorization: 'Bearer ' + cfg.supabaseAnonKey, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_lat: 0, p_lng: 0, p_radius_km: 1 }) });
      if (a.ok) issues.push('visitante (anon) executa nearest_requested_rides');
    } catch (_) {}
    if (issues.length) return r('fail', issues.join('; ') + '.', { cause: 'Grants diretos a anon/authenticated não revogados.', file: 'v47-rpc-grants-hardening.sql' });
    return r('ok', 'Sondas negadas como esperado (pagamento, despacho e leitura anônima).');
  } }
];

const S = { results: {}, role: null, timer: null, running: false };

async function run() {
  if (S.running) return;
  S.running = true;
  const ctx = { role: null, user: null, testMode: false, settings: null, appCtx: null, ride: null, report: null, reportErr: null, pos: null };
  ctx.role = localStorage.getItem('vai_diag_role') || null;
  render(true);
  // Pré-carga: sessão, contexto e relatório do servidor (sem interpretar).
  try {
    if (sb()) {
      const u = await sb().auth.getUser().catch(() => ({}));
      ctx.user = u?.data?.user || null;
      if (ctx.user) {
        const a = await rpc('get_my_app_context'); ctx.appCtx = a.data || null;
        const t = await rpc('get_test_mode'); ctx.testMode = t.data === true;
        if (ctx.testMode) { const rp = await rpc('test_e2e_report'); ctx.report = rp.data; ctx.reportErr = rp.error; }
      }
    }
  } catch (_) {}
  if (!ctx.role) ctx.role = ctx.appCtx?.has_driver_profile ? 'driver' : 'passenger';
  S.role = ctx.role;
  for (const c of CHECKS) {
    try { S.results[c.id] = await c.run(ctx); }
    catch (e) { S.results[c.id] = failFrom('Exceção no diagnóstico.', e, c.id); }
    render(true);
  }
  S.ctx = ctx; S.running = false; render(false);
}

function verdict() {
  const main = CHECKS.filter(c => c.group === 'E2E').map(c => S.results[c.id]?.status);
  if (main.includes('fail')) return 'FALHOU';
  if (main.includes('blocked')) return 'BLOQUEADO';
  if (main.every(x => x === 'ok' || x === 'na')) return 'PRONTO (neste celular)';
  return 'EM ANDAMENTO';
}

function esc(s) { return String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

function reportText() {
  const cfg = window.VAI_CONFIG || {};
  const lines = [`VaiComigo — Diagnóstico E2E — ${new Date().toLocaleString('pt-BR')}`,
    `Origem: ${location.origin} | Ambiente: ${cfg.environment || '—'} | Papel: ${S.role} | Resultado: ${verdict()}`, ''];
  for (const c of CHECKS) {
    const x = S.results[c.id]; if (!x) continue;
    lines.push(`[${ST[x.status][1]}] ${c.title}: ${x.message}`);
    if (x.error) lines.push(`   Erro: ${x.error}`);
    if (x.cause) lines.push(`   Provável causa: ${x.cause}`);
    if (x.file) lines.push(`   Arquivo: ${x.file}`);
  }
  return lines.join('\n');
}

function render(running) {
  const box = document.getElementById('vaiDiagBody'); if (!box) return;
  const row = c => {
    const x = S.results[c.id];
    if (!x) return `<div class="dg"><b>⏳ ${esc(c.title)}</b></div>`;
    const [icon, label] = ST[x.status];
    const det = ['error:Erro', 'cause:Provável causa', 'file:Arquivo'].map(k => { const [f, n] = k.split(':'); return x[f] ? `<div class="dd"><i>${n}:</i> ${esc(x[f])}</div>` : ''; }).join('');
    return `<div class="dg s-${x.status}"><b>${icon} ${esc(c.title)}</b> <span class="dl">${esc(label)}</span><div>${esc(x.message)}</div>${det}</div>`;
  };
  box.innerHTML = `<div class="dv">Resultado: ${running ? 'executando…' : esc(verdict())}</div>
    <h4>Checklist E2E</h4>${CHECKS.filter(c => c.group === 'E2E').map(row).join('')}
    <h4>Infraestrutura e segurança</h4>${CHECKS.filter(c => c.group === 'INFRA').map(row).join('')}`;
}

function open() {
  let ov = document.getElementById('vaiDiag');
  if (!ov) {
    ov = document.createElement('div'); ov.id = 'vaiDiag';
    ov.innerHTML = `<style>
      #vaiDiag{position:fixed;inset:0;z-index:5000;background:#f5f7fb;overflow:auto;padding:14px;padding-top:max(14px,env(safe-area-inset-top));font:14px system-ui}
      #vaiDiag .dg{background:#fff;border:1px solid #e4e7ec;border-radius:12px;padding:10px;margin:8px 0}
      #vaiDiag .s-fail{border-color:#f04438;background:#fff5f4}#vaiDiag .s-blocked{border-color:#f79009;background:#fffaeb}
      #vaiDiag .s-ok{border-color:#12b76a}#vaiDiag .dl{font-size:11px;font-weight:700;color:#475467}
      #vaiDiag .dd{font-size:12px;color:#475467;margin-top:3px}#vaiDiag .dv{font-weight:800;font-size:16px;margin:8px 0}
      #vaiDiag button{border:0;border-radius:10px;padding:9px 12px;margin:3px;background:#101828;color:#fff;font:inherit}
      #vaiDiag button.on{background:#2563eb}</style>
      <div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:17px">🧪 Diagnóstico E2E</b><button id="dgClose">Fechar</button></div>
      <div>Este celular é: <button id="dgP">Passageira</button><button id="dgD">Motorista</button></div>
      <div><button id="dgRun">Executar</button><button id="dgAuto">Atualizar a cada 5 s</button><button id="dgCopy">Copiar relatório</button></div>
      <div id="vaiDiagBody"></div>`;
    document.body.appendChild(ov);
    const paint = () => { ov.querySelector('#dgP').classList.toggle('on', (S.role || localStorage.getItem('vai_diag_role')) !== 'driver'); ov.querySelector('#dgD').classList.toggle('on', (S.role || localStorage.getItem('vai_diag_role')) === 'driver'); };
    ov.querySelector('#dgClose').onclick = () => { clearInterval(S.timer); S.timer = null; ov.style.display = 'none'; };
    ov.querySelector('#dgRun').onclick = () => run();
    ov.querySelector('#dgP').onclick = () => { localStorage.setItem('vai_diag_role', 'passenger'); S.role = 'passenger'; paint(); run(); };
    ov.querySelector('#dgD').onclick = () => { localStorage.setItem('vai_diag_role', 'driver'); S.role = 'driver'; paint(); run(); };
    ov.querySelector('#dgAuto').onclick = e => { if (S.timer) { clearInterval(S.timer); S.timer = null; e.target.classList.remove('on'); } else { S.timer = setInterval(run, 5000); e.target.classList.add('on'); } };
    ov.querySelector('#dgCopy').onclick = async () => { try { await navigator.clipboard.writeText(reportText()); alert('Relatório copiado.'); } catch (_) { prompt('Copie o relatório:', reportText()); } };
    paint();
  }
  ov.style.display = 'block';
  run();
}

function showEntry() { const e = document.getElementById('diagEntry'); if (e) e.style.display = 'block'; }

window.VaiDiag = { open, run, showEntry, report: reportText, checks: CHECKS.map(c => c.id), results: S.results };

const q = new URLSearchParams(location.search);
if ((window.VAI_CONFIG || {}).environment === 'test' || q.get('diag') === '1') showEntry();
if (q.get('diag') === '1') window.addEventListener('load', () => setTimeout(open, 800));



})();
