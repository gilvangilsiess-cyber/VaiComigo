(function(){
'use strict';
/* VaiComigo v40 — GPS Engine
 * Captura contínua + filtragem + IndexedDB + Supabase RPC + Background Sync.
 *
 * Uso após o carregamento do script clássico:
 *   await window.VaiComigoGPS.start();
 *   window.VaiComigoGPS.stop();
 *
 * Compatibilidade:
 * - Usa window.supabaseClient e window.currentUser do app atual.
 * - Expõe window.VaiComigoGPS para facilitar integração incremental.
 */

const DB_NAME = 'vai-comigo-gps-v1';
const DB_VERSION = 1;
const STORE = 'queue';
const META = 'meta';
const SW_URL = './sw.js';
const SYNC_TAG = 'sync-gps';

let watchId = null;
let active = false;
let lastAccepted = null;
let lastPublished = null;
let flushing = false;
let initialized = false;
let heartbeatTimer = null;
let lastPublishAt = 0;

// O servidor só considera o motorista elegível para push/oferta se location_updated_at
// tiver menos de 180 s. watchPosition não dispara com o aparelho parado, então
// republicamos a posição real a cada ~40 s quando não houve publicação recente.
const HEARTBEAT_CHECK_MS = 20000;
const HEARTBEAT_STALE_MS = 40000;

const config = {
  maxAccuracy: 150,
  maxJumpMeters: 250,
  maxJumpSeconds: 3,
  queueLimit: 5000,
  minimumDistanceMeters: 4,
  minimumIntervalMs: 1500,
  onStatus: null
};

function emit(status, extra = {}) {
  try {
    config.onStatus?.({ status, ...extra });
  } catch (_) {}
  window.dispatchEvent(new CustomEvent('vai:gps-status', {
    detail: { status, ...extra }
  }));
}

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        const store = db.createObjectStore(STORE, {
          keyPath: 'id',
          autoIncrement: true
        });
        store.createIndex('created_at', 'created_at', { unique: false });
      }
      if (!db.objectStoreNames.contains(META)) {
        db.createObjectStore(META, { keyPath: 'key' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function queuePoint(point) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).add(point);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

async function getQueue() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const req = tx.objectStore(STORE).getAll();
    req.onsuccess = () => {
      resolve((req.result || []).sort((a, b) =>
        String(a.created_at).localeCompare(String(b.created_at))
      ));
    };
    req.onerror = () => reject(req.error);
  });
}

async function deleteQueueItem(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

async function trimQueue() {
  const rows = await getQueue();
  if (rows.length <= config.queueLimit) return;
  const overflow = rows.slice(0, rows.length - config.queueLimit);
  for (const row of overflow) await deleteQueueItem(row.id);
  emit('queue-trimmed', { dropped: overflow.length });
}

async function saveSupabaseConfig() {
  const sb = window.supabaseClient;
  const user = window.currentUser;

  if (!sb || !user) return;

  try {
    const { data } = await sb.auth.getSession();
    const session = data?.session;
    const cfg = window.VAI_CONFIG || {};
    const url =
      cfg.supabaseUrl ||
      sb.supabaseUrl ||
      '';
    const anonKey =
      cfg.supabaseAnonKey ||
      sb.supabaseKey ||
      '';

    if (!session?.access_token || !url || !anonKey) return;

    const db = await openDB();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(META, 'readwrite');
      tx.objectStore(META).put({
        key: 'supabase',
        value: {
          url,
          anonKey,
          accessToken: session.access_token,
          userId: user.id,
          savedAt: Date.now()
        }
      });
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });

    if (navigator.serviceWorker?.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'GPS_AUTH_UPDATE',
        url,
        anonKey,
        accessToken: session.access_token
      });
    }
  } catch (error) {
    emit('auth-cache-error', { error });
  }
}

function registerServiceWorker() {
  if (window.VAI_NATIVE_APP || !('serviceWorker' in navigator)) return;

  navigator.serviceWorker.register(SW_URL, { scope: './' })
    .then(() => navigator.serviceWorker.ready)
    .then(() => {
      emit('service-worker-ready');
      return saveSupabaseConfig();
    })
    .catch(error => emit('service-worker-error', { error }));
}

async function registerBackgroundSync() {
  try {
    const reg = await navigator.serviceWorker?.ready;
    if (reg?.sync) {
      await reg.sync.register(SYNC_TAG);
      return true;
    }
  } catch (_) {}
  return false;
}

function haversineMeters(a, b) {
  const R = 6371000;
  const p1 = Number(a.latitude ?? a.lat) * Math.PI / 180;
  const p2 = Number(b.latitude ?? b.lat) * Math.PI / 180;
  const dp =
    (Number(b.latitude ?? b.lat) - Number(a.latitude ?? a.lat)) *
    Math.PI / 180;
  const dl =
    (Number(b.longitude ?? b.lng) - Number(a.longitude ?? a.lng)) *
    Math.PI / 180;

  const x =
    Math.sin(dp / 2) ** 2 +
    Math.cos(p1) *
      Math.cos(p2) *
      Math.sin(dl / 2) ** 2;

  return 2 * R * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

function normalizePosition(position) {
  const c = position?.coords;
  if (!c) return null;

  const latitude = Number(c.latitude);
  const longitude = Number(c.longitude);
  const accuracy =
    c.accuracy == null ? null : Number(c.accuracy);
  const heading =
    Number.isFinite(c.heading) ? Number(c.heading) : null;
  const speed =
    Number.isFinite(c.speed) ? Number(c.speed) : null;

  if (
    !Number.isFinite(latitude) ||
    !Number.isFinite(longitude) ||
    latitude < -90 ||
    latitude > 90 ||
    longitude < -180 ||
    longitude > 180
  ) {
    return null;
  }

  if (accuracy != null && accuracy > config.maxAccuracy) return null;

  return {
    latitude,
    longitude,
    accuracy,
    heading,
    speed,
    created_at: new Date(
      Number(position.timestamp) || Date.now()
    ).toISOString()
  };
}

function shouldAccept(point) {
  if (!lastAccepted) return true;

  const dt =
    (Date.parse(point.created_at) -
      Date.parse(lastAccepted.created_at)) / 1000;

  const distance = haversineMeters(lastAccepted, point);

  if (
    distance > config.maxJumpMeters &&
    dt >= 0 &&
    dt < config.maxJumpSeconds
  ) {
    return false;
  }

  if (
    distance < config.minimumDistanceMeters &&
    Date.parse(point.created_at) -
      Date.parse(lastAccepted.created_at) <
      config.minimumIntervalMs
  ) {
    return false;
  }

  if (
    point.accuracy != null &&
    lastAccepted.accuracy != null &&
    point.accuracy > Math.max(100, lastAccepted.accuracy * 2)
  ) {
    return false;
  }

  return true;
}

async function publish(point) {
  const sb = window.supabaseClient;
  const user = window.currentUser;

  if (!sb || !user) return false;

  try {
    const { error } = await sb.rpc('update_driver_location', {
      p_lat: point.latitude,
      p_lng: point.longitude,
      p_accuracy: point.accuracy,
      p_heading: point.heading,
      p_speed: point.speed
    });

    if (error) {
      emit('publish-error', { error, point });
      return false;
    }

    lastPublished = point;
    lastPublishAt = Date.now();
    return true;
  } catch (error) {
    emit('publish-error', { error, point });
    return false;
  }
}

async function persist(point) {
  try {
    await queuePoint(point);
    await trimQueue();
    emit('queued', { point, queued: (await getQueue()).length });
    await registerBackgroundSync();

    if (navigator.serviceWorker?.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'GPS_QUEUE_SYNC'
      });
    }
  } catch (error) {
    emit('queue-error', { error });
  }
}

async function handlePosition(position) {
  if (!active) return;

  const point = normalizePosition(position);
  if (!point || !shouldAccept(point)) return;

  lastAccepted = point;

  const ok = await publish(point);
  if (ok) {
    emit('published', { point });
    // Tenta descarregar pontos antigos somente depois do ponto atual.
    await flush();
  } else {
    await persist(point);
    emit('offline-buffered', { point });
  }
}

async function handleError(error) {
  emit('geolocation-error', {
    code: error?.code,
    message: error?.message || 'Falha ao obter localização'
  });

  // Erros de rede não impedem o watchPosition de continuar.
  if (navigator.onLine) {
    await flush();
  }
}

async function flush() {
  if (flushing || !window.supabaseClient || !window.currentUser) {
    return { sent: 0, remaining: (await getQueue()).length };
  }

  flushing = true;
  let sent = 0;

  try {
    await saveSupabaseConfig();
    const rows = await getQueue();

    for (const point of rows) {
      const ok = await publish(point);

      if (!ok) {
        emit('flush-stopped', {
          sent,
          remaining: rows.length - sent
        });
        return {
          sent,
          remaining: rows.length - sent
        };
      }

      await deleteQueueItem(point.id);
      sent += 1;
    }

    emit('flush-complete', { sent, remaining: 0 });
    return { sent, remaining: 0 };
  } finally {
    flushing = false;
  }
}

async function start(options = {}) {
  Object.assign(config, options);

  if (!(window.VAI_GEO||navigator.geolocation)) {
    throw new Error('Geolocalização não suportada neste navegador.');
  }

  if (active) return;

  active = true;
  initialized = true;

  registerServiceWorker();
  await saveSupabaseConfig();

  // O cliente faz a sincronização imediatamente quando volta a ter rede.
  if (navigator.onLine) await flush();

  watchId = (window.VAI_GEO||navigator.geolocation).watchPosition(
    handlePosition,
    handleError,
    {
      enableHighAccuracy: true,
      maximumAge: 3000,
      timeout: 15000
    }
  );

  if (heartbeatTimer) clearInterval(heartbeatTimer);
  heartbeatTimer = setInterval(() => {
    if (active && Date.now() - lastPublishAt > HEARTBEAT_STALE_MS) {
      queueCurrentPosition().catch(() => {});
    }
  }, HEARTBEAT_CHECK_MS);

  emit('started');
}

function stop() {
  active = false;

  if (watchId != null && (window.VAI_GEO||navigator.geolocation)) {
    (window.VAI_GEO||navigator.geolocation).clearWatch(watchId);
  }

  watchId = null;
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
  emit('stopped');
}

function isActive() {
  return active;
}

async function queueCurrentPosition() {
  if (!(window.VAI_GEO||navigator.geolocation)) return;

  return new Promise(resolve => {
    (window.VAI_GEO||navigator.geolocation).getCurrentPosition(
      position => {
        handlePosition(position).finally(resolve);
      },
      error => {
        handleError(error).finally(resolve);
      },
      {
        enableHighAccuracy: true,
        maximumAge: 0,
        timeout: 15000
      }
    );
  });
}

async function getQueueSize() {
  return (await getQueue()).length;
}

async function clearQueue() {
  const rows = await getQueue();
  for (const row of rows) await deleteQueueItem(row.id);
  emit('queue-cleared');
}

async function onOnline() {
  await saveSupabaseConfig();
  await flush();
  await registerBackgroundSync();

  if (navigator.serviceWorker?.controller) {
    navigator.serviceWorker.controller.postMessage({
      type: 'GPS_QUEUE_SYNC'
    });
  }
}

function onServiceWorkerMessage(event) {
  const data = event.data || {};

  if (data.type === 'GPS_SYNC_COMPLETE') {
    emit('sw-sync-complete', data);
  } else if (data.type === 'GPS_SYNC_RETRY') {
    emit('sw-sync-retry', data);
  } else if (data.type === 'GPS_SYNC_AUTH_REQUIRED') {
    emit('sw-sync-auth-required', data);
    // O token atualizado será enviado na próxima atividade de rede/foco.
    saveSupabaseConfig();
  }
}

async function init() {
  if (initialized) return;
  initialized = true;

  window.addEventListener('online', onOnline);
  window.addEventListener('focus', () => {
    if (active) {
      saveSupabaseConfig();
      if (navigator.onLine) flush();
    }
  });

  navigator.serviceWorker?.addEventListener(
    'message',
    onServiceWorkerMessage
  );
}

init().catch(error=>console.warn("GPS engine",error));

const gpsEngine = {
  start,
  stop,
  flush,
  queueCurrentPosition,
  getQueueSize,
  clearQueue,
  isActive
};

window.VaiComigoGPS = gpsEngine;

})();
