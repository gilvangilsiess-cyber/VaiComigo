/* Orientação local sobre uma rota calculada pelo provedor. Não substitui os
   dados de trânsito, manobras ou restrições viárias do serviço de rotas. */
(function(root){
 'use strict';
 const rad=Math.PI/180;
 function distance(a,b){const x=(b.lat-a.lat)*rad,y=(b.lng-a.lng)*rad;const h=Math.sin(x/2)**2+Math.cos(a.lat*rad)*Math.cos(b.lat*rad)*Math.sin(y/2)**2;return 12742000*Math.atan2(Math.sqrt(h),Math.sqrt(1-h))}
 function project(p,a,b){const k=111320,cos=Math.cos(p.lat*rad),dx=(b.lng-a.lng)*cos*k,dy=(b.lat-a.lat)*k,x=(p.lng-a.lng)*cos*k,y=(p.lat-a.lat)*k,t=Math.max(0,Math.min(1,(x*dx+y*dy)/(dx*dx+dy*dy||1)));return {point:{lat:a.lat+(b.lat-a.lat)*t,lng:a.lng+(b.lng-a.lng)*t},t}}
 function heading(from,to){const y=Math.sin((to.lng-from.lng)*rad)*Math.cos(to.lat*rad),x=Math.cos(from.lat*rad)*Math.sin(to.lat*rad)-Math.sin(from.lat*rad)*Math.cos(to.lat*rad)*Math.cos((to.lng-from.lng)*rad);return (Math.atan2(y,x)/rad+360)%360}
 const turnNames={left:'Vire à esquerda',right:'Vire à direita',straight:'Siga em frente','slight left':'Mantenha-se à esquerda','slight right':'Mantenha-se à direita','sharp left':'Vire acentuadamente à esquerda','sharp right':'Vire acentuadamente à direita',uturn:'Faça o retorno'};
 function instruction(step){const m=step.maneuver||{},kind=m.type||'',road=step.name?` na ${step.name}`:'';if(kind==='arrive')return 'Você chegou ao destino';if(kind==='depart')return 'Inicie o trajeto'+road;if(kind==='roundabout'||kind==='rotary')return 'Entre na rotatória'+(m.exit?' e pegue a saída '+m.exit:'');return (turnNames[m.modifier]|| (kind==='merge'?'Entre na via':'Continue'))+road}
 function create(onReroute){let coordinates=[],cumulative=[],maneuvers=[],routeDistance=0,routeDuration=0,previousProgress=0,offroute=0,lastReroute=0,routing=false;
  function setRoute(route){const coords=route?.geometry?.coordinates||[];coordinates=coords.filter(c=>Array.isArray(c)&&Number.isFinite(c[0])&&Number.isFinite(c[1])).map(c=>({lng:c[0],lat:c[1]}));cumulative=[0];for(let i=1;i<coordinates.length;i++)cumulative[i]=cumulative[i-1]+distance(coordinates[i-1],coordinates[i]);routeDistance=cumulative.at(-1)||0;routeDuration=Number(route?.duration)||0;previousProgress=0;offroute=0;maneuvers=(route?.legs?.[0]?.steps||[]).map(s=>{const c=s.maneuver?.location;if(!Array.isArray(c))return null;const hit=nearest({lng:c[0],lat:c[1]});return {at:hit.progress,text:instruction(s)}}).filter(Boolean).sort((a,b)=>a.at-b.at)}
  function nearest(point){let best={distance:Infinity,progress:0,point};for(let i=1;i<coordinates.length;i++){const match=project(point,coordinates[i-1],coordinates[i]),gap=distance(point,match.point),progress=cumulative[i-1]+(cumulative[i]-cumulative[i-1])*match.t;if(gap<best.distance)best={distance:gap,progress,point:match.point,index:i}}return best}
  function update(point){if(coordinates.length<2||!Number.isFinite(point?.lat)||!Number.isFinite(point?.lng))return null;const accuracy=Number(point.accuracy)||30;if(accuracy>100)return {state:'gps-imprecise'};const hit=nearest(point),now=Date.now(),off=hit.distance>Math.max(65,accuracy*2.2);offroute=off?offroute+1:0;
   if(offroute>=3&&!routing&&now-lastReroute>45000&&typeof onReroute==='function'){lastReroute=now;routing=true;offroute=0;Promise.resolve().then(()=>onReroute(point)).catch(()=>{}).finally(()=>{routing=false})}
   if(!off)previousProgress=Math.max(previousProgress,hit.progress-25);
   const progress=off?previousProgress:Math.max(previousProgress,hit.progress),next=maneuvers.find(x=>x.at>progress+12)||maneuvers.at(-1);
   const remaining=Math.max(0,routeDistance-progress),eta=routeDistance?Math.ceil(routeDuration*remaining/routeDistance/60):0;
   const bearing=Number.isFinite(point.heading)?point.heading:coordinates[hit.index]?heading(coordinates[hit.index-1],coordinates[hit.index]):0;
   return {state:off?'off-route':'on-route',snapped:off?point:hit.point,bearing,remainingMeters:remaining,etaMinutes:eta,next:next?.text||'Continue até o destino',maneuverMeters:next?Math.max(0,next.at-progress):remaining,gapMeters:hit.distance}
  }
  return {setRoute,update,reset(){coordinates=[];maneuvers=[];offroute=0},get ready(){return coordinates.length>1}};
 }
 root.VaiNavigation={create,distance,instruction};
})(window);
