/* Busca de lugares das duas pontas da viagem; dados de conta continuam sob RLS. */
(function(root){
 'use strict';
 const dest=document.getElementById('dest'),origin=document.getElementById('originSearch'),box=document.getElementById('placeSuggestions');
 const voice=document.getElementById('voiceSearchButton'),save=document.getElementById('savePlaceButton');
 const fold=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
 const icons={address:'📍',neighborhood:'📍',shopping:'🛍️',hotel:'🛏️',tourism:'📷',transport:'🚌',business:'📍',other:'📍'};
 let active='destination',seq=0,timer=null,controller=null,wide=false,results=[],selected=null,saved=[],recent=[],catalog=[];
 const memory=new Map(),LOCAL_KEY='vai_places_osm_v78';
 const valid=p=>p&&Number.isFinite(Number(p.lat))&&Number.isFinite(Number(p.lng))&&Math.abs(Number(p.lat))<=90&&Math.abs(Number(p.lng))<=180;
 const position=()=>root.vaiLatestGps||{lat:-22.51,lng:-43.18};
 function kilometers(p){const a=position(),lat=(a.lat+p.lat)/2*Math.PI/180;return Math.hypot((a.lat-p.lat)*111.2,(a.lng-p.lng)*111.2*Math.cos(lat))}
 function formatDistance(p){const km=kilometers(p);return km<1?Math.round(km*1000)+' m':km.toFixed(1).replace('.',',')+' km'}
 const query=()=> (active==='origin'?origin:dest).value.trim();
 function cancel(){seq++;clearTimeout(timer);controller?.abort();controller=null}
 function hide(){box.replaceChildren();box.style.display='none';results=[]}
 function create(tag,className,text){const el=document.createElement(tag);if(className)el.className=className;if(text!=null)el.textContent=text;return el}
 function resultButton(p){const button=create('button','geoResult');button.type='button';button.setAttribute('role','option');button.setAttribute('aria-label',p.name+', '+p.address+', '+formatDistance(p));
  const distance=create('span','geoDistance',formatDistance(p));const icon=create('span','geoIcon',icons[p.category]||icons.other);icon.setAttribute('aria-hidden','true');const info=create('span','geoInfo');info.append(create('strong','',p.name),create('small','',p.address));button.append(distance,icon,info);button.addEventListener('click',()=>select(p));return button}
 function action(label,callback,icon){const button=create('button','geoAction');button.type='button';button.append(create('span','geoActionIcon',icon),create('span','',label));button.addEventListener('click',callback);return button}
 function show(items,{error=false}={}){results=(items||[]).filter(valid);box.replaceChildren();const q=query();
  if(!q&&active==='destination'){
   const hour=new Date().getHours();const preferred=hour>=18||hour<7?'Casa':'Trabalho';
   const ordered=[...saved].sort((a,b)=>Number(b.label===preferred)-Number(a.label===preferred));
   if(ordered.length){box.append(create('div','geoHeading','Seus lugares'));for(const p of ordered.slice(0,30)){const row=create('div','geoSaved');const button=resultButton(p);button.title='Favorito: '+p.label;const remove=create('button','geoRemove','×');remove.type='button';remove.title='Remover favorito '+p.label;remove.setAttribute('aria-label','Remover favorito '+p.label);remove.addEventListener('click',()=>removeSaved(p));row.append(button,remove);box.append(row)}}
   if(recent.length){box.append(create('div','geoHeading','Destinos recentes'));for(const p of recent.slice(0,5))box.append(resultButton(p))}
  }else for(const p of results)box.append(resultButton(p));
  if(error&&q)box.append(create('p','geoNotice','Busca externa indisponível. Mostrando lugares disponíveis no aparelho.'));
  if(q&&!results.length&&!error)box.append(create('p','geoNotice','Procurando lugares próximos…'));
  const footer=create('div','geoFooter');
  footer.append(action('Pesquisar em uma cidade diferente',()=>{wide=true;run(true);(active==='origin'?origin:dest).focus()},'◎'));
  footer.append(action('Obtenha mais resultados para '+(q||'sua busca'),()=>{wide=true;run(true)},'⌕'));
  footer.append(action('Defina a localização no mapa',()=>{hide();active==='origin'?root.choosePickupOnMap():root.chooseDestinationOnMap()},'⌖'));
  box.append(footer);
  if(results.some(p=>String(p.source||'').match(/catalog|osm/))){const credit=create('small','geoAttribution','Dados de lugares: '),link=create('a','', '© OpenStreetMap contributors (ODbL)');link.href='https://www.openstreetmap.org/copyright';link.target='_blank';link.rel='noopener noreferrer';credit.append(link,document.createTextNode('. Trechos de vias são aproximados.'));box.append(credit)}
  box.style.display='block';
 }
 function showRecent(){active='destination';show([])}
 function local(queryText){const q=fold(queryText);if(!q)return [];
  const localPlaces=[...catalog,...(root.VaiPlaces?.rank(queryText)||[]).filter(valid).map(p=>({id:p.id,name:p.name,address:p.area+', Petrópolis - RJ',category:'tourism',lat:p.lat,lng:p.lng,source:'catalog'}))];
  const seen=new Set();return localPlaces.filter(p=>{const label=fold(p.name+' '+p.address+' '+(p.aliases||[]).join(' '));if(!label.includes(q)&&!(q.length>=3&&q.split(' ').every(t=>label.includes(t))))return false;const key=p.id||p.name+'|'+p.lat;if(seen.has(key))return false;seen.add(key);return true}).sort((a,b)=>{const sa=fold(a.name).startsWith(q)?1:0,sb=fold(b.name).startsWith(q)?1:0;return sb-sa||kilometers(a)-kilometers(b)}).slice(0,8)}
 function merge(a,b){const seen=new Set();return [...a,...b].filter(p=>{if(!valid(p))return false;const k=fold(p.name)+'|'+Math.round(p.lat*1000)+'|'+Math.round(p.lng*1000);if(seen.has(k))return false;seen.add(k);return true}).slice(0,15)}
 async function remote(term,extended=false){if(!root.supabaseClient)throw Error('backend_unavailable');const pos=position();
  const {data,error}=await root.supabaseClient.functions.invoke('place-autocomplete',{body:{query:term,lat:pos.lat,lng:pos.lng,wide:extended}});
  if(error||!Array.isArray(data?.items))throw error||Error('provider_unavailable');return data.items.filter(valid)}
 function run(immediate=false){cancel();const value=query();if(!value){show([]);return}const current=seq,near=local(value),cacheKey=fold(value)+'|'+wide;
  const cached=memory.get(cacheKey);show(cached?.items?merge(near,cached.items):near);
  if(cached&&Date.now()-cached.at<60000)return;
  timer=setTimeout(async()=>{try{const items=await remote(value,wide);if(current!==seq||query()!==value)return;memory.set(cacheKey,{items,at:Date.now()});if(memory.size>80)memory.delete(memory.keys().next().value);show(merge(near,items))}
    catch(e){if(current===seq&&query()===value)show(near,{error:true})}
  },immediate?0:110)}
 async function resolve(value){const q=fold(value);if(!q)return null;const previous=selected;if(previous&&fold(previous.name)===q)return previous;
  const current=results.filter(p=>fold(p.name)===q);if(current.length===1)return current[0];
  let found=local(value);try{found=merge(found,await remote(value,wide))}catch{};
  const exact=found.filter(p=>fold(p.name)===q);if(exact.length===1)return exact[0];
  show(found);document.getElementById('msg').textContent='Escolha o destino na lista para confirmar o endereço correto.';return null}
 async function select(place){if(!valid(place))return;const number=query().match(/\b\d{1,5}\b/)?.[0];if(number&&!new RegExp('\\b'+number+'\\b').test(place.address+' '+place.name)){
   document.getElementById('msg').textContent='O número '+number+' não foi confirmado. Escolha o endereço correto ou marque a entrada no mapa.';show(results);return;
  }cancel();selected=place;hide();if(active==='origin'){
   root.setPickupFromSearch(place);origin.value=place.name;origin.blur();return;
  }
  dest.value=place.name;dest.blur();root.goTo(Number(place.lat),Number(place.lng),place.name,place);
 }
 function destinationSelected(p){selected=p;save.hidden=false;storeRecent(p)}
 async function storeRecent(p){if(!valid(p))return;root.VaiRecents?.add({name:p.name,lat:p.lat,lng:p.lng,area:p.address});
  const user=root.currentUser;if(!user||!root.supabaseClient)return;
  const row={user_id:user.id,place_key:fold(p.name).slice(0,90)+':'+p.lat.toFixed(4)+':'+p.lng.toFixed(4),name:p.name,address:p.address||p.name,category:p.category||'address',lat:p.lat,lng:p.lng,last_used_at:new Date().toISOString()};
  await root.supabaseClient.from('recent_places').upsert(row,{onConflict:'user_id,place_key'});
  loadAccountPlaces()}
 async function loadAccountPlaces(){const user=root.currentUser;if(!user||!root.supabaseClient){saved=[];recent=(root.VaiRecents?.list()||[]).map(p=>({...p,address:p.area||'Petrópolis - RJ',category:'address'}));return}
  const [favorites,history]=await Promise.all([root.supabaseClient.from('saved_places').select('id,label,name,address,category,lat,lng').eq('user_id',user.id).order('created_at'),root.supabaseClient.from('recent_places').select('name,address,category,lat,lng,last_used_at').eq('user_id',user.id).order('last_used_at',{ascending:false}).limit(8)]);
  if(!favorites.error)saved=favorites.data||[];if(!history.error)recent=history.data||[];
 }
 async function saveCurrent(){const p=selected||root.selectedDestination;if(!valid(p))return;
  const label=prompt('Nome do favorito (Casa, Trabalho ou outro):',saved.some(x=>x.label==='Casa')?'Trabalho':'Casa');if(!label?.trim())return;
  if(!root.currentUser){root.openAuth?.('login');return}
  const item={user_id:root.currentUser.id,label:label.trim().slice(0,80),name:p.name,address:p.address||'Petrópolis - RJ',category:p.category||'address',lat:p.lat,lng:p.lng};
  const {error}=await root.supabaseClient.from('saved_places').upsert(item,{onConflict:'user_id,label'});
  if(error){document.getElementById('msg').textContent='Não foi possível salvar o lugar. Tente novamente.';return}
  await loadAccountPlaces();document.getElementById('msg').textContent='Favorito '+item.label+' salvo na sua conta.';
 }
 async function removeSaved(place){if(!root.currentUser||!place?.id)return;const {error}=await root.supabaseClient.from('saved_places').delete().eq('id',place.id).eq('user_id',root.currentUser.id);if(error)return;await loadAccountPlaces();show([])}
 async function loadCatalog(){try{const old=JSON.parse(localStorage.getItem(LOCAL_KEY)||'null');if(Array.isArray(old?.items))catalog=old.items.filter(valid)}catch{}
  if(!root.supabaseClient)return;
  const all=[];
  for(let offset=0;offset<5000;offset+=400){const response=await root.supabaseClient.rpc('list_ride_pois_page',{p_offset:offset,p_limit:400});
   if(response.error)break;all.push(...(response.data||[]));if(offset===0&&all.length){catalog=all.map(p=>({...p,source:'catalog'}));if(query())run(true)}
   if((response.data||[]).length<400)break;
  }
  if(all.length){catalog=all.map(p=>({...p,source:'catalog'}));try{localStorage.setItem(LOCAL_KEY,JSON.stringify({at:Date.now(),items:catalog}))}catch{}if(query())run(true)}
 }
 function voiceSearch(){const SR=root.SpeechRecognition||root.webkitSpeechRecognition;if(!SR)return;const recognition=new SR();recognition.lang='pt-BR';recognition.interimResults=false;recognition.onresult=e=>{const input=active==='origin'?origin:dest;input.value=e.results[0][0].transcript;run(true);input.focus()};recognition.onerror=()=>{document.getElementById('msg').textContent='Não foi possível entender a fala. Digite o lugar ou marque no mapa.'};recognition.start()}
 for(const [input,side] of [[dest,'destination'],[origin,'origin']]){input.addEventListener('focus',()=>{active=side;wide=false;run(true)});input.addEventListener('input',()=>{active=side;wide=false;selected=null;if(side==='destination'){root.selectedDestination=null;root.resetQuoteForPickup();save.hidden=true}run()});input.addEventListener('keydown',e=>{if(e.key==='Escape')hide();if(e.key==='ArrowDown'){e.preventDefault();box.querySelector('.geoResult')?.focus()}})}
 const SR=root.SpeechRecognition||root.webkitSpeechRecognition;if(SR){voice.hidden=false;voice.addEventListener('click',voiceSearch)}
 save.addEventListener('click',saveCurrent);
 root.supabaseClient?.auth?.onAuthStateChange(()=>setTimeout(loadAccountPlaces,150));
 loadAccountPlaces();loadCatalog();
 root.VaiPlaceUI=Object.freeze({cancel,hide,show,showRecent,resolve,destinationSelected,loadAccountPlaces});
})(window);
