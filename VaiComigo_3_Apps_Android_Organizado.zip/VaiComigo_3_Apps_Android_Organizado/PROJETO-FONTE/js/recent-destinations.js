/* Destinos recentes deste navegador. Dados locais, limitados e descartáveis. */
(function(root){
 'use strict';
 const KEY='vai_recent_destinations_v1';
 const valid=p=>p&&typeof p.name==='string'&&p.name.trim().length>1&&p.name.length<=120&&
  Number.isFinite(p.lat)&&Number.isFinite(p.lng)&&p.lat>=-22.70&&p.lat<=-22.25&&p.lng>=-43.65&&p.lng<=-42.93;
 function list(){
  try{const data=JSON.parse(root.localStorage.getItem(KEY)||'[]');return Array.isArray(data)?data.filter(valid).slice(0,5):[]}
  catch{return []}
 }
 function add(place){
  if(!valid(place))return list();
  const p={name:place.name.trim(),lat:place.lat,lng:place.lng,area:String(place.area||'Petrópolis').slice(0,80),kind:'Recente',source:'recent'};
  const items=[p,...list().filter(x=>x.name.toLowerCase()!==p.name.toLowerCase()||Math.hypot(x.lat-p.lat,x.lng-p.lng)>0.001)].slice(0,5);
  try{root.localStorage.setItem(KEY,JSON.stringify(items))}catch{}
  return items;
 }
 function clear(){try{root.localStorage.removeItem(KEY)}catch{}}
 root.VaiRecents=Object.freeze({list,add,clear});
})(typeof window==='undefined'?globalThis:window);
