/* Estados da corrida, conectados aos eventos que o Supabase já valida no servidor. */
(function(root){
 'use strict';
 const edges=Object.freeze({requested:['accepted','cancelled'],accepted:['arriving','cancelled'],arriving:['in_progress','cancelled'],in_progress:['completed','cancelled'],completed:[],cancelled:[]});
 const steps=['requested','accepted','arriving','in_progress'];
 const labels=['Solicitada','Aceita','A caminho','Em viagem'];
 let current=null;
 function canTransition(from,to){return Boolean(edges[from]?.includes(to))}
 function progress(status){return ({requested:'12%',accepted:'36%',arriving:'67%',in_progress:'100%'})[status]||'0%'}
 function observe(ride){
  if(!ride||!ride.id||!edges[ride.status]){current=null;return null}
  const changed=current?.id!==ride.id||current.status!==ride.status;
  // Um evento perdido ou uma sessão restaurada recebe o estado persistido do servidor.
  current={id:ride.id,status:ride.status};
  return {status:ride.status,changed,step:steps.indexOf(ride.status),progress:progress(ride.status)}
 }
 function decorate(ride){
  const box=document.getElementById('activeRidePanel');if(!box)return;
  const state=observe(ride);if(!state){box.removeAttribute('data-ride-state');return}
  box.dataset.rideState=state.status;box.style.setProperty('--ride-progress',state.progress);
  box.setAttribute('aria-live','polite');box.setAttribute('aria-label','Estado da corrida: '+(labels[state.step]||state.status));
  const grid=box.querySelector('.liveGrid');if(!grid)return;
  const track=document.createElement('div');track.className='rideSteps';track.setAttribute('aria-label','Etapas da corrida');
  steps.forEach((step,index)=>{const item=document.createElement('span');item.textContent=labels[index];if(index===state.step)item.className='isCurrent';else if(index<state.step)item.className='isPast';track.append(item)});
  grid.before(track);
  if(state.changed){box.classList.remove('rideStateTransition');void box.offsetWidth;box.classList.add('rideStateTransition')}
 }
 function decorateDriver(ride){const box=document.getElementById('driverCall');if(!box||!ride?.id||!edges[ride.status])return;box.dataset.rideState=ride.status;box.setAttribute('aria-live','polite');box.classList.remove('rideStateTransition');void box.offsetWidth;box.classList.add('rideStateTransition')}
 root.VaiRideMachine=Object.freeze({canTransition,observe,decorate,decorateDriver,states:edges});
 const passengerRenderer=root.renderActiveRidePanel;
 if(typeof passengerRenderer==='function')root.renderActiveRidePanel=function(ride){passengerRenderer(ride);decorate(ride)};
 const driverRenderer=root.renderDriverRideState;
 if(typeof driverRenderer==='function')root.renderDriverRideState=function(ride){driverRenderer(ride);decorateDriver(ride)};
 // A RPC continua a decidir se a transição é permitida. Dados locais podem estar
 // atrasados após perda de conexão e não devem bloquear o botão do motorista.
})(window);
