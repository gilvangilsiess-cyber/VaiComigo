/* Tema automático e gesto da folha sobre o mapa. Sem dependências externas. */
(function(root){
 'use strict';
 const doc=document.documentElement,button=document.getElementById('themeToggle'),sheet=document.querySelector('#home .searchPanel'),handle=document.getElementById('sheetHandle');
 const key='vai_theme_preference';const system=root.matchMedia?.('(prefers-color-scheme: dark)');
 function preference(){try{return localStorage.getItem(key)||'auto'}catch{return 'auto'}}
 function apply(){const mode=preference(),dark=mode==='dark'||mode==='auto'&&Boolean(system?.matches);doc.dataset.theme=dark?'dark':'light';if(button){button.setAttribute('aria-pressed',String(dark));button.title=mode==='auto'?'Tema acompanha o aparelho':'Tema '+(dark?'escuro':'claro')+' · toque para alternar'};document.querySelector('meta[name="theme-color"]')?.setAttribute('content',dark?'#171819':'#202021')}
 apply();system?.addEventListener?.('change',apply);
 button?.addEventListener('click',()=>{try{localStorage.setItem(key,doc.dataset.theme==='dark'?'light':'dark')}catch{}apply()});
 function setExpanded(value){if(!sheet||!handle)return;sheet.dataset.sheet=value?'expanded':'compact';handle.setAttribute('aria-expanded',String(value));handle.setAttribute('aria-label',value?'Recolher mapa e busca':'Expandir mapa e busca');root.vaiMapEngine?.resize?.();root.map?.invalidateSize?.();root.dispatchEvent(new Event('resize'))}
 setExpanded(false);handle?.addEventListener('click',()=>setExpanded(sheet.dataset.sheet!=='expanded'));
 let y=null;handle?.addEventListener('pointerdown',e=>{y=e.clientY;handle.setPointerCapture(e.pointerId)});
 handle?.addEventListener('pointerup',e=>{if(y===null)return;const delta=e.clientY-y;y=null;if(Math.abs(delta)>32)setExpanded(delta<0)});
 handle?.addEventListener('pointercancel',()=>{y=null});
 function closeModal(modal){const close=modal?.querySelector('.sheet .head button[onclick]');if(close)close.click();else modal?.classList.remove('on')}
 document.querySelectorAll('.modal .sheet').forEach(modalSheet=>{
  let start=null;
  modalSheet.addEventListener('pointerdown',event=>{if(event.clientY-modalSheet.getBoundingClientRect().top<34&&!event.target.closest('button,input,select,textarea'))start=event.clientY});
  modalSheet.addEventListener('pointerup',event=>{if(start===null)return;const dy=event.clientY-start;start=null;if(dy>85)closeModal(modalSheet.closest('.modal'))});
  modalSheet.addEventListener('pointercancel',()=>{start=null});
 });
 document.addEventListener('keydown',event=>{if(event.key==='Escape'){const top=[...document.querySelectorAll('.modal.on')].at(-1);if(top){closeModal(top);event.preventDefault()}}});
 const route=document.getElementById('routeQuote'),quote=document.getElementById('quoteMain'),status=document.getElementById('quoteStatus');
 if(route&&quote&&status){const refresh=()=>{const visible=getComputedStyle(route).display!=='none';const pending=visible&&/calcul|aguard|carreg|consult/i.test(status.textContent||'');quote.classList.toggle('routeSkeleton',pending);route.setAttribute('aria-busy',String(pending))};new MutationObserver(refresh).observe(route,{attributes:true,attributeFilter:['style'],childList:true,subtree:true,characterData:true});refresh()}
 root.VaiStage3=Object.freeze({setExpanded,applyTheme:apply});
})(window);
