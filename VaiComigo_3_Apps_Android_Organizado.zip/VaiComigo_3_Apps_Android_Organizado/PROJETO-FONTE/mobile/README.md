# VaiComigo — três projetos Android

Esta pasta contém três **projetos Android separados** gerados a partir do código de `../`:

| Projeto | Nome no aparelho | Application ID | Entrada |
| --- | --- | --- | --- |
| `passageiros/` | VaiComigo Passageiros | `com.vaicomigo.passageiros` | Passageiro |
| `motorista/` | VaiComigo Motorista | `com.vaicomigo.motorista` | Motorista |
| `administracao/` | VaiComigo Administração | `com.vaicomigo.administracao` | Diretor |

Os arquivos web são **embutidos no APK**, inclusive o cliente Supabase. Nenhum app carrega sua interface de um site. Todos compartilham o projeto Supabase já configurado em `../js/config.js`; o banco continua impondo a autorização de cada perfil. A entrada de cada app é fixa e o app do diretor não aparece na instalação dos passageiros.

## Atualizar o código e gerar um APK de teste

Instale Node.js 22 ou superior, Android Studio e o Android SDK. Na pasta `mobile/`:

```sh
npm ci
npm run sync:android
```

Abra **cada** pasta `passageiros/android`, `motorista/android`, `administracao/android` no Android Studio e gere um APK de teste pelo menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Para publicar na loja, ainda são necessários assinatura de produção, testes físicos e revisão das permissões. A regeneração dos assets sempre começa em `../` e preserva os projetos Android personalizados.

## Configuração indispensável antes de testar no aparelho

1. No Supabase (`uuywjwmarjrmcjtvezbg`), em **Authentication > URL Configuration > Redirect URLs**, inclua exatamente `com.vaicomigo.passageiros://auth`, `com.vaicomigo.motorista://auth` e `com.vaicomigo.administracao://auth`. Mantenha outros URLs que ainda sejam usados. Sem esses redirecionamentos, o e-mail poderá abrir o endereço antigo. O app faz a troca do código de confirmação pela sessão recebida.
2. Para os alertas Android do motorista, crie um projeto Firebase, registre nele o aplicativo Android `com.vaicomigo.motorista` e coloque o `google-services.json` verdadeiro em `mobile/motorista/android/app/google-services.json`. Configure no Supabase Edge Function `push-notify` o Secret `FCM_SERVICE_ACCOUNT_JSON` com o JSON da conta de serviço autorizada a enviar mensagens Firebase HTTP v1 para esse mesmo projeto. **Nunca inclua a conta de serviço no ZIP ou no aplicativo.** Confira a configuração do plugin Push Notifications do Capacitor para Gradle e FCM antes de compilar.
3. Reinstale os apps depois de uma troca de esquema de confirmação ou configuração do Firebase. Teste confirmação por e-mail, permissão de notificações, GPS com tela bloqueada e toque no alerta em aparelhos físicos.

## Limites desta versão

- **Não há APK compilado neste pacote.** Este ambiente não tem Android SDK nem os arquivos Firebase do seu projeto. `cap sync android` e os testes JavaScript passaram; isso não comprova a compilação ou o comportamento físico.
- O serviço nativo de GPS está integrado ao motorista e publica pontos diretamente no Supabase enquanto a conta estiver aprovada e online. O token específico do GPS expira em 24 horas; abra o aplicativo para reiniciar a disponibilidade em um novo turno. Bloqueio de permissões, economia de bateria, falta de sinal e encerramento forçado pelo sistema podem interromper a publicação. Confira em aparelho com tela bloqueada; a localização precisa estar atualizada para o motorista receber ofertas.
- A função de alertas Android foi implantada, mas os alertas nativos **não funcionarão** sem `google-services.json` no app e `FCM_SERVICE_ACCOUNT_JSON` no servidor. O alerta exibe apenas que há uma corrida; abra o app e busque os detalhes com sua conta autorizada.
- Os três redirecionamentos precisam ser inseridos no painel do Supabase; a conexão disponível aqui não oferece edição das configurações do Auth. Sem essa etapa, o link de confirmação pode continuar abrindo `localhost:3000`.
- Revisar em dois aparelhos e contas reais login, envio dos quatro arquivos de identidade, CNH/CRLV, aprovação, câmera/seleção de arquivos, GPS bloqueado/aberto, chamada e aceite, trajeto, pagamento e notificações.
- Os IDs de pacote devem ser confirmados antes de qualquer publicação, pois não podem ser trocados livremente depois da primeira instalação pela loja.

O código do site anterior continua na raiz como fonte compartilhada e para executar os testes; o aplicativo instalado abre exclusivamente os arquivos embarcados.
