/* Ponte pequena para o plugin de GPS nativo; mantém a API de posição do app. */
(function(){
  if(!window.VAI_NATIVE_APP)return;
  // O token de confirmação via e-mail chega por deep link no mesmo app.
  let handledUrl='';
  async function handleAuthUrl(value){
    if(!value||value===handledUrl||!value.startsWith(window.VAI_AUTH_REDIRECT))return;
    handledUrl=value;
    const code=new URL(value).searchParams.get('code');
    if(!code)return;
    const client=window.supabaseClient;
    if(!client)return;
    const {error}=await client.auth.exchangeCodeForSession(code);
    if(error){document.getElementById('connectionStatus').textContent='Não foi possível concluir a confirmação: '+error.message;return;}
    window.location.reload();
  }
  window.addEventListener('load',()=>{
    const app=window.Capacitor?.Plugins?.App;
    app?.addListener('appUrlOpen',event=>handleAuthUrl(event.url).catch(console.warn));
    app?.getLaunchUrl().then(event=>handleAuthUrl(event?.url)).catch(()=>{});
  });
  // Tokens FCM nunca são enviados para outro usuário. Registro só após autenticação.
  const push=()=>window.Capacitor?.Plugins?.PushNotifications;
  let pushReady=false,registerResolve=null,registerReject=null;
  async function setupPush(){
    if(pushReady)return;
    const native=push();if(!native)throw Error('Alertas Android indisponíveis.');
    await native.addListener('registration',async info=>{
      try{
        const token=info.value;
        const {error}=await window.supabaseClient.rpc('register_my_native_push',{p_token:token});
        if(error)throw error;
        localStorage.setItem('vai_native_push_token',token);
        registerResolve?.(token);
      }catch(e){registerReject?.(e)}finally{registerResolve=null;registerReject=null}
    });
    await native.addListener('registrationError',e=>{registerReject?.(e);registerResolve=null;registerReject=null});
    await native.addListener('pushNotificationActionPerformed',()=>{
      if(window.VAI_FIXED_ROLE==='driver')setTimeout(()=>window.loadDriverRequests?.(),800);
    });
    pushReady=true;
  }
  window.VaiNativePush={
    async register(){
      if(!window.currentUser)throw Error('Entre na conta para ativar alertas.');
      await setupPush();const native=push();
      let permission=await native.checkPermissions();
      if(permission.receive==='prompt')permission=await native.requestPermissions();
      if(permission.receive!=='granted')throw Error('Permita notificações nas configurações do aparelho.');
      return new Promise((resolve,reject)=>{
        const timer=setTimeout(()=>{
          registerResolve=null;registerReject=null;
          reject(Error('Não foi possível registrar alertas. Confira a configuração Firebase do aplicativo.'));
        },15000);
        registerResolve=value=>{clearTimeout(timer);resolve(value)};
        registerReject=error=>{clearTimeout(timer);reject(error)};
        native.register().catch(registerReject);
      });
    },
    async unregister(){
      const token=localStorage.getItem('vai_native_push_token');
      if(token&&window.supabaseClient&&window.currentUser){
        const {error}=await window.supabaseClient.from('native_push_tokens').delete().eq('token',token).eq('user_id',window.currentUser.id);
        if(error)throw error;
      }
      localStorage.removeItem('vai_native_push_token');
    }
  };
  const locationPlugin=()=>window.Capacitor?.Plugins?.BackgroundGeolocation;
  window.VaiNativeLocation={
    async start(){
      if(!window.currentUser)throw Error('Entre na conta para ativar o GPS.');
      const native=locationPlugin();if(!native)throw Error('Atualize o aplicativo para ativar o GPS em segundo plano.');
      const bytes=crypto.getRandomValues(new Uint8Array(32));
      const token=[...bytes].map(byte=>byte.toString(16).padStart(2,'0')).join('');
      const {error}=await window.supabaseClient.rpc('set_my_native_location_key',{p_token:token});
      if(error)throw error;
      try{
        await native.start({
          backgroundTitle:'VaiComigo Motorista online',
          backgroundMessage:'Compartilhando localização para receber corridas. Abra o app para ficar offline.',
          requestPermissions:true,stale:false,distanceFilter:0,minIntervalMs:40000,
          url:window.VAI_CONFIG.supabaseUrl+'/functions/v1/native-driver-location',
          headers:{'x-vai-location-token':token}
        },(point,error)=>{
          if(error){const note=document.getElementById('driverLocationSync');if(note)note.textContent='GPS Android: '+(error.message||'confira as permissões de localização.');}
        });
      }catch(e){await window.supabaseClient.rpc('clear_my_native_location_key');throw e;}
    },
    async stop(){
      try{await locationPlugin()?.stop()}finally{
        if(window.currentUser&&window.supabaseClient){
          const {error}=await window.supabaseClient.rpc('clear_my_native_location_key');
          if(error)console.warn('GPS nativo: credencial será recusada quando offline',error);
        }
      }
    }
  };
  let nextId=1;
  const watches=new Map();
  const plugin=()=>window.Capacitor?.Plugins?.Geolocation;
  const failure=(callback,error)=>callback?.({code:Number(error?.code)||2,message:error?.message||'GPS indisponível'});
  window.VAI_GEO={
    getCurrentPosition(success,error,options){
      const native=plugin();
      if(!native){failure(error,{message:'GPS nativo indisponível. Atualize o aplicativo.'});return;}
      native.getCurrentPosition(options||{}).then(success,e=>failure(error,e));
    },
    watchPosition(success,error,options){
      const id=nextId++;
      const native=plugin();
      if(!native){failure(error,{message:'GPS nativo indisponível. Atualize o aplicativo.'});return id;}
      const watch={native,id:null,closed:false};watches.set(id,watch);
      native.watchPosition(options||{},(err,position)=>{
        if(watch.closed)return;
        if(err)failure(error,err);else if(position)success(position);
      }).then(nativeId=>{
        watch.id=nativeId;
        if(watch.closed)native.clearWatch({id:nativeId}).catch(()=>{});
      },e=>failure(error,e));
      return id;
    },
    clearWatch(id){
      const watch=watches.get(id);if(!watch)return;
      watch.closed=true;watches.delete(id);
      if(watch.id!=null)watch.native.clearWatch({id:watch.id}).catch(()=>{});
    }
  };
})();
