/* VaiComigo v40 — Service Worker
 * Offline shell + IndexedDB GPS queue + Background Sync + Web Push.
 *
 * Importante:
 * - O SW não usa o SDK do Supabase.
 * - A fila usa a mesma estrutura do gps-engine.js.
 * - O endpoint RPC é o contrato existente de v24:
 *   public.update_driver_location(lat,lng,accuracy,heading,speed)
 * - "created_at" permanece armazenado localmente para ordenação, mas a RPC
 *   existente não recebe esse campo; o banco usa now() no momento da ingestão.
 */

const VERSION = 'vai-comigo-v103-visible-exit';
const CACHE_NAME = VERSION;
const GPS_DB = 'vai-comigo-gps-v1';
const GPS_STORE = 'queue';
const META_STORE = 'meta';
const GPS_SYNC_TAG = 'sync-gps';

const ASSETS = [
  './',
  './index.html',
  './app.js',
  './css/vai-design.css',
  './css/vai-map.css',
  './css/vai-search.css',
  './vendor/leaflet/leaflet.css',
  './vendor/leaflet/leaflet.js',
  './vendor/leaflet/images/layers-2x.png',
  './vendor/leaflet/images/layers.png',
  './vendor/leaflet/images/marker-icon-2x.png',
  './vendor/leaflet/images/marker-icon.png',
  './vendor/leaflet/images/marker-shadow.png',
  './vendor/maplibre/maplibre-gl.css',
  './vendor/maplibre/maplibre-gl.js',
  './sw.js',
  './manifest.webmanifest',
  './icon.svg',
  './brand/simbolo-escuro.svg',
  './js/config.js',
  './js/local-places.js',
  './js/recent-destinations.js',
  './js/city-search.js',
  './js/map-engine.js',
  './js/navigation-engine.js',
  './js/place-search.js',
  './js/ride-state.js',
  './js/stage3-ui.js',
  './js/modules/gps-engine.js',
  './js/modules/driver.js',
  './js/identity-review.js'
];

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(GPS_DB, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(GPS_STORE)) {
        const store = db.createObjectStore(GPS_STORE, {
          keyPath: 'id',
          autoIncrement: true
        });
        store.createIndex('created_at', 'created_at', { unique: false });
      }
      if (!db.objectStoreNames.contains(META_STORE)) {
        db.createObjectStore(META_STORE, { keyPath: 'key' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function dbGetAllGps() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(GPS_STORE, 'readonly');
    const req = tx.objectStore(GPS_STORE).getAll();
    req.onsuccess = () => {
      const rows = (req.result || []).sort((a, b) =>
        String(a.created_at).localeCompare(String(b.created_at))
      );
      resolve(rows);
    };
    req.onerror = () => reject(req.error);
  });
}

async function dbDeleteGps(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(GPS_STORE, 'readwrite');
    tx.objectStore(GPS_STORE).delete(id);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

async function dbGetMeta(key) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(META_STORE, 'readonly');
    const req = tx.objectStore(META_STORE).get(key);
    req.onsuccess = () => resolve(req.result?.value ?? null);
    req.onerror = () => reject(req.error);
  });
}

async function dbPutMeta(key, value) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(META_STORE, 'readwrite');
    tx.objectStore(META_STORE).put({ key, value });
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

async function requestBackgroundSync() {
  try {
    if (self.registration.sync) {
      await self.registration.sync.register(GPS_SYNC_TAG);
      return true;
    }
  } catch (_) {}
  return false;
}

async function notifyClients(type, payload = {}) {
  const list = await self.clients.matchAll({
    type: 'window',
    includeUncontrolled: true
  });
  for (const client of list) {
    try {
      client.postMessage({ type, ...payload });
    } catch (_) {}
  }
}

/*
 * O SW tenta sincronizar diretamente quando possui:
 * - supabaseUrl
 * - anonKey
 * - accessToken
 *
 * Se o token expirou, o cliente recebe GPS_SYNC_AUTH_REQUIRED e atualiza
 * a sessão/token antes de chamar flush novamente.
 */
async function syncGpsDirect() {
  const rows = await dbGetAllGps();
  if (!rows.length) {
    await notifyClients('GPS_SYNC_COMPLETE', { remaining: 0 });
    return { ok: true, remaining: 0 };
  }

  const cfg = await dbGetMeta('supabase');
  if (!cfg?.url || !cfg?.anonKey || !cfg?.accessToken) {
    await notifyClients('GPS_SYNC_AUTH_REQUIRED', { remaining: rows.length });
    return { ok: false, reason: 'missing-auth', remaining: rows.length };
  }

  const endpoint =
    String(cfg.url).replace(/\/+$/, '') +
    '/rest/v1/rpc/update_driver_location';

  for (const row of rows) {
    const body = {
      p_lat: Number(row.latitude),
      p_lng: Number(row.longitude),
      p_accuracy: row.accuracy == null ? null : Number(row.accuracy),
      p_heading: row.heading == null ? null : Number(row.heading),
      p_speed: row.speed == null ? null : Number(row.speed)
    };

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          apikey: cfg.anonKey,
          Authorization: `Bearer ${cfg.accessToken}`,
          'Content-Type': 'application/json',
          Accept: 'application/json'
        },
        body: JSON.stringify(body),
        cache: 'no-store'
      });

      if (res.status === 401 || res.status === 403) {
        await notifyClients('GPS_SYNC_AUTH_REQUIRED', {
          remaining: rows.length
        });
        return { ok: false, reason: 'auth', remaining: rows.length };
      }

      if (!res.ok) {
        // Não pula este ponto: mantém ordem cronológica.
        await notifyClients('GPS_SYNC_RETRY', {
          remaining: rows.length
        });
        return { ok: false, reason: `http-${res.status}`, remaining: rows.length };
      }

      await dbDeleteGps(row.id);
    } catch (_) {
      await notifyClients('GPS_SYNC_RETRY', { remaining: rows.length });
      return { ok: false, reason: 'network', remaining: rows.length };
    }
  }

  await notifyClients('GPS_SYNC_COMPLETE', { remaining: 0 });
  return { ok: true, remaining: 0 };
}

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    Promise.all([
      caches.keys().then(keys =>
        Promise.all(
          keys
            .filter(key => key !== CACHE_NAME)
            .map(key => caches.delete(key))
        )
      ),
      self.clients.claim()
    ])
  );
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // Apenas arquivos da própria aplicação são armazenados; consultas externas nunca recebem HTML offline.
  if (url.origin !== self.location.origin) return;
  // Nunca cachear Supabase/REST ou outros dados autenticados.
  if (
    url.pathname.includes('/rest/v1/') ||
    url.pathname.includes('/auth/v1/') ||
    url.hostname.includes('supabase')
  ) {
    return;
  }

  event.respondWith(
    fetch(request)
      .then(response => {
        if (response.ok && url.origin === self.location.origin) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
        }
        return response;
      })
      .catch(() => caches.match(request).then(cached => cached || (request.mode === 'navigate' ? caches.match('./index.html') : Response.error())))
  );
});

self.addEventListener('sync', event => {
  if (event.tag === GPS_SYNC_TAG) {
    event.waitUntil(syncGpsDirect());
  }
});

self.addEventListener('message', event => {
  const data = event.data || {};

  if (data.type === 'GPS_QUEUE_SYNC') {
    event.waitUntil(syncGpsDirect());
    return;
  }

  if (data.type === 'GPS_AUTH_UPDATE') {
    event.waitUntil(
      dbPutMeta('supabase', {
        url: data.url || null,
        anonKey: data.anonKey || null,
        accessToken: data.accessToken || null
      }).then(() => syncGpsDirect())
    );
    return;
  }

  if (data.type === 'GPS_CLEAR_AUTH') {
    event.waitUntil(
      dbPutMeta('supabase', {
        url: null,
        anonKey: null,
        accessToken: null
      })
    );
  }
});

self.addEventListener('push', event => {
  let payload = {};
  try {
    payload = event.data ? event.data.json() : {};
  } catch (_) {
    try {
      payload = { body: event.data?.text() || '' };
    } catch (_) {}
  }

  const title = payload.title || 'VaiComigo';
  const body = payload.body || 'Você recebeu uma nova atualização.';
  const data = payload.data || {};
  const rideId = data.ride_id || data.rideId || null;

  const actions = [];
  if (rideId && (data.type === 'ride' || data.type === 'ride_request')) {
    actions.push(
      { action: 'accept-ride', title: 'Aceitar corrida' },
      { action: 'reject-ride', title: 'Recusar' }
    );
  }

  const options = {
    body,
    icon: payload.icon || './icon.svg',
    badge: payload.badge || './icon.svg',
    tag: payload.tag || (rideId ? `ride-${rideId}` : 'vai-comigo'),
    renotify: true,
    requireInteraction: true,
    data: {
      ...data,
      ride_id: rideId,
      url: payload.url || './'
    },
    actions
  };

  // Evidência para o Diagnóstico E2E: registra que este aparelho recebeu um push.
  const evidence = dbPutMeta('last_push', {
    at: Date.now(),
    ride_id: rideId,
    type: data.type || null,
    title
  }).then(() => notifyClients('PUSH_RECEIVED', { ride_id: rideId, at: Date.now() }))
    .catch(() => {});

  event.waitUntil(Promise.all([
    self.registration.showNotification(title, options),
    evidence
  ]));
});

self.addEventListener('notificationclick', event => {
  const action = event.action;
  const data = event.notification.data || {};
  const rideId = data.ride_id || data.rideId || null;

  event.notification.close();

  event.waitUntil((async () => {
    const windows = await self.clients.matchAll({
      type: 'window',
      includeUncontrolled: true
    });

    if (action === 'accept-ride' && rideId) {
      for (const client of windows) {
        try {
          client.postMessage({
            type: 'RIDE_NOTIFICATION_ACTION',
            action: 'accept',
            rideId
          });
          if ('focus' in client) await client.focus();
          return;
        } catch (_) {}
      }

      const target = new URL('./', self.location.origin);
      target.searchParams.set('action', 'accept-ride');
      target.searchParams.set('ride_id', rideId);
      await self.clients.openWindow(target.href);
      return;
    }

    if (action === 'reject-ride' && rideId) {
      for (const client of windows) {
        try {
          client.postMessage({
            type: 'RIDE_NOTIFICATION_ACTION',
            action: 'reject',
            rideId
          });
          if ('focus' in client) await client.focus();
          return;
        } catch (_) {}
      }

      const target = new URL('./', self.location.origin);
      target.searchParams.set('action', 'reject-ride');
      target.searchParams.set('ride_id', rideId);
      await self.clients.openWindow(target.href);
      return;
    }

    const target = new URL(data.url || './', self.location.origin);
    for (const client of windows) {
      try {
        if (new URL(client.url).origin === target.origin) {
          if ('focus' in client) await client.focus();
          client.postMessage({ type: 'PUSH_OPEN', data });
          return;
        }
      } catch (_) {}
    }
    await self.clients.openWindow(target.href);
  })());
});

self.addEventListener('notificationclose', event => {
  // Reservado para telemetria futura; não há chamada externa aqui.
});
