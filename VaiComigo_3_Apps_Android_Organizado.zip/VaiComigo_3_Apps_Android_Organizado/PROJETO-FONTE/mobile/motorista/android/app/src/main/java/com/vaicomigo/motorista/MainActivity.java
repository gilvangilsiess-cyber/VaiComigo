package com.vaicomigo.motorista;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
