package com.vaicomigo.passageiros;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
