import { cp, mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { build } from 'esbuild';
const here=path.dirname(fileURLToPath(import.meta.url));
const source=path.dirname(here);
const apps={
  passageiros:{role:'passenger',name:'VaiComigo Passageiros',id:'com.vaicomigo.passageiros'},
  motorista:{role:'driver',name:'VaiComigo Motorista',id:'com.vaicomigo.motorista'},
  administracao:{role:'admin',name:'VaiComigo Administração',id:'com.vaicomigo.administracao'}
};
const assets=['index.html','app.js','sw.js','manifest.webmanifest','icon.svg','js','css','brand','vendor'];
for(const [slug,app] of Object.entries(apps)){
 const target=path.join(here,slug,'www');
 await rm(target,{recursive:true,force:true});await mkdir(target,{recursive:true});
 for(const asset of assets)await cp(path.join(source,asset),path.join(target,asset),{recursive:true});
 await build({entryPoints:[path.join(here,'supabase-global.js')],bundle:true,platform:'browser',format:'iife',outfile:path.join(target,'js','supabase.bundle.js')});
 let html=await readFile(path.join(target,'index.html'),'utf8');
 const gate=/<div id="entryGate"[\s\S]*?<div class="app">/;
 if(!gate.test(html))throw Error('Tela de seleção não encontrada');
 html=html.replace(gate,'<div class="app">');
 html=html.replace('<body>','<body data-entry-role="'+app.role+'">');
 html=html.replace('<title>VaiComigo</title>','<title>'+app.name+'</title>');
 html=html.replace('<script src="js/config.js"></script>',
  '<script>window.VAI_FIXED_ROLE='+JSON.stringify(app.role)+';window.VAI_NATIVE_APP=true;window.VAI_AUTH_REDIRECT='+JSON.stringify(app.id+'://auth')+';</script>\n<script src="mobile/native-bridge.js"></script>\n<script src="js/config.js"></script>');
 html=html.replace('<link rel="manifest" href="manifest.webmanifest">','');
 html=html.replace('<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>','<script src="js/supabase.bundle.js"></script>');
 await writeFile(path.join(target,'index.html'),html);
 await mkdir(path.join(target,'mobile'),{recursive:true});
 await cp(path.join(here,'native-bridge.js'),path.join(target,'mobile','native-bridge.js'));
 await writeFile(path.join(here,slug,'capacitor.config.json'),JSON.stringify({appId:app.id,appName:app.name,webDir:'www',...(slug==='motorista'?{android:{useLegacyBridge:true}}:{})},null,2)+'\n');
}
console.log('Pacotes separados: '+Object.keys(apps).join(', '));
