import { spawnSync } from 'node:child_process';
import { existsSync, symlinkSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const bin=path.join(here,'node_modules','.bin','cap');
for(const slug of ['passageiros','motorista','administracao']){
 const cwd=path.join(here,slug);
 if(!existsSync(path.join(cwd,'node_modules')))symlinkSync('../node_modules',path.join(cwd,'node_modules'));
 const command=spawnSync(bin,[...(process.env.VAI_ADD_ANDROID==='1'?['add']:['sync']),'android'],{cwd,stdio:'inherit'});
 if(command.status!==0)process.exit(command.status||1);
}
