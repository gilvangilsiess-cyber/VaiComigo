// Gera js/config.js a partir de variáveis de ambiente do build (Netlify).
// - Sem nenhuma variável: mantém o js/config.js existente (deploy manual).
// - Recusa chaves secretas (service_role / sb_secret_*): elas jamais podem ir para o frontend.
import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const url = (process.env.SUPABASE_URL || '').trim();
const key = (process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_PUBLISHABLE_KEY || '').trim();
// Preserva a chave pública instalada quando o build define Supabase mas omite VAPID.
const currentConfig = readFileSync(join(root, 'js', 'config.js'), 'utf8');
const currentVapid = currentConfig.match(/vapidPublicKey["']?\s*:\s*["']([A-Za-z0-9_-]+)["']/);
const vapid = (process.env.VAPID_PUBLIC_KEY || currentVapid?.[1] || '').trim();
const environment = (process.env.VAI_ENVIRONMENT || 'production').trim() === 'test' ? 'test' : 'production';

function fail(msg) { console.error('[generate-config] ERRO: ' + msg); process.exit(1); }

if (!url && !key) {
  console.log('[generate-config] SUPABASE_URL/SUPABASE_ANON_KEY não definidos: js/config.js mantido como está.');
  process.exit(0);
}
if (!url || !key) fail('defina SUPABASE_URL e SUPABASE_ANON_KEY juntos.');
if (!/^https:\/\/[^\s/]+$/.test(url)) fail('SUPABASE_URL deve ser https://<projeto>.supabase.co (sem barra final).');
if (/^sb_secret_/.test(key)) fail('SUPABASE_ANON_KEY contém uma chave SECRETA (sb_secret_*). Use a chave anon/publishable.');
if (key.split('.').length === 3) {
  try {
    const payload = JSON.parse(Buffer.from(key.split('.')[1], 'base64url').toString('utf8'));
    if (payload.role && payload.role !== 'anon') fail(`a chave informada tem role="${payload.role}". Use somente a chave anon.`);
  } catch { fail('SUPABASE_ANON_KEY parece um JWT inválido.'); }
} else if (!/^sb_publishable_/.test(key)) {
  fail('SUPABASE_ANON_KEY não parece uma chave anon (eyJ...) nem publishable (sb_publishable_...).');
}

const cfg = { supabaseUrl: url, supabaseAnonKey: key, vapidPublicKey: vapid, paymentsEnabled: false, environment };
writeFileSync(join(root, 'js', 'config.js'),
`// GERADO por scripts/generate-config.mjs no build. Somente valores públicos.
window.VAI_CONFIG = Object.assign(${JSON.stringify(cfg, null, 2)}, window.VAI_CONFIG || {});
`);
console.log(`[generate-config] js/config.js gerado (ambiente: ${environment}).`);
