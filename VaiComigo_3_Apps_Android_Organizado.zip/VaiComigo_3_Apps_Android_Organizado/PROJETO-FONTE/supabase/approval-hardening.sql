-- Aplicar pelo Supabase após conferir o projeto. Exige análise da CNH e do CRLV.
create or replace function public.admin_set_driver_document_status(p_driver_id uuid, p_status text)
returns public.drivers language plpgsql security definer set search_path to 'public' as $$
declare d public.drivers; ready boolean;
begin
 if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
 if p_status not in ('pending','approved','rejected') then raise exception 'Status de documento inválido'; end if;
 if p_status='approved' then
  select count(*)=2 and coalesce(bool_and(status='approved' and
    (expires_at is null or expires_at>=current_date)),false)
  into ready from (
    select distinct on (document_type) document_type,status,expires_at
    from public.driver_documents where driver_id=p_driver_id
      and document_type in ('cnh','crlv')
    order by document_type,created_at desc,id desc
  ) docs;
  if not ready then raise exception 'Aprove CNH e CRLV válidos antes de liberar este motorista'; end if;
 end if;
 update public.drivers set document_status=p_status,
   status=case when p_status<>'approved' then 'offline' else status end,
   updated_at=now() where id=p_driver_id returning * into d;
 if d.id is null then raise exception 'Motorista não encontrado'; end if;
 return d;
end;$$;

create or replace function public.admin_review_driver_document(
 p_document_id uuid,p_status text,p_reason text default null)
returns public.driver_documents language plpgsql security definer set search_path to 'public' as $$
declare x public.driver_documents; ready boolean;
begin
 if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
 if p_status not in ('pending','approved','rejected','expired') then raise exception 'Status inválido'; end if;
 update public.driver_documents set status=p_status,
   rejection_reason=case when p_status='rejected' then nullif(trim(p_reason),'') else null end,
   reviewed_at=now(),reviewed_by=auth.uid(),updated_at=now()
 where id=p_document_id returning * into x;
 if x.id is null then raise exception 'Documento não encontrado'; end if;
 if p_status='approved' then
  select count(*)=2 and coalesce(bool_and(status='approved' and
    (expires_at is null or expires_at>=current_date)),false)
  into ready from (
    select distinct on (document_type) document_type,status,expires_at
    from public.driver_documents where driver_id=x.driver_id
      and document_type in ('cnh','crlv')
    order by document_type,created_at desc,id desc
  ) docs;
  if ready then perform public.admin_set_driver_document_status(x.driver_id,'approved');
  else update public.drivers set document_status='pending',status='offline',updated_at=now()
       where id=x.driver_id;
  end if;
 else
  update public.drivers set
   document_status=case when p_status='rejected' then 'rejected' else 'pending' end,
   status='offline',updated_at=now() where id=x.driver_id;
 end if;
 return x;
end;$$;

create or replace function public.reset_driver_review_on_document_upload()
returns trigger language plpgsql security definer set search_path to 'public' as $$
begin
 new.status='pending';new.reviewed_at=null;new.reviewed_by=null;new.rejection_reason=null;
 update public.drivers set document_status='pending',status='offline',updated_at=now()
 where id=new.driver_id;
 return new;
end;$$;

drop trigger if exists driver_document_requires_review on public.driver_documents;
create trigger driver_document_requires_review before insert on public.driver_documents
for each row execute function public.reset_driver_review_on_document_upload();

revoke execute on function public.reset_driver_review_on_document_upload() from public,anon,authenticated;

create or replace function public.admin_set_driver_status(p_driver_id uuid,p_status text)
returns public.drivers language plpgsql security definer set search_path to 'public' as $$
declare d public.drivers;
begin
 if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
 if p_status not in ('offline','available','busy','suspended') then
  raise exception 'Status de motorista inválido'; end if;
 select * into d from public.drivers where id=p_driver_id;
 if d.id is null then raise exception 'Motorista não encontrado'; end if;
 if p_status in ('available','busy') and d.document_status<>'approved' then
  raise exception 'Motorista ainda não foi aprovado'; end if;
 update public.drivers set status=p_status,updated_at=now()
 where id=p_driver_id returning * into d;
 return d;
end;$$;
