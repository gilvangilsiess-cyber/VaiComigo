-- Corrige transições administrativas sem desfazer suspensão e encerra atalhos de teste.
create or replace function public.admin_set_driver_document_status(p_driver_id uuid, p_status text)
returns public.drivers language plpgsql security definer set search_path to 'public' as $$
declare d public.drivers; ready boolean;
begin
 if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
 if p_status not in ('pending','approved','rejected') then raise exception 'Status de documento inválido'; end if;
 if p_status='approved' then
  select count(*)=2 and coalesce(bool_and(status='approved' and
    (expires_at is null or expires_at>=current_date)),false)
  into ready from (
    select distinct on (document_type) document_type,status,expires_at
    from public.driver_documents where driver_id=p_driver_id
      and document_type in ('cnh','crlv')
    order by document_type,created_at desc,id desc
  ) docs;
  if not ready then raise exception 'Aprove CNH e CRLV válidos antes de liberar este motorista'; end if;
 end if;
 update public.drivers set document_status=p_status,
   status=case when status='suspended' then 'suspended' when p_status<>'approved' then 'offline' else status end,
   updated_at=now() where id=p_driver_id returning * into d;
 if d.id is null then raise exception 'Motorista não encontrado'; end if;
 return d;
end;$$;

create or replace function public.admin_review_driver_document(
 p_document_id uuid,p_status text,p_reason text default null)
returns public.driver_documents language plpgsql security definer set search_path to 'public' as $$
declare x public.driver_documents; ready boolean;
begin
 if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
 if p_status not in ('approved','rejected') then raise exception 'Decisão inválida'; end if;
 if p_status='rejected' and nullif(trim(p_reason),'') is null then raise exception 'Informe o motivo da reprovação'; end if;
 update public.driver_documents set status=p_status,
   rejection_reason=case when p_status='rejected' then nullif(trim(p_reason),'') else null end,
   reviewed_at=now(),reviewed_by=auth.uid(),updated_at=now()
 where id=p_document_id and status='pending' and (p_status<>'approved' or expires_at is null or expires_at>=current_date) returning * into x;
 if x.id is null then raise exception 'Documento não encontrado'; end if;
 if p_status='approved' then
  select count(*)=2 and coalesce(bool_and(status='approved' and
    (expires_at is null or expires_at>=current_date)),false)
  into ready from (
    select distinct on (document_type) document_type,status,expires_at
    from public.driver_documents where driver_id=x.driver_id
      and document_type in ('cnh','crlv')
    order by document_type,created_at desc,id desc
  ) docs;
  if ready then perform public.admin_set_driver_document_status(x.driver_id,'approved');
  else update public.drivers set document_status='pending',status=case when status='suspended' then 'suspended' else 'offline' end,updated_at=now()
       where id=x.driver_id;
  end if;
 else
  update public.drivers set
   document_status=case when p_status='rejected' then 'rejected' else 'pending' end,
   status=case when status='suspended' then 'suspended' else 'offline' end,updated_at=now() where id=x.driver_id;
 end if;
 return x;
end;$$;


-- Um novo documento não pode ressuscitar uma conta suspensa.
create or replace function public.expire_driver_documents()
returns integer language plpgsql security definer set search_path to 'public' as $$
declare n integer;
begin
 update public.driver_documents set status='expired',updated_at=now()
 where expires_at is not null and expires_at<current_date and status='approved';
 get diagnostics n=row_count;
 update public.drivers d set document_status='pending',
 status=case when d.status='suspended' then 'suspended' else 'offline' end,updated_at=now()
 where exists(select 1 from public.driver_documents x where x.driver_id=d.id and x.status='expired');
 return n;
end;$$;

update public.platform_settings set test_mode_enabled=false,updated_at=now() where id=true;
revoke all on function public.admin_set_test_mode(boolean) from public,anon,authenticated;
revoke all on function public.test_prepare_my_driver(text,text,text,text) from public,anon,authenticated;
revoke all on function public.test_set_my_driver_location(double precision,double precision) from public,anon,authenticated;
