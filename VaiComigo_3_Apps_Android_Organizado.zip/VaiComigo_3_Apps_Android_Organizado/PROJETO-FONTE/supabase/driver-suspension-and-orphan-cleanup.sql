-- Suspensão administrativa não pode ser desfeita por envio de documento ou botão de ficar online.
create or replace function public.reset_driver_review_on_document_upload()
returns trigger language plpgsql security definer set search_path to 'public' as $$
begin
 if new.document_type not in ('cnh','crlv') then raise exception 'Tipo de documento inválido';end if;
 if auth.uid() is not null and new.driver_id is distinct from auth.uid() then
  raise exception 'Você só pode enviar seus documentos';end if;
 if auth.uid() is not null and
   (new.file_path is null or left(new.file_path,length(new.driver_id::text)+1)<>new.driver_id::text||'/' or
    not exists(select 1 from storage.objects o where o.bucket_id='driver-documents' and o.name=new.file_path)) then
  raise exception 'Faça upload do arquivo privado antes de enviá-lo para análise';end if;
 new.status='pending';new.reviewed_at=null;new.reviewed_by=null;new.rejection_reason=null;
 update public.drivers set document_status='pending',
  status=case when status='suspended' then 'suspended' else 'offline' end,updated_at=now()
 where id=new.driver_id;
 return new;
end;$$;

create or replace function public.set_driver_availability(p_available boolean)
returns public.drivers language plpgsql security definer set search_path to 'public' as $$
declare d public.drivers;
begin
 if auth.uid() is null then raise exception 'Usuário não autenticado';end if;
 select * into d from public.drivers where id=auth.uid() for update;
 if d.id is null then raise exception 'Cadastro de motorista não encontrado';end if;
 if p_available and d.status='suspended' then
  raise exception 'Sua conta de motorista está suspensa. Peça à administração para reativá-la';end if;
 if p_available and not public.driver_identity_and_documents_ready(auth.uid()) then
  raise exception 'Aguarde aprovação da identidade, CNH e CRLV antes de receber corridas';end if;
 update public.drivers set status=case when p_available then 'available' else
  case when d.status='suspended' then 'suspended' else 'offline' end end,
  updated_at=now() where id=auth.uid() returning * into d;
 return d;
end;$$;

-- Somente o próprio dono pode remover um upload que nunca virou documento cadastrado.
create policy "driver docs owner remove unregistered upload" on storage.objects
 for delete to authenticated using (
 bucket_id='driver-documents' and (storage.foldername(name))[1]=(select auth.uid())::text
 and not exists(select 1 from public.driver_documents d
  where d.driver_id=(select auth.uid()) and d.file_path=name)
);
