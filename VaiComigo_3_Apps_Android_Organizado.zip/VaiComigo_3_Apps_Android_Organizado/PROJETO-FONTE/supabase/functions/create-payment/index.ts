import { withSupabase } from 'npm:@supabase/server'

const MP_API = 'https://api.mercadopago.com'
const cors = {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type'}

function json(data: unknown, status=200){return new Response(JSON.stringify(data),{status,headers:{...cors,'Content-Type':'application/json'}})}

export default {
  fetch: withSupabase({auth:'user'}, async (req, ctx) => {
    if(req.method==='OPTIONS') return new Response('ok',{headers:cors})
    const token = Deno.env.get('MP_ACCESS_TOKEN')
    if(!token) return json({error:'MP_ACCESS_TOKEN não configurado no Supabase.'},500)
    const body = await req.json().catch(()=>({}))
    const rideId = String(body.ride_id||'')
    if(!rideId) return json({error:'ride_id obrigatório.'},400)

    const {data:ride,error:rideError}=await ctx.supabase
      .from('rides')
      .select('id,passenger_id,driver_id,status,final_price,estimated_price,fare_estimate,payment_method,destination_name')
      .eq('id',rideId).eq('passenger_id',ctx.userClaims?.sub).maybeSingle()
    if(rideError||!ride) return json({error:'Corrida não encontrada.'},404)
    if(ride.status!=='completed') return json({error:'O pagamento só pode ser iniciado após a corrida.'},400)

    const amount=Number(ride.final_price ?? ride.estimated_price ?? ride.fare_estimate ?? 0)
    if(!Number.isFinite(amount)||amount<=0) return json({error:'Valor da corrida inválido.'},400)

    const {data:tx,error:txError}=await ctx.supabase.rpc('create_payment_intent',{p_ride_id:rideId})
    if(txError||!tx) return json({error:txError?.message||'Não foi possível criar a transação.'},400)

    const {data:profile}=await ctx.supabase.from('profiles').select('full_name,phone').eq('id',ctx.userClaims?.sub).maybeSingle()
    const email=ctx.userClaims?.email
    const name=profile?.full_name || 'Passageiro VaiComigo'
    const method=String(ride.payment_method||'pix')
    const headers={'Authorization':`Bearer ${token}`,'Content-Type':'application/json'}

    if(method==='pix'){
      const response=await fetch(`${MP_API}/v1/payments`,{method:'POST',headers:{...headers,'X-Idempotency-Key':String(tx.id)},body:JSON.stringify({transaction_amount:Number(amount.toFixed(2)),description:`VaiComigo — corrida ${ride.id}`,payment_method_id:'pix',payer:{email,first_name:name}})})
      const mp=await response.json().catch(()=>({}))
      if(!response.ok) return json({error:mp.message||'Mercado Pago recusou a cobrança.',details:mp},400)
      const sync=await ctx.supabaseAdmin.rpc('sync_external_payment',{p_provider:'mercadopago',p_provider_reference:String(mp.id),p_status:mp.status||'pending',p_external_status:mp.status_detail||mp.status,p_qr_code:mp.point_of_interaction?.transaction_data?.qr_code||null,p_qr_code_base64:mp.point_of_interaction?.transaction_data?.qr_code_base64||null,p_payload:mp})
      if(sync.error) return json({error:sync.error.message},500)
      return json({kind:'pix',transaction:sync.data,qr_code:mp.point_of_interaction?.transaction_data?.qr_code||null,qr_code_base64:mp.point_of_interaction?.transaction_data?.qr_code_base64||null,external_id:String(mp.id),status:mp.status})
    }

    if(method==='card'){
      const functionUrl=new URL(req.url)
      const notification_url=`${functionUrl.origin}/functions/v1/mp-webhook`
      const response=await fetch(`${MP_API}/checkout/preferences`,{method:'POST',headers:{...headers,'X-Idempotency-Key':String(tx.id)},body:JSON.stringify({items:[{id:String(ride.id),title:`Corrida VaiComigo — ${ride.destination_name||'destino'}`,quantity:1,currency_id:'BRL',unit_price:Number(amount.toFixed(2))}],payer:{email,name},external_reference:String(tx.id),notification_url,back_urls:{success:`${functionUrl.origin}/?payment=success`,failure:`${functionUrl.origin}/?payment=failure`,pending:`${functionUrl.origin}/?payment=pending`},auto_return:'approved'})})
      const mp=await response.json().catch(()=>({}))
      if(!response.ok) return json({error:mp.message||'Não foi possível criar o checkout do cartão.',details:mp},400)
      const sync=await ctx.supabaseAdmin.rpc('sync_external_payment',{p_provider:'mercadopago',p_provider_reference:String(mp.id),p_status:'pending',p_external_status:'checkout_created',p_checkout_url:mp.init_point||mp.sandbox_init_point||null,p_payload:mp})
      if(sync.error) return json({error:sync.error.message},500)
      return json({kind:'card',transaction:sync.data,checkout_url:mp.init_point||mp.sandbox_init_point,external_id:String(mp.id),status:'pending'})
    }

    return json({error:'Método não suportado pela integração online.'},400)
  })
}
