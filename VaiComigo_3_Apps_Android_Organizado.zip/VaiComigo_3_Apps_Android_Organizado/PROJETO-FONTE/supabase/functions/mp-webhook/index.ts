import { createClient } from 'npm:@supabase/supabase-js@2'

const cors={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'content-type'}
function json(data:unknown,status=200){return new Response(JSON.stringify(data),{status,headers:{...cors,'Content-Type':'application/json'}})}

async function verifySignature(req: Request, paymentId: string): Promise<boolean>{
  const secret=Deno.env.get('MP_WEBHOOK_SECRET') || ''
  if(!secret) return false
  const signature=req.headers.get('x-signature') || ''
  const requestId=req.headers.get('x-request-id') || ''
  if(!signature || !requestId || !paymentId) return false
  const parts=Object.fromEntries(signature.split(',').map(x=>x.trim().split('=')))
  const ts=parts.ts || ''
  const v1=parts.v1 || ''
  if(!ts || !v1 || !/^\d+$/.test(ts)) return false
  const age=Math.abs(Date.now()/1000-Number(ts))
  if(!Number.isFinite(age) || age > 300) return false
  const manifest=`id:${paymentId};request-id:${requestId};ts:${ts};`
  const keyData=new TextEncoder().encode(secret)
  const data=new TextEncoder().encode(manifest)
  const key=await crypto.subtle.importKey('raw',keyData,{name:'HMAC',hash:'SHA-256'},false,['sign'])
  const sig=await crypto.subtle.sign('HMAC',key,data)
  const expected=Array.from(new Uint8Array(sig)).map(b=>b.toString(16).padStart(2,'0')).join('')
  if(v1.length!==expected.length) return false
  let diff=0
  for(let i=0;i<expected.length;i++) diff |= expected.charCodeAt(i)^v1.charCodeAt(i)
  return diff===0
}

export default {async fetch(req:Request){
  if(req.method==='OPTIONS') return new Response('ok',{headers:cors})
  if(req.method!=='POST') return json({error:'Método não permitido'},405)
  const token=Deno.env.get('MP_ACCESS_TOKEN')
  const url=new URL(req.url)
  const body=await req.json().catch(()=>({}))
  const paymentId=String(body?.data?.id||url.searchParams.get('data.id')||url.searchParams.get('id')||'')
  if(!token||!paymentId) return json({ok:true})

  if(!(await verifySignature(req,paymentId))) return json({error:'Assinatura do webhook inválida ou ausente.'},401)

  const response=await fetch(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(paymentId)}`,{headers:{Authorization:`Bearer ${token}`}})
  if(!response.ok) return json({error:'Falha ao consultar pagamento'},502)
  const mp=await response.json()

  const secret= Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
  if(!secret) return json({error:'SUPABASE_SERVICE_ROLE_KEY não configurado.'},500)
  const supabaseUrl=Deno.env.get('SUPABASE_URL')!
  const admin=createClient(supabaseUrl,secret)
  const sync=await admin.rpc('sync_external_payment',{p_provider:'mercadopago',p_provider_reference:String(mp.id),p_status:mp.status||'pending',p_external_status:mp.status_detail||mp.status,p_qr_code:mp.point_of_interaction?.transaction_data?.qr_code||null,p_qr_code_base64:mp.point_of_interaction?.transaction_data?.qr_code_base64||null,p_payload:mp})
  if(sync.error) return json({error:sync.error.message},500)
  return json({ok:true})
}}
