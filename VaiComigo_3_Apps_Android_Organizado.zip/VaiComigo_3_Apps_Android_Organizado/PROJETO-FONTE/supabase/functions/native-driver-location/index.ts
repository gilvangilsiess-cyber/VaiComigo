import { createClient } from 'npm:@supabase/supabase-js@2'

// Endpoint exclusivo do serviço Android. A RPC valida credencial, prazo,
// documentos, identidade e estado do motorista a cada ponto recebido.
const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, {
  auth: { autoRefreshToken: false, persistSession: false },
})

Deno.serve(async req => {
  if (req.method !== 'POST') return new Response('', { status: 405 })
  const token = req.headers.get('x-vai-location-token') || ''
  if (!/^[a-f0-9]{64}$/.test(token)) return new Response('', { status: 401 })
  try {
    if (Number(req.headers.get('content-length') || 0) > 8192) return new Response('', { status: 413 })
    const body = await req.json()
    const num = (value: unknown) => typeof value === 'number' && Number.isFinite(value) ? value : null
    const { data, error } = await admin.rpc('ingest_native_driver_location', {
      p_token: token, p_lat: num(body.latitude), p_lng: num(body.longitude),
      p_accuracy: num(body.accuracy), p_heading: num(body.bearing),
      p_speed: num(body.speed), p_time: num(body.time),
    })
    if (error) { console.error('Falha ao registrar localização nativa:', error.code); return new Response('', { status: 500 }) }
    return new Response('', { status: data === true ? 204 : 403 })
  } catch { return new Response('', { status: 400 }) }
})
