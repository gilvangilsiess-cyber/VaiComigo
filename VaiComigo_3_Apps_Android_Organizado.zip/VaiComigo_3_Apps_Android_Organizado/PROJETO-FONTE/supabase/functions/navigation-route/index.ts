/* Mapbox Directions stays server-side. The JWT gateway admits signed-in users;
   consumers fall back to their existing route provider if this function fails. */
const cors={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization,apikey,content-type,x-client-info','Access-Control-Allow-Methods':'POST,OPTIONS'};
const reply=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{...cors,'Content-Type':'application/json','Cache-Control':'no-store'}});
function valid(point){return point&&Number.isFinite(point.lat)&&Number.isFinite(point.lng)&&point.lat>=-35&&point.lat<=6&&point.lng>=-75&&point.lng<=-32}
Deno.serve(async request=>{
 if(request.method==='OPTIONS')return reply({ok:true});
 if(request.method!=='POST')return reply({error:'method_not_allowed'},405);
 const key=Deno.env.get('MAPBOX_ACCESS_TOKEN');if(!key)return reply({error:'traffic_provider_not_configured'},503);
 let input;try{input=await request.json()}catch{return reply({error:'invalid_json'},400)}
 const origin={lat:Number(input?.origin?.lat),lng:Number(input?.origin?.lng)},target={lat:Number(input?.target?.lat),lng:Number(input?.target?.lng)};
 if(!valid(origin)||!valid(target))return reply({error:'invalid_coordinates'},400);
 const path=`${origin.lng},${origin.lat};${target.lng},${target.lat}`;
 const url=new URL('https://api.mapbox.com/directions/v5/mapbox/driving-traffic/'+path);
 for(const [k,v] of Object.entries({overview:'full',geometries:'geojson',steps:'true',language:'pt-BR',annotations:'congestion,duration,distance'}))url.searchParams.set(k,v);
 url.searchParams.set('access_token',key);
 const abort=new AbortController(),timeout=setTimeout(()=>abort.abort(),7000);
 try{
  const response=await fetch(url,{signal:abort.signal});
  if(!response.ok)return reply({error:'route_provider_unavailable'},502);
  const data=await response.json(),route=data.routes?.[0];
  if(!route?.geometry?.coordinates||!Array.isArray(route.legs))return reply({error:'route_empty'},502);
  const traffic=route.legs.flatMap(leg=>leg.annotation?.congestion||[]);
  const coverage=traffic.some(level=>['low','moderate','heavy','severe'].includes(level));
  return reply({route:{distance:route.distance,duration:route.duration,geometry:route.geometry,legs:route.legs.map(leg=>({steps:leg.steps||[]}))},traffic:coverage?{source:'mapbox-driving-traffic',congestion:traffic}:null,source:'mapbox'});
 }catch{return reply({error:'route_provider_timeout'},504)}finally{clearTimeout(timeout)}
});
