import { createClient } from 'npm:@supabase/supabase-js@2'

type Place = {id:string;name:string;address:string;category:string;lat:number;lng:number;distance_m:number;source:string;score?:number}
const CORS={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization,apikey,content-type,x-client-info','Access-Control-Allow-Methods':'POST,OPTIONS'}
const respond=(data:unknown,status=200)=>new Response(JSON.stringify(data),{status,headers:{...CORS,'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}})
const normalize=(value:string)=>value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim()
const distance=(a:number,b:number,c:number,d:number)=>{const r=Math.PI/180,x=(c-a)*r,y=(d-b)*r;const h=Math.sin(x/2)**2+Math.cos(a*r)*Math.cos(c*r)*Math.sin(y/2)**2;return 12742000*Math.atan2(Math.sqrt(h),Math.sqrt(1-h))}
function category(text:string){const s=normalize(text);if(/hotel|guest|motel|pousada|hostel|lodging|accommodation/.test(s))return 'hotel';if(/shop|mall|shopping|store|supermarket/.test(s))return 'shopping';if(/museum|tour|attraction|monument|castle|palace|historic|camera/.test(s))return 'tourism';if(/terminal|station|bus|airport|train|transport/.test(s))return 'transport';if(/district|borough|neighbourhood|neighborhood|locality|suburb/.test(s))return 'neighborhood';if(/street|road|house|address|place/.test(s))return 'address';return 'other'}
function rank(place:Place,q:string,lat:number,lng:number){const a=normalize(place.name),b=normalize(place.address);const parts=q.split(' ').filter(Boolean);const match=a===q?210:a.startsWith(q)?155:a.includes(q)?105:parts.every(t=>(a+' '+b).includes(t))?68:0;const intent=q==='bairro'&&place.category==='neighborhood'?130:0;return match+intent+(place.source==='catalog'?28:0)+(/^(neighborhood|address)$/.test(place.category)?12:0)-Math.min(55,place.distance_m/1200)}
function dedup(rows:Place[],q:string,lat:number,lng:number,limit:number){const seen=new Set<string>();return rows.filter(p=>Number.isFinite(p.lat)&&Number.isFinite(p.lng)&&p.name&&p.address).map(p=>({...p,score:rank(p,q,lat,lng)})).filter(p=>p.score!>8).sort((a,b)=>b.score!-a.score!||a.distance_m-b.distance_m).filter(p=>{const k=/^(address|neighborhood)$/.test(p.category)?p.category+'|'+normalize(p.name):normalize(p.name)+'|'+Math.round(p.lat*1000)+'|'+Math.round(p.lng*1000);if(seen.has(k))return false;seen.add(k);return true}).slice(0,limit)}
function pointOf(item:any){const pos=item.access?.[0]||item.position;return {lat:Number(pos?.lat),lng:Number(pos?.lng)}}
function hereItems(json:any,lat:number,lng:number,wide:boolean):Place[]{return (json.items||[]).flatMap((item:any)=>{const p=pointOf(item);if(!Number.isFinite(p.lat)||!Number.isFinite(p.lng))return [];if(!wide&&(p.lat < -22.70||p.lat > -22.25||p.lng < -43.65||p.lng > -42.93))return [];const address=String(item.address?.label||item.title||'').slice(0,320);return [{id:'here:'+String(item.id||address),name:String(item.title||address).slice(0,160),address,category:category([item.resultType,item.categories?.map((c:any)=>c.name).join(' ')].join(' ')),lat:p.lat,lng:p.lng,distance_m:distance(lat,lng,p.lat,p.lng),source:'here'}]})}
function photonItems(json:any,lat:number,lng:number,wide:boolean):Place[]{return (json.features||[]).flatMap((feature:any)=>{const props=feature.properties||{},coords=feature.geometry?.coordinates||[],p={lng:Number(coords[0]),lat:Number(coords[1])};if(!Number.isFinite(p.lat)||!Number.isFinite(p.lng)||(!wide&&(p.lat < -22.70||p.lat > -22.25||p.lng < -43.65||p.lng > -42.93)))return [];if(!wide&&props.city&&normalize(props.city)!=='petropolis')return [];const name=String(props.name||props.street||props.district||props.locality||'').slice(0,160);const street=props.street?String(props.street)+(props.housenumber?', '+props.housenumber:''):'';const address=[street||name,props.district||props.locality,props.city||'Petrópolis',props.state||'RJ','Brasil'].filter(Boolean).join(', ').slice(0,320);return name?[{id:'osm:'+String(props.osm_type)+':'+String(props.osm_id),name,address,category:category([props.osm_key,props.osm_value,props.type].join(' ')),lat:p.lat,lng:p.lng,distance_m:distance(lat,lng,p.lat,p.lng),source:'osm'}]:[]})}
async function fetchJSON(url:string){const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),3200);try{const r=await fetch(url,{signal:ctrl.signal,headers:{Accept:'application/json'}});if(!r.ok)throw Error('geocoder_'+r.status+':'+(await r.text()).slice(0,180));return await r.json()}finally{clearTimeout(timer)}}

Deno.serve(async req=>{
 if(req.method==='OPTIONS')return respond({ok:true});
 if(req.method!=='POST')return respond({error:'Método inválido'},405);
 const anon=Deno.env.get('SUPABASE_ANON_KEY')||'';
 let publishable:Record<string,string>={};try{publishable=JSON.parse(Deno.env.get('SUPABASE_PUBLISHABLE_KEYS')||'{}')}catch{}
 const supplied=req.headers.get('apikey')||'';
 if(!supplied||!Object.values(publishable).includes(supplied)&&supplied!==anon)return respond({error:'Chave pública inválida'},401);
 let input:any;try{input=await req.json()}catch{return respond({error:'Dados inválidos'},400)}
 const q=normalize(String(input.query||'').slice(0,120));if(q.length<1||q.length>120)return respond({items:[],source:'empty'});
 const wide=input.wide===true,lat=Number(input.lat),lng=Number(input.lng);
 const originLat=lat>=-90&&lat<=90?lat:-22.51,originLng=lng>=-180&&lng<=180?lng:-43.18;
 const api=Deno.env.get('SUPABASE_URL')||'',secret=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')||'';
 const authorization=req.headers.get('Authorization')||'';
 const jwt=authorization.startsWith('Bearer ')&&authorization.slice(7).split('.').length===3?authorization:`Bearer ${anon}`;
 const db=createClient(api,anon,{global:{headers:{Authorization:jwt}},auth:{persistSession:false}});
 const admin=createClient(api,secret,{auth:{persistSession:false}});
 const {data:curated,error:catalogError}=await db.rpc('search_ride_pois',{p_query:q,p_lat:originLat,p_lng:originLng,p_limit:20});
 const local:Place[]=(curated||[]).map((p:any)=>({id:'poi:'+p.id,name:p.name,address:p.address,category:p.category,lat:p.lat,lng:p.lng,distance_m:p.distance_m,source:'catalog'}));
 if(catalogError)console.warn('poi_search',catalogError.message);
 const key=Deno.env.get('HERE_API_KEY');let external:Place[]=[],source='catalog',degraded=false;
 if(key){try{const url=new URL('https://autosuggest.search.hereapi.com/v1/autosuggest');url.searchParams.set('q',q);url.searchParams.set('at',originLat+','+originLng);url.searchParams.set('limit',wide?'30':'20');url.searchParams.set('lang','pt-BR');url.searchParams.set('apiKey',key);url.searchParams.set('in',wide?'countryCode:BRA':'countryCode:BRA');external=hereItems(await fetchJSON(url.toString()),originLat,originLng,wide);source='here'}catch(error){console.warn('HERE indisponível',String(error));degraded=true}}
 if(!key||degraded||!external.length){source='osm';const cacheKey='osm:'+q+':'+(wide?'wide':'local')+':'+originLat.toFixed(2)+':'+originLng.toFixed(2);
   try{const {data:cached}=await admin.from('place_search_cache').select('payload').eq('cache_key',cacheKey).gt('expires_at',new Date().toISOString()).maybeSingle();
    if(cached?.payload)external=cached.payload as Place[];
    else if(q.length>=2){const url=new URL('https://photon.komoot.io/api/');url.searchParams.set('q',q);url.searchParams.set('lat',String(originLat));url.searchParams.set('lon',String(originLng));url.searchParams.set('limit',wide?'30':'20');if(!wide)url.searchParams.set('bbox','-43.65,-22.70,-42.93,-22.25');external=photonItems(await fetchJSON(url.toString()),originLat,originLng,wide);await admin.from('place_search_cache').upsert({cache_key:cacheKey,payload:external,expires_at:new Date(Date.now()+12*3600000).toISOString()})}
   }catch(error){console.warn('Photon indisponível',String(error));degraded=true}
 }
 const items=dedup([...local,...external.map(p=>({...p,distance_m:distance(originLat,originLng,p.lat,p.lng)}))],q,originLat,originLng,wide?25:12);
 return respond({items,source,degraded,region:wide?'Brasil':'Petrópolis'});
})
