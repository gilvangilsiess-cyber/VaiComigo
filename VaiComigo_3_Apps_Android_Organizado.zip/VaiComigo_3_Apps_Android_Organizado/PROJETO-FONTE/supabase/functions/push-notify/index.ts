import webpush from 'npm:web-push@3.6.7'
import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY')!
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const VAPID_SUBJECT = Deno.env.get('VAPID_SUBJECT') || 'mailto:admin@vai-comigo.local'

const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false },
})

const userClient = (token: string) => createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  global: { headers: { Authorization: `Bearer ${token}` } },
  auth: { autoRefreshToken: false, persistSession: false },
})

// Somente service_role pode executar esta RPC. Nenhuma chave privada fica no app
// ou no código implantado; Vault guarda o valor criptografado em repouso.
let vapidReady = false
async function ensureVapidReady() {
  if (vapidReady) return
  const { data, error } = await admin.rpc('get_push_vapid_keys')
  if (error || !data?.public_key || !data?.private_key) {
    throw new Error('Chaves VAPID não configuradas no Vault.')
  }
  webpush.setVapidDetails(VAPID_SUBJECT, data.public_key, data.private_key)
  vapidReady = true
}

async function sendToSubscriptions(subscriptions: any[], payload: Record<string, unknown>) {
  if (!subscriptions.length) return []
  await ensureVapidReady()

  const results = await Promise.allSettled(subscriptions.map(async sub => {
    const subscription = {
      endpoint: sub.endpoint,
      keys: { p256dh: sub.p256dh, auth: sub.auth },
    }

    try {
      await webpush.sendNotification(subscription, JSON.stringify(payload), {
        TTL: 120,
        urgency: 'high',
      })
      return { endpoint: sub.endpoint, ok: true }
    } catch (error: any) {
      const status = error?.statusCode
      if (status === 404 || status === 410) {
        await admin.from('push_subscriptions').delete().eq('id', sub.id)
      }
      return { endpoint: sub.endpoint, ok: false, status }
    }
  }))

  return results.map(x => x.status === 'fulfilled' ? x.value : { ok: false })
}

// Credencial FCM permanece exclusivamente nos Secrets desta função.
let fcmAccess: { token: string; expires: number } | null = null
const base64url = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
async function getFcmAccessToken() {
  if (fcmAccess && fcmAccess.expires > Date.now() + 60_000) return fcmAccess.token
  const raw = Deno.env.get('FCM_SERVICE_ACCOUNT_JSON')
  if (!raw) throw new Error('FCM_SERVICE_ACCOUNT_JSON ainda não foi configurado.')
  const service = JSON.parse(raw)
  if (!service.project_id || !service.client_email || !service.private_key) throw new Error('Credencial FCM incompleta.')
  const issued = Math.floor(Date.now() / 1000)
  const header = base64url(new TextEncoder().encode(JSON.stringify({ alg: 'RS256', typ: 'JWT' })))
  const payload = base64url(new TextEncoder().encode(JSON.stringify({
    iss: service.client_email, scope: 'https://www.googleapis.com/auth/firebase.messaging',
    aud: 'https://oauth2.googleapis.com/token', iat: issued, exp: issued + 3600,
  })))
  const bytes = Uint8Array.from(atob(service.private_key.replace(/-----[^-]+-----/g, '').replace(/\s/g, '')), c => c.charCodeAt(0))
  const key = await crypto.subtle.importKey('pkcs8', bytes, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign'])
  const signed = new Uint8Array(await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, new TextEncoder().encode(`${header}.${payload}`)))
  const assertion = `${header}.${payload}.${base64url(signed)}`
  const response = await fetch('https://oauth2.googleapis.com/token', { method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion }),
  })
  if (!response.ok) throw new Error('FCM não autorizou o servidor de envio.')
  const result = await response.json()
  fcmAccess = { token: result.access_token, expires: Date.now() + Number(result.expires_in || 3600) * 1000 }
  return fcmAccess.token
}
async function sendNativeTokens(tokens: any[]) {
  if (!tokens.length) return []
  const raw = Deno.env.get('FCM_SERVICE_ACCOUNT_JSON')
  if (!raw) throw new Error('Credencial FCM não configurada.')
  const projectId = JSON.parse(raw).project_id
  const access = await getFcmAccessToken()
  return await Promise.all(tokens.map(async row => {
    const response = await fetch(`https://fcm.googleapis.com/v1/projects/${encodeURIComponent(projectId)}/messages:send`, {
      method: 'POST', headers: { Authorization: `Bearer ${access}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: { token: row.token,
        notification: { title: 'Nova corrida', body: 'Abra o app para conferir a chamada.' },
        data: { type: 'ride_request' }, android: { priority: 'HIGH', ttl: '120s' },
      } }),
    })
    if (response.ok) return { ok: true }
    if (response.status === 404) await admin.from('native_push_tokens').delete().eq('token', row.token)
    return { ok: false, status: response.status }
  }))
}

Deno.serve(async req => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ error: 'Método não permitido.' }, 405)

  try {
    const auth = req.headers.get('Authorization') || ''
    const token = auth.startsWith('Bearer ') ? auth.slice(7) : ''
    const webhookSecret = req.headers.get('x-vai-webhook-secret') || ''
    let isWebhookAuthorized = false
    if (webhookSecret) {
      const { data: stored, error } = await admin.rpc('get_push_webhook_secret')
      if (error) throw error
      // The token is kept in Vault, never in code, cron metadata or the app.
      if (stored && webhookSecret.length === stored.length) {
        let diff = 0
        for (let i = 0; i < stored.length; i++) diff |= webhookSecret.charCodeAt(i) ^ stored.charCodeAt(i)
        isWebhookAuthorized = diff === 0
      }
    }
    const isServiceRequest = token === SUPABASE_SERVICE_ROLE_KEY || isWebhookAuthorized
    if (!token && !isWebhookAuthorized) return json({ error: 'Autenticação necessária.' }, 401)

    let user: any = null
    if (!isServiceRequest) {
      const caller = userClient(token)
      const { data: { user: authUser }, error: userError } = await caller.auth.getUser(token)
      if (userError || !authUser) return json({ error: 'Sessão inválida.' }, 401)
      user = authUser
    }

    const body = await req.json()
    // Supabase Database Webhook envia { type, table, record, old_record }.
    // O fallback action/ride_id mantém compatibilidade com o app e chamadas manuais.
    const webhookRideId = body?.record?.id || body?.new_record?.id || body?.ride_id || ''
    const isWebhook = Boolean(body?.record || body?.new_record)
    const action = isWebhook ? 'process_ride_queue' : (body?.action || 'ride_request')

    if (action === 'diag_ping') {
      if (!isServiceRequest) return json({ error: 'Acesso negado.' }, 403)
      const { data, error } = await admin.rpc('get_push_vapid_keys')
      return json({ ready: !error && !!data?.public_key && !!data?.private_key, service: 'push-notify' })
    }

    async function notifyRide(rideId: string) {
      if (!rideId) throw new Error('ride_id é obrigatório.')

      const { data: claimed, error: claimError } = await admin.rpc('claim_ride_push', {
        p_ride_id: rideId,
        p_lock_seconds: 90,
      })
      if (claimError) throw claimError
      if (!claimed) return { ride_id: rideId, sent: 0, skipped: true, reason: 'locked_or_processed' }

      try {
        const { data: ride, error: rideError } = await admin
          .from('rides')
          .select('id,status,destination_name,estimated_price,origin_lat,origin_lng')
          .eq('id', rideId)
          .maybeSingle()
        if (rideError || !ride) throw new Error('Corrida não encontrada.')
        if (ride.status !== 'requested') {
          await admin.rpc('finish_ride_push', { p_ride_id: rideId, p_success: true, p_error: null })
          return { ride_id: ride.id, sent: 0, skipped: true, reason: 'ride_not_requested' }
        }

        const { data: candidates, error: candidateError } = await admin.rpc('push_ride_candidates', {
          p_ride_id: ride.id,
          p_radius_km: 10,
          p_fresh_seconds: 180,
        })
        if (candidateError) throw candidateError

        const driverIds = [...new Set((candidates || []).map((d: any) => d.driver_id).filter(Boolean))]
        if (!driverIds.length) {
          await admin.rpc('finish_ride_push', {
            p_ride_id: rideId,
            p_success: false,
            p_error: 'Nenhum motorista elegível no momento.',
          })
          return { ride_id: ride.id, sent: 0, drivers: 0, retry: true }
        }

        const { data: subscriptions, error: subError } = await admin
          .from('push_subscriptions')
          .select('id,user_id,endpoint,p256dh,auth')
          .in('user_id', driverIds)
        if (subError) throw subError

        const { data: nativeTokens, error: nativeError } = await admin
          .from('native_push_tokens').select('token,user_id').in('user_id', driverIds)
        if (nativeError) throw nativeError
        if (!subscriptions?.length && !nativeTokens?.length) {
          await admin.rpc('finish_ride_push', { p_ride_id: rideId, p_success: false,
            p_error: 'Motoristas elegíveis sem inscrição de alerta.' })
          return { ride_id: ride.id, sent: 0, drivers: driverIds.length, retry: true }
        }

        const payload = {
          title: '🔔 Nova corrida',
          body: 'Abra o app para conferir a chamada.',
          icon: './icon.svg',
          badge: './icon.svg',
          tag: 'nova-corrida',
          data: { type: 'ride_request', url: './' },
        }
        const results = await Promise.all([
          subscriptions?.length ? sendToSubscriptions(subscriptions, payload).catch(() => []) : Promise.resolve([]),
          nativeTokens?.length ? sendNativeTokens(nativeTokens).catch(() => []) : Promise.resolve([]),
        ])
        const sent = results.flat().filter((r: any) => r.ok).length
        if (sent > 0) {
          await admin.rpc('finish_ride_push', { p_ride_id: rideId, p_success: true, p_error: null })
        } else {
          await admin.rpc('finish_ride_push', { p_ride_id: rideId, p_success: false, p_error: 'Nenhum push foi entregue.' })
        }
        return { ride_id: ride.id, sent, subscriptions: results.flat().length, drivers: driverIds.length, retry: sent === 0 }
      } catch (error) {
        await admin.rpc('finish_ride_push', {
          p_ride_id: rideId,
          p_success: false,
          p_error: error instanceof Error ? error.message : 'Erro ao enviar push',
        })
        throw error
      }
    }

    if (action === 'ride_request' || action === 'process_ride_queue') {
      const isQueue = action === 'process_ride_queue'
      if (isQueue && !isServiceRequest) return json({ error: 'Acesso negado.' }, 403)

      let rideId = String(body?.ride_id || webhookRideId || '')
      if (isQueue && !rideId) {
        const { data: pending, error: queueError } = await admin.rpc('pending_ride_pushes', { p_limit: 25 })
        if (queueError) throw queueError
        const results = []
        for (const item of pending || []) {
          results.push(await notifyRide(item.ride_id))
        }
        return json({ processed: results.length, results })
      }

      if (!rideId) return json({ error: 'ride_id é obrigatório.' }, 400)
      if (!isQueue) {
        const { data: ride, error: rideError } = await admin
          .from('rides')
          .select('id,passenger_id,status,destination_name,estimated_price,origin_lat,origin_lng')
          .eq('id', rideId)
          .maybeSingle()
        if (rideError || !ride) return json({ error: 'Corrida não encontrada.' }, 404)
        if (ride.passenger_id !== user.id) return json({ error: 'Sem permissão para esta corrida.' }, 403)
      }
      return json(await notifyRide(rideId))
    }

    if (action === 'user_notification') {
      const userId = String(body?.user_id || '')
      if (!userId) return json({ error: 'user_id é obrigatório.' }, 400)

      // Só permite que um usuário envie uma notificação para si mesmo. Para
      // notificações de outro usuário, use a ação ride_request acima ou uma
      // função server-side específica com autorização própria.
      if (userId !== user.id) return json({ error: 'Sem permissão.' }, 403)

      const { data: subscriptions, error } = await admin
        .from('push_subscriptions')
        .select('id,user_id,endpoint,p256dh,auth')
        .eq('user_id', userId)

      if (error) throw error

      const payload = {
        title: String(body?.title || 'VaiComigo'),
        body: String(body?.message || 'Você recebeu uma nova atualização.'),
        icon: './icon.svg',
        badge: './icon.svg',
        data: body?.data || {},
      }

      const results = await sendToSubscriptions(subscriptions || [], payload)
      return json({ sent: results.filter((r: any) => r.ok).length, subscriptions: results.length })
    }

    return json({ error: 'Ação não suportada.' }, 400)
  } catch (error) {
    console.error(error)
    return json({ error: error instanceof Error ? error.message : 'Erro interno.' }, 500)
  }
})
