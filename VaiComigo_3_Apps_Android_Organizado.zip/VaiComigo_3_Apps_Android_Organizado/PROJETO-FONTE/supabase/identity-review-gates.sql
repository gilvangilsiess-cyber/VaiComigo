-- Fechamento de rotas legadas e exigência dos dois documentos reais do motorista.
create or replace function public.driver_identity_and_documents_ready(p_driver_id uuid)
returns boolean language sql security definer set search_path to 'public' as $$
 select exists(select 1 from public.identity_reviews i where i.user_id=p_driver_id and i.status='approved')
 and exists(select 1 from public.drivers d where d.id=p_driver_id and d.document_status='approved')
 and (select count(*)=2 and coalesce(bool_and(status='approved' and (expires_at is null or expires_at>=current_date)),false)
      from (select distinct on (document_type) document_type,status,expires_at
            from public.driver_documents where driver_id=p_driver_id and document_type in ('cnh','crlv')
            order by document_type,created_at desc,id desc) docs);
$$;
revoke all on function public.driver_identity_and_documents_ready(uuid) from public,anon,authenticated;

create or replace function public.update_driver_location(
 p_lat double precision,p_lng double precision,p_accuracy double precision default null,
 p_heading double precision default null,p_speed double precision default null)
returns public.drivers language plpgsql security definer set search_path to 'public' as $$
declare d public.drivers;
begin
 if auth.uid() is null then raise exception 'Usuário não autenticado';end if;
 if p_lat is null or p_lng is null or p_lat not between -90 and 90 or p_lng not between -180 and 180 then
  raise exception 'Coordenadas inválidas';end if;
 -- GPS nunca deve cadastrar ou habilitar motorista implicitamente.
 update public.drivers set lat=p_lat,lng=p_lng,updated_at=now(),location_accuracy=p_accuracy,
  heading=p_heading,speed=p_speed,location_updated_at=now() where id=auth.uid() returning * into d;
 if d.id is null then raise exception 'Cadastre-se como motorista antes de compartilhar o GPS';end if;
 if d.status='available' and not public.driver_identity_and_documents_ready(d.id) then
  update public.drivers set status='offline' where id=d.id returning * into d;
 end if;
 insert into public.driver_location_history(driver_id,lat,lng,accuracy,heading,speed,recorded_at)
 values(auth.uid(),p_lat,p_lng,p_accuracy,p_heading,p_speed,now());
 return d;
end;$$;

create or replace function public.set_driver_availability(p_available boolean)
returns public.drivers language plpgsql security definer set search_path to 'public' as $$
declare d public.drivers;
begin
 if auth.uid() is null then raise exception 'Usuário não autenticado';end if;
 if p_available and not public.driver_identity_and_documents_ready(auth.uid()) then
  raise exception 'Aguarde aprovação da identidade, CNH e CRLV antes de receber corridas';end if;
 update public.drivers set status=case when p_available then 'available' else 'offline' end,updated_at=now()
 where id=auth.uid() returning * into d;
 if d.id is null then raise exception 'Cadastro de motorista não encontrado';end if;
 return d;
end;$$;

create or replace function public.accept_ride(p_ride_id uuid)
returns public.rides language plpgsql security definer set search_path to 'public' as $$
declare r public.rides;
begin
 if not public.driver_identity_and_documents_ready(auth.uid()) or
    not exists(select 1 from public.drivers where id=auth.uid() and status='available') then
  raise exception 'Motorista não está disponível ou não está aprovado';end if;
 if exists(select 1 from public.rides x where x.driver_id=auth.uid()
  and x.status in ('accepted','arriving','in_progress')) then
  raise exception 'Motorista já possui uma corrida em andamento';end if;
 update public.rides set driver_id=auth.uid(),status='accepted',accepted_at=coalesce(accepted_at,now())
 where id=p_ride_id and driver_id is null and status in ('requested','offered') returning * into r;
 if r.id is null then raise exception 'Corrida já foi aceita ou não está mais disponível';end if;
 update public.drivers set status='busy',updated_at=now() where id=auth.uid();
 return r;
end;$$;

create or replace function public.admin_set_driver_status(p_driver_id uuid,p_status text)
returns public.drivers language plpgsql security definer set search_path to 'public' as $$
declare d public.drivers;
begin
 if not public.is_admin() then raise exception 'Acesso administrativo negado';end if;
 if p_status not in ('offline','available','busy','suspended') then raise exception 'Status de motorista inválido';end if;
 if p_status in ('available','busy') and not public.driver_identity_and_documents_ready(p_driver_id) then
  raise exception 'Aguarde aprovação da identidade, CNH e CRLV';end if;
 update public.drivers set status=p_status,updated_at=now() where id=p_driver_id returning * into d;
 if d.id is null then raise exception 'Motorista não encontrado';end if;
 return d;
end;$$;

-- O atalho de criação de conta de teste contrariava a análise obrigatória.
revoke execute on function public.test_prepare_my_driver(text,text,text,text) from public,anon,authenticated;
