-- Verificação manual de identidade. Documentos privados; aprovação no servidor.
create table if not exists public.identity_reviews (
 user_id uuid primary key references auth.users(id) on delete cascade,
 status text not null default 'draft' check(status in ('draft','pending','approved','rejected')),
 document_kind text check(document_kind in ('rg','cnh','passport')),
 document_front_path text, document_back_path text,
 selfie_path text, selfie_with_document_path text,
 consent_at timestamptz, privacy_notice_version text,
 submitted_at timestamptz, reviewed_at timestamptz,
 reviewed_by uuid references auth.users(id), rejection_reason text,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
alter table public.identity_reviews enable row level security;
create policy "identity owner or director read" on public.identity_reviews for select to authenticated
 using(user_id=(select auth.uid()) or public.is_admin());
revoke all on public.identity_reviews from anon,authenticated;
grant select on public.identity_reviews to authenticated;

create table if not exists public.identity_review_events (
 id bigint generated always as identity primary key,
 user_id uuid not null references auth.users(id) on delete cascade,
 reviewer_id uuid not null references auth.users(id),
 decision text not null check(decision in ('approved','rejected')),
 reason text, created_at timestamptz not null default now()
);
alter table public.identity_review_events enable row level security;
create policy "director reads identity review history" on public.identity_review_events for select to authenticated
 using(public.is_admin());
revoke all on public.identity_review_events from anon,authenticated;
grant select on public.identity_review_events to authenticated;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('vai-identity-private','vai-identity-private',false,8388608,
 array['image/jpeg','image/png','image/webp'])
on conflict(id) do update set public=false,file_size_limit=8388608,
 allowed_mime_types=array['image/jpeg','image/png','image/webp'];
create policy "identity evidence owner upload" on storage.objects for insert to authenticated
 with check(bucket_id='vai-identity-private' and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy "identity evidence owner or director read" on storage.objects for select to authenticated
 using(bucket_id='vai-identity-private' and
  ((storage.foldername(name))[1]=(select auth.uid())::text or public.is_admin()));

create or replace function public.submit_my_identity(
 p_kind text,p_front text,p_back text,p_selfie text,p_with_document text,p_consent boolean)
returns public.identity_reviews language plpgsql security definer set search_path to 'public' as $$
declare u uuid:=auth.uid(); rec public.identity_reviews; path text;
begin
 if u is null then raise exception 'Entre na sua conta para continuar';end if;
 if p_consent is distinct from true then raise exception 'Leia e aceite o aviso de dados antes de enviar';end if;
 if p_kind not in ('rg','cnh','passport') then raise exception 'Selecione um documento válido';end if;
 if exists(select 1 from public.identity_reviews where user_id=u and status in ('pending','approved')) then
  raise exception 'Seu envio já está em análise ou aprovado';end if;
 foreach path in array array[p_front,p_back,p_selfie,p_with_document] loop
  if path is null or left(path,length(u::text)+1)<>u::text||'/' or
   not exists(select 1 from storage.objects where bucket_id='vai-identity-private' and name=path) then
   raise exception 'Envie as quatro fotos antes de solicitar a análise';
  end if;
 end loop;
 insert into public.identity_reviews(user_id,status,document_kind,document_front_path,
  document_back_path,selfie_path,selfie_with_document_path,consent_at,
  privacy_notice_version,submitted_at,updated_at,rejection_reason)
 values(u,'pending',p_kind,p_front,p_back,p_selfie,p_with_document,now(),
  'identity-notice-2026-09',now(),now(),null)
 on conflict(user_id) do update set status='pending',document_kind=excluded.document_kind,
  document_front_path=excluded.document_front_path,document_back_path=excluded.document_back_path,
  selfie_path=excluded.selfie_path,selfie_with_document_path=excluded.selfie_with_document_path,
  consent_at=excluded.consent_at,privacy_notice_version=excluded.privacy_notice_version,
  submitted_at=excluded.submitted_at,updated_at=now(),rejection_reason=null,
  reviewed_at=null,reviewed_by=null
 returning * into rec;
 return rec;
end;$$;
revoke execute on function public.submit_my_identity(text,text,text,text,text,boolean) from public,anon;
grant execute on function public.submit_my_identity(text,text,text,text,text,boolean) to authenticated;

create or replace function public.admin_identity_queue()
returns table(user_id uuid,full_name text,account_role text,review_status text,
 document_kind text,document_front_path text,document_back_path text,
 selfie_path text,selfie_with_document_path text,submitted_at timestamptz,
 reviewed_at timestamptz,rejection_reason text)
language plpgsql security definer set search_path to 'public' as $$
begin
 if not public.is_admin() then raise exception 'Acesso administrativo negado';end if;
 return query select r.user_id,p.full_name,p.role,r.status,r.document_kind,
  r.document_front_path,r.document_back_path,r.selfie_path,r.selfie_with_document_path,
  r.submitted_at,r.reviewed_at,r.rejection_reason
 from public.identity_reviews r left join public.profiles p on p.id=r.user_id
 order by case r.status when 'pending' then 0 else 1 end,r.submitted_at desc nulls last limit 100;
end;$$;
revoke execute on function public.admin_identity_queue() from public,anon;
grant execute on function public.admin_identity_queue() to authenticated;

create or replace function public.admin_review_identity(p_user_id uuid,p_decision text,p_reason text default null)
returns public.identity_reviews language plpgsql security definer set search_path to 'public' as $$
declare rec public.identity_reviews;
begin
 if not public.is_admin() then raise exception 'Acesso administrativo negado';end if;
 if p_decision not in ('approved','rejected') then raise exception 'Decisão inválida';end if;
 if p_decision='rejected' and nullif(trim(p_reason),'') is null then
  raise exception 'Informe o motivo para que a pessoa possa corrigir o cadastro';end if;
 update public.identity_reviews set status=p_decision,reviewed_at=now(),
 reviewed_by=auth.uid(),rejection_reason=case when p_decision='rejected' then trim(p_reason) else null end,
 updated_at=now()
 where user_id=p_user_id and status='pending'
 and document_front_path is not null and document_back_path is not null
 and selfie_path is not null and selfie_with_document_path is not null
 returning * into rec;
 if rec.user_id is null then raise exception 'Solicitação pendente completa não encontrada';end if;
 insert into public.identity_review_events(user_id,reviewer_id,decision,reason)
 values(p_user_id,auth.uid(),p_decision,rec.rejection_reason);
 return rec;
end;$$;
revoke execute on function public.admin_review_identity(uuid,text,text) from public,anon;
grant execute on function public.admin_review_identity(uuid,text,text) to authenticated;

create or replace function public.require_verified_passenger(p_user_id uuid)
returns void language plpgsql security definer set search_path to 'public' as $$
begin
 if p_user_id is distinct from auth.uid() then raise exception 'Conta inválida';end if;
 if not exists(select 1 from public.identity_reviews where user_id=p_user_id and status='approved') then
  raise exception 'Sua identidade precisa ser aprovada pelo VaiComigo antes de solicitar uma corrida';
 end if;
end;$$;
revoke execute on function public.require_verified_passenger(uuid) from public,anon;
grant execute on function public.require_verified_passenger(uuid) to authenticated;

create or replace function public.create_ride_quote(
 p_origin_lat double precision,p_origin_lng double precision,p_destination_name text,
 p_distance_km numeric,p_duration_min numeric,p_payment_method text default 'pix')
returns public.rides language plpgsql security definer set search_path to 'public' as $$
declare r public.rides; v_fare numeric(10,2);v_method text:=lower(coalesce(p_payment_method,'pix'));
 v_test boolean:=public.get_test_mode();
begin
 if auth.uid() is null then raise exception 'Usuário não autenticado';end if;
 perform public.require_verified_passenger(auth.uid());
 if p_origin_lat is null or p_origin_lng is null then raise exception 'Localização de origem obrigatória';end if;
 if p_distance_km is null or p_distance_km<0 or p_distance_km>500 then raise exception 'Distância inválida';end if;
 if p_duration_min is null or p_duration_min<0 or p_duration_min>1440 then raise exception 'Duração inválida';end if;
 if v_method not in ('pix','card','cash') then raise exception 'Método de pagamento inválido';end if;
 v_fare:=public.estimate_ride_fare(p_distance_km,p_duration_min);
 insert into public.rides(passenger_id,origin_lat,origin_lng,destination_name,ride_type,
  estimated_price,fare_estimate,route_distance_km,route_duration_min,quote_source,
  payment_method,payment_status,status,test_run)
 values(auth.uid(),p_origin_lat,p_origin_lng,nullif(trim(p_destination_name),''),'simple',
  v_fare,v_fare,round(p_distance_km,2),round(p_duration_min,2),'vai_route',
  v_method,'pending','requested',v_test) returning * into r;
 return r;
end;$$;

create or replace function public.guard_passenger_tour()
returns trigger language plpgsql set search_path to 'public' as $$
begin
 if current_user <> 'authenticated' then return new;end if;
 if tg_op='INSERT' then
  perform public.require_verified_passenger(new.passenger_id);
  if new.passenger_id is distinct from auth.uid() or new.driver_id is not null
   or new.status<>'requested' or new.duration_hours not in (4,6,8)
   or new.price is distinct from(case new.duration_hours when 4 then 200 when 6 then 280 when 8 then 360 end)
  then raise exception 'Solicitação de Tour inválida';end if;
 elsif tg_op='UPDATE' then
  if old.status<>'requested' or new.status<>'cancelled' or
   (to_jsonb(new)-'status'-'updated_at') is distinct from (to_jsonb(old)-'status'-'updated_at')
  then raise exception 'Somente cancelamento de Tour solicitado é permitido';end if;
 end if;
 return new;
end;$$;

create or replace function public.set_driver_availability(p_available boolean)
returns public.drivers language plpgsql security definer set search_path to 'public' as $$
declare d public.drivers;
begin
 if auth.uid() is null then raise exception 'Usuário não autenticado';end if;
 if p_available then
  if not exists(select 1 from public.identity_reviews where user_id=auth.uid() and status='approved') then
   raise exception 'Sua identidade precisa ser aprovada antes de receber corridas';end if;
  update public.drivers set status='available',updated_at=now()
  where id=auth.uid() and coalesce(document_status,'pending')='approved' returning * into d;
  if d.id is null then
   if exists(select 1 from public.drivers where id=auth.uid()) then
    raise exception 'Motorista ainda não foi aprovado pelo administrador';end if;
   raise exception 'Cadastro de motorista não encontrado';end if;
 else
  update public.drivers set status='offline',updated_at=now()
  where id=auth.uid() returning * into d;
  if d.id is null then raise exception 'Cadastro de motorista não encontrado';end if;
 end if;
 return d;
end;$$;

create or replace function public.accept_ride(p_ride_id uuid)
returns public.rides language plpgsql security definer set search_path to 'public' as $$
declare r public.rides;
begin
 if not exists(select 1 from public.drivers d join public.identity_reviews i on i.user_id=d.id
  where d.id=auth.uid() and d.status='available' and d.document_status='approved'
  and i.status='approved') then
  raise exception 'Motorista não está disponível ou não está aprovado';end if;
 if exists(select 1 from public.rides x where x.driver_id=auth.uid()
  and x.status in ('accepted','arriving','in_progress')) then
  raise exception 'Motorista já possui uma corrida em andamento';end if;
 update public.rides set driver_id=auth.uid(),status='accepted',accepted_at=coalesce(accepted_at,now())
 where id=p_ride_id and driver_id is null and status in ('requested','offered') returning * into r;
 if r.id is null then raise exception 'Corrida já foi aceita ou não está mais disponível';end if;
 update public.drivers set status='busy',updated_at=now() where id=auth.uid();
 return r;
end;$$;

create or replace function public.admin_set_driver_status(p_driver_id uuid,p_status text)
returns public.drivers language plpgsql security definer set search_path to 'public' as $$
declare d public.drivers;
begin
 if not public.is_admin() then raise exception 'Acesso administrativo negado';end if;
 if p_status not in ('offline','available','busy','suspended') then
  raise exception 'Status de motorista inválido';end if;
 select * into d from public.drivers where id=p_driver_id;
 if d.id is null then raise exception 'Motorista não encontrado';end if;
 if p_status in ('available','busy') and (d.document_status<>'approved' or
  not exists(select 1 from public.identity_reviews where user_id=p_driver_id and status='approved')) then
  raise exception 'Identidade e documentos do motorista precisam ser aprovados';end if;
 update public.drivers set status=p_status,updated_at=now()
 where id=p_driver_id returning * into d;
 return d;
end;$$;
