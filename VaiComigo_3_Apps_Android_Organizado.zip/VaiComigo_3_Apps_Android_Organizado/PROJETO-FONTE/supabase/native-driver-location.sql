-- Credencial limitada a publicar localização, com prazo curto e sem acesso às demais APIs.
create table if not exists public.native_driver_location_keys (
  driver_id uuid primary key references auth.users(id) on delete cascade,
  token_hash text not null unique,
  expires_at timestamptz not null,
  updated_at timestamptz not null default now()
);
alter table public.native_driver_location_keys enable row level security;
revoke all on public.native_driver_location_keys from public, anon, authenticated;

create or replace function public.set_my_native_location_key(p_token text)
returns void language plpgsql security definer set search_path='public', 'extensions' as $$
begin
 if auth.uid() is null then raise exception 'Entre na conta'; end if;
 if p_token is null or length(p_token) <> 64 or p_token !~ '^[a-f0-9]{64}$' then raise exception 'Credencial inválida'; end if;
 if not exists(select 1 from public.drivers where id=auth.uid() and status in ('available','busy'))
    or not public.driver_identity_and_documents_ready(auth.uid()) then
   raise exception 'Motorista não está aprovado e online';
 end if;
 insert into public.native_driver_location_keys(driver_id,token_hash,expires_at)
 values(auth.uid(),encode(extensions.digest(p_token,'sha256'),'hex'),now()+interval '24 hours')
 on conflict(driver_id) do update set token_hash=excluded.token_hash,expires_at=excluded.expires_at,updated_at=now();
end; $$;
revoke all on function public.set_my_native_location_key(text) from public,anon;
grant execute on function public.set_my_native_location_key(text) to authenticated;

create or replace function public.clear_my_native_location_key()
returns void language plpgsql security definer set search_path='public' as $$
begin
 if auth.uid() is null then raise exception 'Entre na conta'; end if;
 delete from public.native_driver_location_keys where driver_id=auth.uid();
end; $$;
revoke all on function public.clear_my_native_location_key() from public,anon;
grant execute on function public.clear_my_native_location_key() to authenticated;

create or replace function public.ingest_native_driver_location(
 p_token text,p_lat double precision,p_lng double precision,p_accuracy double precision default null,
 p_heading double precision default null,p_speed double precision default null,p_time bigint default null)
returns boolean language plpgsql security definer set search_path='public','extensions' as $$
declare v_driver uuid;
begin
 if p_token is null or length(p_token)<>64 or p_token !~ '^[a-f0-9]{64}$'
    or p_lat is null or p_lng is null
    or p_lat not between -90 and 90 or p_lng not between -180 and 180
    or p_accuracy is null or p_accuracy not between 0 and 150
    or (p_heading is not null and p_heading not between 0 and 360)
    or (p_speed is not null and p_speed not between 0 and 100)
    or p_time is null or p_time not between 1577836800000 and 4102444800000
    or to_timestamp(p_time/1000.0) not between now()-interval '2 minutes' and now()+interval '30 seconds'
 then return false; end if;
 select k.driver_id into v_driver from public.native_driver_location_keys k
 join public.drivers d on d.id=k.driver_id
 where k.token_hash=encode(extensions.digest(p_token,'sha256'),'hex')
   and k.expires_at>now() and d.status in ('available','busy');
 if v_driver is null or not public.driver_identity_and_documents_ready(v_driver) then return false; end if;
 update public.drivers set lat=p_lat,lng=p_lng,location_accuracy=p_accuracy,
 heading=p_heading,speed=p_speed,location_updated_at=now(),updated_at=now() where id=v_driver;
 insert into public.driver_location_history(driver_id,lat,lng,accuracy,heading,speed,recorded_at)
 values(v_driver,p_lat,p_lng,p_accuracy,p_heading,p_speed,now());
 return true;
end; $$;
revoke all on function public.ingest_native_driver_location(text,double precision,double precision,double precision,double precision,double precision,bigint) from public,anon,authenticated;
grant execute on function public.ingest_native_driver_location(text,double precision,double precision,double precision,double precision,double precision,bigint) to service_role;
