-- Tokens FCM são privados e vinculados à conta autenticada. A chave Firebase fica só na Edge Function.
create table if not exists public.native_push_tokens (
 token text primary key check (length(token) between 32 and 4096),
 user_id uuid not null references auth.users(id) on delete cascade,
 platform text not null default 'android' check (platform='android'),
 updated_at timestamptz not null default now()
);
create index if not exists native_push_tokens_user_idx on public.native_push_tokens(user_id);
alter table public.native_push_tokens enable row level security;
revoke all on public.native_push_tokens from anon,authenticated;
grant select,delete on public.native_push_tokens to authenticated;
drop policy if exists native_push_own_read on public.native_push_tokens;
create policy native_push_own_read on public.native_push_tokens for select to authenticated
 using (user_id=(select auth.uid()));
drop policy if exists native_push_own_delete on public.native_push_tokens;
create policy native_push_own_delete on public.native_push_tokens for delete to authenticated
 using (user_id=(select auth.uid()));

create or replace function public.register_my_native_push(p_token text)
returns void language plpgsql security definer set search_path to 'public' as $$
begin
 if (select auth.uid()) is null then raise exception 'Entre na conta para receber alertas';end if;
 if p_token is null or length(p_token) not between 32 and 4096 then raise exception 'Token do aparelho inválido';end if;
 if not exists(select 1 from public.drivers where id=(select auth.uid())) then
  raise exception 'Cadastre-se como motorista antes de ativar alertas';end if;
 insert into public.native_push_tokens(token,user_id,platform,updated_at)
 values(p_token,(select auth.uid()),'android',now())
 on conflict(token) do update set user_id=excluded.user_id,updated_at=now();
end;$$;
revoke all on function public.register_my_native_push(text) from public,anon;
grant execute on function public.register_my_native_push(text) to authenticated;
