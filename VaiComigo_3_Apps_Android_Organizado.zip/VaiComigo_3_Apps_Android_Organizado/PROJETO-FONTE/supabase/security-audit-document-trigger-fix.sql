create or replace function public.reset_driver_review_on_document_upload()
returns trigger language plpgsql security definer set search_path to 'public' as $$
begin
 if new.document_type not in ('cnh','crlv') then raise exception 'Tipo de documento inválido';end if;
 if auth.uid() is not null and new.driver_id is distinct from auth.uid() then
  raise exception 'Você só pode enviar seus documentos';end if;
 if auth.uid() is not null and
   (new.file_path is null or left(new.file_path,length(new.driver_id::text)+1)<>new.driver_id::text||'/' or
    not exists(select 1 from storage.objects o where o.bucket_id='driver-documents' and o.name=new.file_path)) then
  raise exception 'Faça upload do arquivo privado antes de enviá-lo para análise';end if;
 new.status='pending';new.reviewed_at=null;new.reviewed_by=null;new.rejection_reason=null;
 update public.drivers set document_status='pending',status='offline',updated_at=now()
 where id=new.driver_id;
 return new;
end;$$;
