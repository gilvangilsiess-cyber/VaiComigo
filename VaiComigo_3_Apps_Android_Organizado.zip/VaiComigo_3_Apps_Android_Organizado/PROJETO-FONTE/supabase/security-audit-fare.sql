-- O aplicativo usa create_ride_with_destination; chamadas diretas ao cálculo sem destino não são expostas.
revoke execute on function public.create_ride_quote(double precision,double precision,text,numeric,numeric,text)
 from public,anon,authenticated;
