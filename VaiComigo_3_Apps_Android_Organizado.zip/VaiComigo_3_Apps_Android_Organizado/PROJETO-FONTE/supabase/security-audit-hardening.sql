-- 2026-09-24: autorização server-side de cargos e evidências privadas.
create or replace function public.guard_profile_role()
returns trigger language plpgsql set search_path to 'public' as $$
begin
 if current_user='authenticated' then
  if tg_op='INSERT' and new.role is distinct from 'passenger' then
   raise exception 'Função da conta é definida pelo servidor';end if;
  if tg_op='UPDATE' and new.role is distinct from old.role then
   raise exception 'Não é permitido alterar o tipo de conta diretamente';end if;
 end if;
 return new;
end;$$;
drop trigger if exists trg_guard_profile_role on public.profiles;
create trigger trg_guard_profile_role before insert or update on public.profiles
for each row execute function public.guard_profile_role();
revoke execute on function public.guard_profile_role() from public,anon,authenticated;

-- Fotos já enviadas não podem ser trocadas depois da aprovação.
drop policy if exists "driver docs storage update" on storage.objects;
update storage.buckets set file_size_limit=8388608,
 allowed_mime_types=array['image/jpeg','image/png','application/pdf']
 where id='driver-documents';

create or replace function public.reset_driver_review_on_document_upload()
returns trigger language plpgsql security definer set search_path to 'public' as $$
begin
 if new.document_type not in ('cnh','crlv') then raise exception 'Tipo de documento inválido';end if;
 if auth.uid() is not null and new.driver_id is distinct from auth.uid() then
  raise exception 'Você só pode enviar seus documentos';end if;
 if auth.uid() is not null and
   (new.file_path is null or left(new.file_path,length(new.driver_id::text)+1)<>new.driver_id::text||'/' or
    not exists(select 1 from storage.objects o where o.bucket_id='driver-documents' and o.name=new.file_path)) then
  raise exception 'Faça upload do arquivo privado antes de enviá-lo para análise';end if;
 new.status='pending';new.reviewed_at=null;new.reviewed_by=null;new.rejection_reason=null;
 update public.drivers set document_status='pending',status='offline',updated_at=now()
 where id=new.driver_id;
 return new;
end;$$;
revoke execute on function public.reset_driver_review_on_document_upload() from public,anon,authenticated;

-- Legado: conta de teste não pode virar motorista aprovado só por chamar register_driver.
-- O status documental somente deve vir da revisão dos arquivos.
create or replace function public.register_driver(
 p_full_name text,p_phone text,p_vehicle_model text,p_vehicle_plate text,
 p_vehicle_color text default null,p_vehicle_year integer default null)
returns public.drivers language plpgsql security definer set search_path to 'public' as $$
declare d public.drivers;u uuid:=auth.uid();
begin
 if u is null then raise exception 'Usuário não autenticado';end if;
 if nullif(trim(p_full_name),'') is null or nullif(trim(p_vehicle_model),'') is null
    or nullif(trim(p_vehicle_plate),'') is null then
  raise exception 'Preencha nome, modelo e placa do veículo';end if;
 insert into public.profiles(id,full_name,phone)
 values(u,trim(p_full_name),nullif(trim(p_phone),''))
 on conflict(id) do update set full_name=excluded.full_name,phone=excluded.phone;
 insert into public.drivers(id,status,full_name,phone,vehicle_model,vehicle_plate,
 vehicle_color,vehicle_year,document_status,updated_at)
 values(u,'offline',trim(p_full_name),nullif(trim(p_phone),''),trim(p_vehicle_model),
 upper(trim(p_vehicle_plate)),nullif(trim(p_vehicle_color),''),p_vehicle_year,'pending',now())
 on conflict(id) do update set full_name=excluded.full_name,phone=excluded.phone,
 vehicle_model=excluded.vehicle_model,vehicle_plate=excluded.vehicle_plate,
 vehicle_color=excluded.vehicle_color,vehicle_year=excluded.vehicle_year,updated_at=now()
 returning * into d;
 return d;
end;$$;

