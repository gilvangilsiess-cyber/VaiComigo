-- Coordenadas de embarque só para motoristas revisados e disponíveis.
create or replace function public.nearest_requested_rides(
 p_lat double precision,p_lng double precision,p_radius_km double precision default 10)
returns table(id uuid,distance_km double precision,destination_name text,
 estimated_price numeric,origin_lat double precision,origin_lng double precision)
language plpgsql security definer set search_path to 'public' as $$
begin
 if not public.driver_identity_and_documents_ready(auth.uid()) or
   not exists(select 1 from public.drivers d where d.id=auth.uid() and d.status='available') then
  raise exception 'Acesso reservado aos motoristas aprovados e disponíveis';end if;
 if p_lat is null or p_lng is null or p_lat not between -90 and 90 or p_lng not between -180 and 180
  or p_radius_km is null or p_radius_km<=0 or p_radius_km>30 then
  raise exception 'Coordenadas ou raio inválidos';end if;
 return query select r.id,
  earth_distance(ll_to_earth(r.origin_lat,r.origin_lng),ll_to_earth(p_lat,p_lng))/1000,
  r.destination_name,r.estimated_price,r.origin_lat,r.origin_lng
 from public.rides r
 where r.status='requested' and r.driver_id is null
 and r.origin_lat between -90 and 90 and r.origin_lng between -180 and 180
 and earth_distance(ll_to_earth(r.origin_lat,r.origin_lng),ll_to_earth(p_lat,p_lng))<=p_radius_km*1000
 order by earth_distance(ll_to_earth(r.origin_lat,r.origin_lng),ll_to_earth(p_lat,p_lng)) limit 10;
end;$$;

-- Dados do veículo apenas aos envolvidos na corrida ou à administração.
create or replace function public.get_public_driver_profile(p_driver_id uuid)
returns table(id uuid,full_name text,avatar_url text,vehicle_model text,
 vehicle_color text,vehicle_year integer,vehicle_plate text,rating numeric,
 rating_count bigint,approved boolean)
language sql security definer set search_path to 'public' as $$
 select d.id,d.full_name,d.avatar_url,d.vehicle_model,d.vehicle_color,d.vehicle_year,d.vehicle_plate,
  coalesce(round(avg(rr.rating)::numeric,1),0),count(rr.id),
  public.driver_identity_and_documents_ready(d.id)
 from public.drivers d left join public.ride_ratings rr on rr.driver_id=d.id
 where d.id=p_driver_id and (d.id=auth.uid() or public.is_admin() or
   exists(select 1 from public.rides r where r.driver_id=d.id and r.passenger_id=auth.uid()))
 group by d.id,d.full_name,d.avatar_url,d.vehicle_model,d.vehicle_color,
 d.vehicle_year,d.vehicle_plate,d.document_status;
$$;
