const test=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
function harness(area){
 const nodes=new Map();
 const node=id=>{
  if(!nodes.has(id)){
   const flags=new Set();
   nodes.set(id,{value:'',textContent:'',hidden:false,disabled:false,style:{},dataset:{},classList:{add(x){flags.add(x)},remove(x){flags.delete(x)},contains(x){return flags.has(x)},toggle(x,on){if(on)flags.add(x);else flags.delete(x)}},focus(){},scrollIntoView(){},setAttribute(){}});
  }
  return nodes.get(id);
 };
 const storage=new Map();
 const body={dataset:{entryRole:area},classList:{toggle(){}}};
 const ctx={window:{VAI_CONFIG:{},VaiPlaces:{places:[]},addEventListener(){},VaiNavigation:null},document:{body,getElementById:node,querySelector(){return null},querySelectorAll(){return []},addEventListener(){}},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},navigator:{},location:{origin:'https://vai.test',pathname:'/'},console,Set,Map,URL,setTimeout(){},clearTimeout(){},scrollTo(){}};
 vm.createContext(ctx);
 vm.runInContext(fs.readFileSync(path.join(__dirname,'../app.js'),'utf8'),ctx);
 ctx.window.appContext=null;
 return {ctx,node,body};
}
test('cadastro encerra sessão automática, fecha formulário e leva à entrada com email preenchido',async()=>{
 const {ctx,node}=harness('driver');let signedOut=0,called;
 ctx.window.supabaseClient={auth:{async signUp(input){called=input;return{data:{session:{user:{id:'abc'}}},error:null}},async signOut(){signedOut++;return{error:null}}}};
 ctx.openAuth('signup');node('authEmail').value='motorista@teste.com';node('authPassword').value='minhasenha';node('authName').value='Nome Completo';
 await ctx.submitAuth();
 assert.equal(signedOut,1);assert.equal(called.options.data.requested_area,'driver');
 assert.equal(node('authTitle').textContent,'Entrar');assert.equal(node('authEmail').value,'motorista@teste.com');
 assert.match(node('authMsg').textContent,/confirmação/);assert.equal(node('authModal').classList.contains('on'),true);
});
test('conta do diretor entra só na Administração, motorista novo encontra cadastro profissional',async()=>{
 for(const [area,kind] of [['driver','driver'],['admin','admin']]){
  const {ctx,node}=harness(area);let selected='',rejected='';
  const user={id:'u1',email:'p@teste.com',user_metadata:{requested_area:kind==='driver'?'driver':'admin'}};
  ctx.window.supabaseClient={auth:{async signInWithPassword(){return{data:{session:{user}},error:null}}}};
  ctx.ensureProfileData=async()=>{};ctx.loadProfileRole=async()=>{ctx.currentRole=kind==='admin'?'admin':'passenger'};
  ctx.refreshAppContext=async()=>{ctx.window.appContext={is_admin:kind==='admin',has_driver_profile:false,driver_document_status:'pending'}};
  ctx.refreshAccountUI=async()=>{};ctx.tab=(id)=>{selected=id};ctx.rejectWrongArea=async msg=>{rejected=msg};
  ctx.loadDriverProfileReal=async()=>{};ctx.loadMyDriverDocuments=async()=>{};ctx.loadDriverFinance=async()=>{};ctx.loadDriverEarnings=async()=>{};
  ctx.loadAdminDashboard=async()=>{};ctx.refreshAdminEntry=async()=>{};
  ctx.openAuth('login');node('authEmail').value='p@teste.com';node('authPassword').value='minhasenha';
  await ctx.submitAuth();
  assert.equal(rejected,'');assert.equal(selected,kind==='admin'?'admin':'driver');
  assert.equal(node('authModal').classList.contains('on'),false);
  if(kind==='driver')assert.match(node('driverJourneyStatus').textContent,/preencha seus dados/);
 }
});
test('conta administrativa não entra por engano como passageiro',async()=>{
 const {ctx,node}=harness('passenger');let explanation='';
 ctx.window.supabaseClient={auth:{async signInWithPassword(){return{data:{session:{user:{id:'owner',user_metadata:{}}}},error:null}}}};
 ctx.ensureProfileData=async()=>{};ctx.loadProfileRole=async()=>{ctx.currentRole='admin'};
 ctx.refreshAppContext=async()=>{ctx.window.appContext={is_admin:true,has_driver_profile:true}};
 ctx.rejectWrongArea=async text=>{explanation=text};
 ctx.openAuth('login');node('authEmail').value='admin@teste.com';node('authPassword').value='minhasenha';
 await ctx.submitAuth();assert.match(explanation,/motorista ou diretor/);
});
test('salvar veículo de conta nova registra motorista e aponta os documentos como próximo passo',async()=>{
 const {ctx,node}=harness('driver');let request;
 ctx.window.currentUser={id:'driver-1',user_metadata:{requested_area:'driver'}};
 ctx.window.appContext={has_driver_profile:false,driver_document_status:'pending'};
 ctx.window.supabaseClient={rpc:async(name,args)=>{request={name,args};return{data:{document_status:'pending'},error:null}}};
 ctx.ensureUser=async()=>ctx.window.currentUser;
 ctx.refreshAppContext=async()=>{ctx.window.appContext={has_driver_profile:true,driver_document_status:'pending'}};
 ctx.loadDriverProfileReal=async()=>{};
 node('driverName').value='Motorista';node('driverVehicle').value='Sedã';node('driverPlate').value='ABC1D23';
 await ctx.saveDriverProfileReal();
 assert.equal(request.name,'register_driver');assert.equal(request.args.p_vehicle_plate,'ABC1D23');
 assert.equal(ctx.window.appContext.has_driver_profile,true);
 assert.match(node('driverJourneyStatus').textContent,/CNH e CRLV/);
 assert.equal(node('driverProfileSave').disabled,false);
});
test('documentos pendentes e aprovados impedem reenvio após recarregar; reprovação permite correção',async()=>{
 const {ctx,node}=harness('driver');
 ctx.window.currentUser={id:'driver-1'};
 ctx.window.appContext={has_driver_profile:true,driver_document_status:'pending'};
 ctx.document.createElement=()=>({textContent:'',className:'',children:[],append(...items){this.children.push(...items)}});
 const box=node('myDriverDocs');box.children=[];box.replaceChildren=()=>{box.children=[]};box.append=x=>box.children.push(x);
 let rows=[{document_type:'cnh',status:'pending',file_name:'cnh.jpg',expires_at:null},{document_type:'crlv',status:'approved',file_name:'crlv.pdf',expires_at:null}];
 ctx.window.supabaseClient={rpc:async()=>({data:rows,error:null})};
 await ctx.loadMyDriverDocuments();
 assert.equal(node('driverSendCnh').disabled,true);assert.match(node('driverDocCnhStatus').textContent,/Aguardando análise/);
 assert.equal(node('driverSendCrlv').disabled,true);assert.match(node('driverDocCrlvStatus').textContent,/Aprovado/);
 rows=[{document_type:'cnh',status:'rejected',file_name:'cnh.jpg',rejection_reason:'foto ilegível'}];
 await ctx.loadMyDriverDocuments();
 assert.equal(node('driverSendCnh').disabled,false);assert.equal(node('driverSendCrlv').disabled,false);
 assert.match(box.children[0].children[0].children[2].textContent,/foto ilegível/);
});
