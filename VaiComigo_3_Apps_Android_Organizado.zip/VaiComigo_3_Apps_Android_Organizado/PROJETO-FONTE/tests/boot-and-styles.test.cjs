const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.join(__dirname, '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');

test('scripts de motorista inicializam no escopo global na ordem exigida pelo HTML', async () => {
  const html = read('index.html');
  const scripts = [...html.matchAll(/<script\s+src="([^"]+)"/g)].map(match => match[1]);
  const sequence = ['app.js', 'js/modules/gps-engine.js', 'js/modules/driver.js', 'js/ride-state.js'];
  for (let i = 1; i < sequence.length; i++) {
    assert.ok(scripts.indexOf(sequence[i - 1]) < scripts.indexOf(sequence[i]), `${sequence[i - 1]} antes de ${sequence[i]}`);
  }
  assert.doesNotMatch(html, /<script[^>]*type="module"/);

  const listeners = [];
  const window = {
    addEventListener: (...args) => listeners.push(args),
    dispatchEvent() {},
    location: { search: '' },
  };
  const document = { readyState: 'loading', getElementById: () => null };
  const navigator = {};
  const context = vm.createContext({ window, document, navigator, location: window.location, URLSearchParams, console, setTimeout, clearTimeout, CustomEvent: class {} });
  for (const script of sequence.slice(1, 4)) vm.runInContext(read(script), context, { filename: script });
  await Promise.resolve();
  assert.ok(window.VaiComigoGPS?.start);
  for (const name of ['toggleDriver', 'acceptRealCall', 'setRideStatus', 'renderDriverRideState', 'loadDriverRequests']) {
    assert.equal(typeof window[name], 'function', name);
  }
});

test('apresentação consolidada e arquivos do precache existem', () => {
  const html = read('index.html');
  const css = read('css/vai-design.css');
  const sw = read('sw.js');
  assert.doesNotMatch(html, /<style\b|\sstyle="/);
  assert.match(css, /data-theme=dark/);
  assert.doesNotMatch(sw, /vai-executive\.css|vai-stage3\.css/);
  for (const file of [...sw.matchAll(/^\s*'\.\/([^']+)'/gm)].map(match => match[1])) {
    assert.ok(fs.existsSync(path.join(root, file)), `${file} listado no service worker`);
  }
  for (const asset of ['leaflet.css', 'leaflet.js', 'maplibre-gl.css', 'maplibre-gl.js']) {
    const reference = asset.startsWith('leaflet') ? `vendor/leaflet/${asset}` : `vendor/maplibre/${asset}`;
    assert.ok(html.includes(`"${reference}"`), `${reference} servido pelo próprio app`);
    assert.ok(sw.includes(`'./${reference}'`), `${reference} armazenado no cache`);
  }
  assert.match(css, /--vc-page:#202021;\s*--vc-surface:#202021/);
  assert.match(css, /\.placesHead b\{[^}]*color:var\(--vc-ink\)/s);
  assert.match(css, /body:has\(#home\.active\) #map\{[^}]*background:var\(--vc-page\)/);
});

test('texto, legenda e destaque dourado permanecem legíveis nos dois fundos', () => {
  const css = read('css/vai-design.css');
  const rgb = hex => [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16) / 255);
  const lightness = hex => rgb(hex).map(v => v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4)
    .reduce((sum, v, i) => sum + v * [.2126, .7152, .0722][i], 0);
  const contrast = (a, b) => (Math.max(lightness(a), lightness(b)) + .05) / (Math.min(lightness(a), lightness(b)) + .05);
  for (const surface of ['#202021', '#171819']) {
    for (const ink of ['#f5f1e8', '#c8c0b5', '#d4b17a']) {
      assert.ok(contrast(surface, ink) >= 4.5, `${ink} sobre ${surface} tem contraste para texto normal`);
    }
  }
  assert.match(css, /--vc-page:#202021;--vc-surface:#202021/);
  assert.match(css, /--vc-page:#171819;--vc-surface:#171819/);
  assert.equal((css.match(/:root\s*\{/g) || []).length, 1);
});
