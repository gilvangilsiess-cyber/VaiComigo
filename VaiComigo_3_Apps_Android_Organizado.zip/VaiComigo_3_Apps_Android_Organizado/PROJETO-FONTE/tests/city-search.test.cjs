const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const ctx=vm.createContext({URL,console});
vm.runInContext(fs.readFileSync('js/city-search.js','utf8'),ctx);
const search=ctx.VaiCitySearch;
const feature=(name,props={},lat=-22.50,lng=-43.20)=>({type:'Feature',geometry:{type:'Point',coordinates:[lng,lat]},properties:{name,city:'Petrópolis',state:'Rio de Janeiro',countrycode:'BR',...props}});
(async()=>{
 const fixtures=[
  feature('Centro',{type:'district',district:'Centro'}),
  feature('Rua das Flores',{type:'street',street:'Rua das Flores',district:'Centro'}),
  feature('Rua das Flores',{type:'house',street:'Rua das Flores',housenumber:'123',district:'Centro'}),
  feature('Rua das Flores',{type:'street',city:'Outra Cidade'}),
  feature('Rua das Flores',{type:'street',city:'Petrópolis'},-22.90,-43.2),
  feature('Rua das Flores',{type:'street',countrycode:'US'})
 ];
 const calls=[];
 const fetcher=async(url)=>{calls.push(new URL(url));return {ok:true,json:async()=>({features:fixtures})}};
 const bairro=await search.search('Centro',{fetcher});assert.equal(bairro[0].kind,'Bairro');
 const ruas=await search.search('Rua das Flores',{fetcher});assert.equal(ruas.length,2);assert.equal(ruas[0].name,'Rua das Flores, 123');
 const casa=await search.search('Rua das Flores 123, Petrópolis',{fetcher});assert.equal(casa[0].hasHouseNumber,true);
 assert.equal(calls[0].searchParams.get('countrycode'),'BR');assert(calls[0].searchParams.has('bbox'));
 assert.equal(calls[0].searchParams.has('lang'),false,'Photon público rejeita lang=pt com HTTP 400');
 assert.equal(new URL(search.reverseUrl({lat:-22.51,lng:-43.18})).searchParams.has('lang'),false);
 assert.equal(search.mapFeature(feature('Rua Teste',{city:'Outra Cidade'})),null);
 console.log('Busca da cidade: bairro, rua, número, município e parâmetros OK');
})().catch(e=>{console.error(e);process.exitCode=1});
