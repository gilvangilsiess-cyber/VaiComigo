const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');

test('acompanhar motorista move a câmera e mantém a verificação de GPS antigo ativa',()=>{
 const source=fs.readFileSync('app.js','utf8');
 const code=source.slice(source.indexOf('let driverFollowActive='),source.indexOf('function tour(){'));
 const elements=new Map();
 const element=id=>{if(!elements.has(id))elements.set(id,{dataset:{},hidden:true,innerHTML:'',textContent:'',setAttribute(){}});return elements.get(id)};
 const positions=[];
 let intervalCleared=false,frame;
 const marker={point:{lat:-22.51,lng:-43.18},getLatLng(){return this.point},setLatLng(p){this.point={lat:p[0],lng:p[1]}},setHeading(){}};
 const map={native:true,ready:true,gl:{easeTo(options){positions.push(options)}},invalidateSize(){}};
 const window={driverLiveMarker:marker,driverLastLocation:{heading:90},driverStaleTimer:4};
 const context=vm.createContext({window,map,document:{getElementById:element,querySelector:element},console,
  Number,Date,performance:{now:()=>0},setTimeout(){},cancelAnimationFrame(){},requestAnimationFrame(cb){frame=cb;return 1},
  clearInterval(){intervalCleared=true},L:{latLng:(lat,lng)=>({lat,lng})},setDriverLocationStatus(){}});
 vm.runInContext(code,context);
 vm.runInContext('toggleDriverFollow(true)',context);
 assert.equal(element('#home .searchPanel').dataset.navigation,'active');
 assert.equal(element('mapFollow').hidden,false);
 assert.equal(positions.at(-1).pitch,53);
 vm.runInContext('animateDriverMarker({lat:-22.51,lng:-43.18},{lat:-22.50,lng:-43.17},1000)',context);
 frame(500);
 assert.equal(intervalCleared,false);
 assert.ok(positions.length>1);
 vm.runInContext('toggleDriverFollow(false)',context);
 assert.equal(element('mapFollow').hidden,true);
 assert.equal(element('#home .searchPanel').dataset.navigation,'off');
});
