# Teste com backend FALSO (somente lógica do cliente)
`python3 run.py` (Playwright + Chromium) abre o app com um Supabase simulado em memória.
Valida: login sem usuário anônimo, cadastro, cadastro de motorista, fluxo aceitar → finalizar → dinheiro,
e o Diagnóstico E2E. **Não valida** SQL, RLS, Realtime, Push, Edge Functions nem Mercado Pago reais.
No Chromium headless a geolocalização só é entregue quando `set_geolocation` é chamado (o script já faz isso).
