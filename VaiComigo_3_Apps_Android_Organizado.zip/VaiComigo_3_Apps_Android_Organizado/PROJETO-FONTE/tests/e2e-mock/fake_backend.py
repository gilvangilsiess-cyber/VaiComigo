"""Backend FALSO em memória: simula o contrato do Supabase só para exercitar o CLIENTE.
NÃO valida SQL, RLS, Realtime, Push nem Mercado Pago reais."""
import json, uuid, time, re
from datetime import datetime, timezone
def now(): return datetime.now(timezone.utc).isoformat()
class Backend:
    def __init__(s):
        s.users={}; s.tok={}; s.t={k:[] for k in ['profiles','drivers','rides','push_subscriptions','payment_transactions','driver_location_history','platform_settings','ride_push_queue','notifications']}
        s.test_mode=True; s.events=[]; s.seq=0; s.log=[]
    def ev(s,table,kind,new,old=None):
        s.seq+=1; s.events.append({'seq':s.seq,'table':table,'eventType':kind,'new':new,'old':old or {}})
    def uid(s,tok): return s.tok.get(tok)
    def handle(s,b):
        op=b['op']; u=s.uid(b.get('token'))
        if op=='signup' or op=='signin':
            e=b['email']
            if op=='signup':
                if e in s.users: return {'error':{'message':'User already registered'}}
                s.users[e]={'id':str(uuid.uuid4()),'email':e,'created_at':now(),'user_metadata':b.get('meta') or {}}
            if e not in s.users: return {'error':{'message':'Invalid login credentials'}}
            tk=str(uuid.uuid4()); s.tok[tk]=s.users[e]['id']
            return {'data':{'session':{'access_token':tk,'user':s.users[e]},'user':s.users[e]}}
        if op=='getuser':
            for x in s.users.values():
                if x['id']==u: return {'data':{'user':x}}
            return {'error':{'message':'invalid JWT'}}
        if op=='events': return {'data':[e for e in s.events if e['seq']>b['since']],'seq':s.seq}
        if op=='fn':
            return {'status':404,'body':{'error':'not found'}}
        if op=='rpc': return s.rpc(b['name'],b.get('args') or {},u)
        if op=='q': return s.query(b,u)
        return {'error':{'message':'op?'}}
    def row(s,tb,id_):
        return next((r for r in s.t[tb] if r.get('id')==id_),None)
    def query(s,b,u):
        tb=b['table']; rows=s.t.setdefault(tb,[]); m=b['method']
        def match(r):
            for f in b.get('filters',[]):
                if f[0]=='eq' and str(r.get(f[1]))!=str(f[2]): return False
                if f[0]=='or':
                    ok=False
                    for part in f[1].split(','):
                        c,o,v=part.split('.',2)
                        if str(r.get(c))==v: ok=True
                    if not ok: return False
                if f[0]=='in' and r.get(f[1]) not in f[2]: return False
            return True
        if m=='insert':
            vals=b['values'] if isinstance(b['values'],list) else [b['values']]
            for v in vals:
                v=dict(v); v.setdefault('id',str(uuid.uuid4())); rows.append(v)
            return {'data':vals}
        sel=[r for r in rows if match(r)]
        if m=='update':
            for r in sel:
                old=dict(r); r.update(b['values']); 
                if tb=='rides': s.ev('rides','UPDATE',dict(r),old)
            return {'data':sel}
        if m=='delete':
            for r in sel: rows.remove(r)
            return {'data':[]}
        if b.get('order'):
            k,asc=b['order']; sel.sort(key=lambda r:str(r.get(k) or ''),reverse=not asc)
        if b.get('limit'): sel=sel[:b['limit']]
        out={'data':None if b.get('head') else sel,'count':len(sel)}
        if b.get('single') and not b.get('head'):
            if not sel: out['data']=None; 
            else: out['data']=sel[0]
        return out
    def rpc(s,name,a,u):
        r=s._rpc(name,a,u); s.log.append((name,sorted(a.keys()),(r.get('error') or {}).get('message'))); return r
    def _rpc(s,name,a,u):
        if name in('sync_external_payment','push_ride_candidates'): return {'error':{'code':'42501','message':'permission denied for function '+name}}
        if not u and name!='get_test_mode': return {'error':{'message':'Usuário não autenticado'}}
        d=s.row('drivers',u)
        rid=next((v for k,v in a.items() if k.startswith('p_ride') or k=='p_id'),None)
        if name=='get_test_mode': return {'data':s.test_mode}
        if name=='is_admin': return {'data':False}
        if name=='get_my_app_context':
            p=s.row('profiles',u)
            return {'data':{'user_id':u,'role':(p or {}).get('role','passenger'),'is_admin':False,'has_driver_profile':bool(d),'driver_status':d and d['status'],'driver_document_status':d and d['document_status'],'driver_can_drive':bool(d and d['document_status']=='approved' and d['status'] in('available','busy'))}}
        if name in('test_prepare_my_driver','register_driver'):
            if name=='test_prepare_my_driver' and not s.test_mode: return {'error':{'message':'Laboratório de testes está desligado'}}
            if not d:
                d={'id':u,'status':'offline','document_status':'pending','full_name':a.get('p_full_name') or 'Motorista'}; s.t['drivers'].append(d)
            if s.test_mode: d['document_status']='approved'
            return {'data':d}
        if name=='set_driver_availability':
            if not d or d['document_status']!='approved': return {'error':{'message':'Motorista não aprovado'}}
            d['status']='available' if a.get('p_available') else 'offline'; return {'data':d}
        if name=='update_driver_location':
            d=d or None
            if d: d.update(lat=a.get('p_lat'),lng=a.get('p_lng'),location_updated_at=now()); s.t['driver_location_history'].append({'id':str(uuid.uuid4()),'driver_id':u})
            return {'data':True}
        if name=='create_ride_quote':
            if a['p_distance_km']<0: return {'error':{'message':'Distância inválida'}}
            r={'id':str(uuid.uuid4()),'passenger_id':u,'status':'requested','origin_lat':a['p_origin_lat'],'origin_lng':a['p_origin_lng'],'destination_name':a['p_destination_name'],'estimated_price':12.5,'payment_method':a.get('p_payment_method','pix'),'payment_status':'pending','test_run':s.test_mode,'created_at':now(),'driver_id':None}
            s.t['rides'].append(r); s.t['ride_push_queue'].append({'ride_id':r['id'],'attempts':0,'created_at':now()}); s.ev('rides','INSERT',dict(r)); return {'data':r}
        if name=='nearest_requested_rides':
            return {'data':[dict(r) for r in s.t['rides'] if r['status']=='requested']}
        r=s.row('rides',rid) if rid else None
        def upd(**k):
            old=dict(r); r.update(k); s.ev('rides','UPDATE',dict(r),old)
        if name=='accept_ride':
            if not r or r['status']!='requested': return {'error':{'message':'Corrida já aceita'}}
            if not d or d['status']!='available': return {'error':{'message':'Motorista indisponível'}}
            upd(status='accepted',driver_id=u,accepted_at=now()); d['status']='busy'; return {'data':r}
        if name=='update_ride_status':
            st=a['p_status']; extra={'arriving':'arrived_at','in_progress':'started_at'}.get(st)
            upd(status=st,**({extra:now()} if extra else {})); return {'data':r}
        if name=='complete_ride':
            upd(status='completed',completed_at=now(),final_price=r['estimated_price']); return {'data':r}  # NÃO libera o motorista (igual ao SQL real)
        if name=='confirm_cash_payment':
            upd(payment_status='paid'); return {'data':r}
        if name=='cancel_ride':
            upd(status='cancelled',cancelled_at=now()); return {'data':r}
        if name=='test_e2e_report':
            if not s.test_mode: return {'error':{'message':'Laboratório de testes está desligado'}}
            rr=next((x for x in reversed(s.t['rides']) if x['passenger_id']==u or x.get('driver_id')==u),None)
            if not rr: return {'data':{'has_ride':False}}
            q=s.row('ride_push_queue',None) or next((x for x in s.t['ride_push_queue'] if x['ride_id']==rr['id']),None)
            av=[x for x in s.t['drivers'] if x['status']=='available']
            fresh=[x for x in av if x.get('location_updated_at')]
            return {'data':{'has_ride':True,'ride':{k:rr.get(k) for k in['id','status','test_run','payment_method','payment_status','created_at','accepted_at','arrived_at','started_at','completed_at','cancelled_at']}|{'has_driver':bool(rr['driver_id'])},'dispatch':{'eligible_now':len(fresh) if rr['status']=='requested' else 0,'eligible_with_push_subscription':0,'available_nearby_any_gps_age':len(av),'available_total':len(av)},'push_queue':{'exists':bool(q),'attempts':q and q['attempts'],'max_attempts':8,'processed_at':None,'last_error':None,'created_at':q and q['created_at']}}}
        return {'error':{'code':'PGRST202','message':'Could not find the function public.'+name}}
