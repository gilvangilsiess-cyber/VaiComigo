import json, re, sys, time, subprocess, threading
sys.path.insert(0,'.')
from fake_backend import Backend
from playwright.sync_api import sync_playwright
import os; TEST_DIR=os.path.dirname(os.path.abspath(__file__)); PROJ=os.path.abspath(os.path.join(TEST_DIR,'..','..'))
srv=subprocess.Popen(['python3','-m','http.server','8765','--directory',PROJ],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
BASE='http://localhost:8765/'
STUB=open(os.path.join(TEST_DIR,'stub.js')).read()
FAKECFG="window.VAI_CONFIG={supabaseUrl:'https://fake.supabase.co',supabaseAnonKey:'"+'x'*10+"',vapidPublicKey:'BFAKEKEY',environment:'test'};"
be=Backend(); lock=threading.Lock(); out=[]
def log(*a): print(*a); out.append(' '.join(map(str,a)))
def setup(ctx,configured):
    errs=[]
    def sb(route):
        with lock: r=be.handle(json.loads(route.request.post_data or '{}'))
        route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    def ext(route):
        u=route.request.url
        if 'fake.supabase.co/auth/v1/health' in u: return route.fulfill(content_type='application/json',body='{}')
        if 'fake.supabase.co/auth/v1/settings' in u: return route.fulfill(content_type='application/json',body='{"disable_signup":false,"mailer_autoconfirm":true,"external":{"email":true}}')
        if 'fake.supabase.co/rest/v1/rpc' in u: return route.fulfill(status=401,content_type='application/json',body='{}')
        if u.startswith(BASE): return route.continue_()
        if 'supabase-js' in u and configured: return route.fulfill(content_type='application/javascript',body=STUB)
        if u.endswith('.css') or 'css' in u: return route.fulfill(content_type='text/css',body='')
        if 'leaflet' in u and configured: return route.fulfill(content_type='application/javascript',body='')
        return route.abort()
    ctx.route('**/*',ext)
    ctx.route('**/__sb',sb)
    if configured: ctx.route('**/js/config.js',lambda r:r.fulfill(content_type='application/javascript',body=FAKECFG))
    return errs
def newpage(br,configured,geo=None):
    ctx=br.new_context(permissions=['geolocation'] if geo else [],geolocation=geo,viewport={'width':390,'height':800},service_workers='block')
    errs=setup(ctx,configured); pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERROR '+str(e)))
    pg.on('console',lambda m:errs.append('CONSOLE '+m.text) if m.type=='error' else None)
    return ctx,pg,errs
with sync_playwright() as p:
    br=p.chromium.launch()
    # ---- A: sem credenciais
    ctx,pg,errs=newpage(br,False); dlg=[]
    pg.on('dialog',lambda d:(dlg.append(d.message),d.dismiss()))
    pg.goto(BASE); pg.wait_for_timeout(1500)
    txt=pg.inner_text('body')
    log('A1 sem credenciais: texto visível cita "Supabase"?', bool(re.search('supabase',txt,re.I)))
    pg.evaluate('ensureUser(true)'); pg.wait_for_timeout(300)
    log('A2 ação do usuário sem config -> alerta:',dlg)
    log('A3 erros JS:',[e for e in errs if 'PAGEERROR' in e] or 'nenhum pageerror')
    ctx.close()
    # ---- B: configurado, passageira
    geo={'latitude':-23.55,'longitude':-46.63}
    def signup(pg,email,name):
        pg.evaluate("openAuth('signup')"); pg.fill('#authEmail',email); pg.fill('#authPassword','123456'); pg.fill('#authName',name)
        pg.click('#authSubmit'); pg.wait_for_timeout(1200)
    cP,P,eP=newpage(br,True,geo); dP=[]; P.on('dialog',lambda d:(dP.append(d.message),d.accept('x')))
    P.goto(BASE); P.wait_for_timeout(1200)
    P.evaluate('ensureUser(true)'); P.wait_for_timeout(300)
    log('B1 sem sessão, ação do usuário abre login?', P.evaluate("document.getElementById('authModal').classList.contains('on')"), '| msg:',P.inner_text('#authMsg'))
    log('B2 signInAnonymously chamado?', P.evaluate('!!window.__anonCalled'))
    signup(P,'passageira@t.com','Passageira Teste')
    log('B3 currentUser após cadastro:', P.evaluate('!!window.currentUser'), '| perfil no backend:', len(be.t['profiles']))
    log('B4 geoloc na página do app:',P.evaluate("new Promise(r=>navigator.geolocation.getCurrentPosition(p=>r('ok'),e=>r('err '+e.code+' '+e.message),{timeout:4000}))"), '| perm:',P.evaluate("navigator.permissions.query({name:'geolocation'}).then(s=>s.state)"), '| geo é nativo?',P.evaluate('navigator.geolocation.getCurrentPosition.toString().slice(0,40)'))
    # ---- C: motorista
    cD,D,eD=newpage(br,True,geo); dD=[]; D.on('dialog',lambda d:(dD.append(d.message),d.accept('Motorista Teste')))
    D.goto(BASE); D.wait_for_timeout(1200); signup(D,'motorista@t.com','Motorista Teste')
    log('C1 register_driver via botão Cadastrar (prompts):'); D.evaluate('saveDriverProfile()'); D.wait_for_timeout(1500)
    log('   drivers no backend:',[(x['document_status'],x['status']) for x in be.t['drivers']],'| alertas:',dD[-1:])
    D.evaluate('driverMode()'); D.wait_for_timeout(800)
    D.evaluate('toggleDriver()')
    for i in range(6):
        cD.set_geolocation({'latitude':-23.55+0.0001*i,'longitude':-46.63}); D.wait_for_timeout(600)
    log('   update_driver_location chamado?', any(n=='update_driver_location' for n,k,e in be.log), '| args:',[k for n,k,e in be.log if n=='update_driver_location'][:1])
    log('   RPCs até aqui:',sorted(set((n,tuple(k),e) for n,k,e in be.log if n in('update_driver_location','set_driver_availability','nearest_requested_rides'))))
    log('C2 motorista após toggleDriver:',[(x['status'],bool(x.get('location_updated_at'))) for x in be.t['drivers']])
    # passageira solicita
    r=P.evaluate("supabaseClient.rpc('create_ride_quote',{p_origin_lat:-23.55,p_origin_lng:-46.63,p_destination_name:'Destino Teste',p_distance_km:5,p_duration_min:12,p_payment_method:'cash'}).then(x=>x.data)")
    rid=r['id']; log('C3 corrida criada:',rid[:8],r['status'],'test_run=',r['test_run'])
    for i in range(14):
        cD.set_geolocation({'latitude':-23.55+0.0002*i,'longitude':-46.63}); D.wait_for_timeout(600)
    log('C4 motorista viu oferta na tela?', 'Destino Teste' in D.inner_text('body'))
    log('   RPCs do backend:',sorted(set((n,e) for n,k,e in be.log)))
    log('   caixa do motorista:',D.evaluate("(document.getElementById('driverRideBox')||document.getElementById('calls')||document.body).innerText.slice(0,300)"))
    D.evaluate(f"acceptRealCall('{rid}')"); D.wait_for_timeout(1500)
    log('C5 após aceite:',[(x['status'],x['driver_id'] and x['driver_id'][:8]) for x in be.t['rides']])
    for st in ['arriving','in_progress']:
        D.evaluate(f"setRideStatus('{rid}','{st}')"); D.wait_for_timeout(800)
    D.evaluate(f"setRideStatus('{rid}','completed')"); D.wait_for_timeout(1500)
    log('C6 após finalizar: ride=',be.t['rides'][0]['status'],'| motorista no banco=',be.t['drivers'][0]['status'],'(esperado available pela correção)')
    log('   botão de dinheiro visível?',D.evaluate("!!document.getElementById('driverCashPayment')"));
    if D.evaluate("!!document.getElementById('driverCashPayment')"): D.evaluate("document.getElementById('driverCashPayment').click()"); D.wait_for_timeout(1000)
    log('C7 pagamento:',be.t['rides'][0]['payment_status'])
    # ---- D: diagnósticos
    for name,pg,role in [('PASSAGEIRA',P,'passenger'),('MOTORISTA',D,'driver')]:
        pg.evaluate(f"localStorage.setItem('vai_diag_role','{role}')")
        (cP if role=='passenger' else cD).set_geolocation({'latitude':-23.5501,'longitude':-46.6301}); pg.evaluate("VaiDiag.run()"); pg.wait_for_function("!document.querySelector('#vaiDiag') || true"); pg.wait_for_timeout(500)
        for _ in range(60):
            if pg.evaluate("Object.keys(VaiDiag.results).length")>=21: break
            pg.wait_for_timeout(500)
        pg.wait_for_timeout(1500)
        log('\n===== DIAGNÓSTICO',name,'====='); log(pg.evaluate('VaiDiag.report()'))
    log('\nErros JS passageira:',[e for e in eP if 'PAGEERROR' in e][:5],'| motorista:',[e for e in eD if 'PAGEERROR' in e][:5])
    br.close()
srv.terminate()
with open(os.path.join(TEST_DIR,'result.txt'),'w') as result:
    result.write('\n'.join(out))
