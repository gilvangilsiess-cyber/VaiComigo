(function(){
 const call=async(body)=>{const r=await fetch('/__sb',{method:'POST',body:JSON.stringify(Object.assign({token:localStorage.getItem('fk_tok')},body))});return r.json()};
 const q=(table)=>{const st={table,filters:[],method:'select'};
  const b={select(c,o){if(st.method==='select'||true){st.cols=c;if(o&&o.head)st.head=true}return b},
   insert(v){st.method='insert';st.values=v;return b},update(v){st.method='update';st.values=v;return b},upsert(v){st.method='insert';st.values=v;return b},delete(){st.method='delete';return b},
   eq(c,v){st.filters.push(['eq',c,v]);return b},or(x){st.filters.push(['or',x]);return b},in(c,v){st.filters.push(['in',c,v]);return b},
   gte(){return b},lte(){return b},neq(){return b},is(){return b},not(){return b},order(k,o){st.order=[k,!(o&&o.ascending===false)];return b},limit(n){st.limit=n;return b},
   maybeSingle(){st.single=true;return run()},single(){st.single=true;return run()},
   then(res,rej){return run().then(res,rej)}};
  function run(){return call({op:'q',...st,method:st.method}).then(r=>({data:r.data??null,error:r.error||null,count:r.count}))}
  return b};
 const listeners=[];let since=0;
 setInterval(async()=>{if(!listeners.length)return;const r=await call({op:'events',since});since=r.seq;for(const e of r.data)for(const l of listeners){if(l.table!==e.table)continue;if(l.event!=='*'&&l.event!==e.eventType)continue;if(l.filter){const m=l.filter.match(/^(\w+)=eq\.(.+)$/);if(m&&String(e.new[m[1]])!==m[2])continue}l.cb({eventType:e.eventType,new:e.new,old:e.old})}},300);
 const client={supabaseUrl:'https://fake.supabase.co',supabaseKey:'fake',
  auth:{async signUp({email,password,options}){const r=await call({op:'signup',email,meta:options&&options.data});if(r.data)localStorage.setItem('fk_tok',r.data.session.access_token);return r.error?{data:{},error:r.error}:{data:r.data,error:null}},
   async signInWithPassword({email}){const r=await call({op:'signin',email});if(r.data)localStorage.setItem('fk_tok',r.data.session.access_token);return r.error?{data:{},error:r.error}:{data:r.data,error:null}},
   async getSession(){const t=localStorage.getItem('fk_tok');if(!t)return{data:{session:null}};const r=await call({op:'getuser'});return r.data?{data:{session:{access_token:t,user:r.data.user}}}:{data:{session:null}}},
   async getUser(){const r=await call({op:'getuser'});return r.data?{data:r.data,error:null}:{data:{user:null},error:r.error}},
   async signOut(){localStorage.removeItem('fk_tok');return{error:null}},
   async signInAnonymously(){window.__anonCalled=true;return{data:{},error:{message:'Anonymous sign-ins are disabled'}}},
   onAuthStateChange(){return{data:{subscription:{unsubscribe(){}}}}}},
  from:q,rpc(name,args){return call({op:'rpc',name,args}).then(r=>({data:r.data??null,error:r.error||null}))},
  functions:{async invoke(name,o){const r=await call({op:'fn',name});const e=new Error('Edge Function returned a non-2xx status code');e.context={status:r.status,json:async()=>r.body};return{data:null,error:e}}},
  channel(){const ch={on(t,cfg,cb){listeners.push({table:cfg.table,event:cfg.event||'*',filter:cfg.filter,cb});return ch},subscribe(cb){setTimeout(()=>cb&&cb('SUBSCRIBED'),50);return ch},unsubscribe(){}};return ch},
  removeChannel(){},getChannels(){return[]}};
 window.supabase={createClient:()=>client};
 const P=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:P,apply:()=>P,construct:()=>P});window.L=P;
})();
