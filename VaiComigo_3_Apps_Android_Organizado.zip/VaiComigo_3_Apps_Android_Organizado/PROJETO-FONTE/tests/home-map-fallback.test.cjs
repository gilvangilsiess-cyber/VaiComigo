const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

test('GPS continua a preencher a partida se nenhuma biblioteca de mapa carregar', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
  const mapBoot = source.slice(source.indexOf('function setHomeMapState('), source.indexOf('function toggleLargeMap('));
  const position = source.slice(source.indexOf('function updatePosition('), source.indexOf('function failGPS('));
  assert.ok(mapBoot.includes('function initMap('));
  assert.ok(position.includes('function updatePosition('));

  const elements = new Map();
  const element = id => {
    if (!elements.has(id)) elements.set(id, { textContent: '', disabled: false, dataset: {}, setAttribute(name, value) { this[name] = value; } });
    return elements.get(id);
  };
  let onGpsPosition;
  let described;
  const window = {};
  const context = vm.createContext({
    window,
    document: {
      getElementById: element,
      querySelector: selector => element(selector),
    },
    navigator: { geolocation: { watchPosition: callback => { onGpsPosition = callback; return 1; } } },
    console,
    setTimeout: () => 1,
    map: null,
    me: null,
    accuracyCircle: null,
    watchId: null,
    lastGpsError: null,
    selectedPickup: null,
    failGPS: () => {},
    describePickup: point => { described = point; },
    updateDriverGuidance: () => {},
  });
  vm.runInContext(mapBoot + position, context);
  vm.runInContext('initMap()', context);
  assert.equal(element('#home .mapCard').dataset.mapState, 'error');
  assert.match(element('mapStatus').textContent, /busca por endereço continua disponível/i);
  assert.equal(typeof onGpsPosition, 'function');

  onGpsPosition({ coords: { latitude: -22.51, longitude: -43.18, accuracy: 20 } });
  assert.equal(element('gpsStatus').textContent, 'GPS ativo');
  assert.equal(element('accuracy').textContent, '± 20 m');
  assert.equal(window.vaiLatestGps.lat, -22.51);
  assert.equal(described.lng, -43.18);
});

test('falha do mapa vetorial troca automaticamente para o mapa básico', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
  const boot = source.slice(source.indexOf('function setHomeMapState('), source.indexOf('function toggleLargeMap('));
  const elements = new Map();
  const element = id => {
    if (!elements.has(id)) elements.set(id, { dataset: {}, textContent: '', disabled: false });
    return elements.get(id);
  };
  let recover;
  let restored = false;
  let removed = false;
  const vectorMap = { native: true, ready: false, pending: [], gl: { once() {}, remove() { removed = true; } } };
  const tiles = { on(name, cb) { if (name === 'tileload') this.loaded = cb; } };
  const basicMap = { setView() { return this; } };
  const L = { map() { return basicMap; }, DomEvent: { disableClickPropagation() {} } };
  const window = { maplibregl: { supported: () => true }, L, VaiMapEngine: { create: () => vectorMap, restoreLeaflet() { restored = true; } } };
  const context = vm.createContext({
    window, L, document: { querySelector: element, getElementById: element }, navigator: { geolocation: { watchPosition: () => 1 } },
    console, setTimeout(callback, ms) { if (ms === 10000) recover = callback; },
    map: null, me: null, accuracyCircle: null, pickupMarker: null, routeLine: null, watchId: null,
    petr: [-22.51, -43.18], addMapBase: () => tiles, updatePosition() {}, failGPS() {},
  });
  vm.runInContext(boot, context);
  vm.runInContext('initMap()', context);
  recover();
  assert.equal(restored, true);
  assert.equal(removed, true);
  assert.equal(window.map, basicMap);
  tiles.loaded();
  assert.equal(element('#home .mapCard').dataset.mapState, 'ready');
});

test('a estimativa e o botão de corrida funcionam sem o desenho do mapa', async () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
  const quoteFunction = source.slice(source.indexOf('async function calculateRouteQuote('), source.indexOf('async function notifyRideDriversPush('));
  const elements = new Map();
  const element = id => {
    if (!elements.has(id)) elements.set(id, {
      value: id === 'dest' ? 'Museu Imperial' : '', textContent: '', innerHTML: '',
      style: {}, dataset: {}, disabled: true,
      classList: { ready: false, add(name) { if (name === 'ready') this.ready = true; }, remove(name) { if (name === 'ready') this.ready = false; } },
      scrollIntoView() {},
    });
    return elements.get(id);
  };
  const document = { getElementById: element, querySelector: () => element('calculateButton') };
  let quoteGeneration = 0;
  let routeQuote = null;
  const context = vm.createContext({
    document, window: {}, console, map: null, routeLine: null,
    selectedPickup: { lat: -22.51, lng: -43.18 }, selectedDestination: null,
    quoteGeneration, routeQuote, lastGpsError: null,
    hidePlaceSuggestions() {},
    resetQuoteForPickup() { quoteGeneration++; context.quoteGeneration = quoteGeneration; context.routeQuote = null; },
    getPosition: async () => null,
    geocodeDestination: async () => ({ name: 'Museu Imperial', lat: -22.51, lng: -43.17 }),
    requestNavigationRoute: async () => ({ route: { distance: 1800, duration: 360, geometry: { type: 'LineString', coordinates: [[-43.18, -22.51], [-43.17, -22.51]] } }, traffic: null }),
    drawTrafficSegments() {},
    formatMoney: amount => `R$ ${amount}`,
    currentPaymentMethod: () => 'cash', paymentLabel: () => 'Dinheiro',
    escapeHtml: String,
  });
  vm.runInContext(quoteFunction, context);
  const result = await vm.runInContext('calculateRouteQuote()', context);
  assert.ok(result);
  assert.equal(result.distanceKm, 1.8);
  assert.equal(element('routeQuote').style.display, 'block');
  assert.equal(element('requestRideButton').classList.ready, true);
  assert.match(element('quotePickup').textContent, /Mapa indisponível/);
});
