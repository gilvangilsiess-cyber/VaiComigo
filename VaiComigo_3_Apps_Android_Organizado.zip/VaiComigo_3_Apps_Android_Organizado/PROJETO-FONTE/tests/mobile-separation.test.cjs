const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'../mobile');
const apps={passageiros:'passenger',motorista:'driver',administracao:'admin'};
test('três aplicativos têm IDs distintos, entrada fixa e cliente Supabase local',()=>{
 const ids=new Set();
 for(const [name,role] of Object.entries(apps)){
  const base=path.join(root,name);
  const cfg=JSON.parse(fs.readFileSync(path.join(base,'capacitor.config.json')));
  const html=fs.readFileSync(path.join(base,'www/index.html'),'utf8');
  const manifest=fs.readFileSync(path.join(base,'android/app/src/main/AndroidManifest.xml'),'utf8');
  ids.add(cfg.appId);
  assert.equal(cfg.webDir,'www');
  assert.match(html,new RegExp('window.VAI_FIXED_ROLE="'+role+'"'));
  assert.doesNotMatch(html,/id="entryGate"|cdn\.jsdelivr\.net\/npm\/@supabase/);
  assert.match(html,/src="js\/supabase\.bundle\.js"/);
  assert.ok(fs.statSync(path.join(base,'www/js/supabase.bundle.js')).size>10000);
  assert.match(manifest,/allowBackup="false"/);
 }
 assert.equal(ids.size,3);
});
