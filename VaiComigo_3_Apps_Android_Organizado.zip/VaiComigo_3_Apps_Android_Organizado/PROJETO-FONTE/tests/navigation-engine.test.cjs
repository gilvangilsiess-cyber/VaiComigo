const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');

function engine(callback){const window={};vm.runInNewContext(fs.readFileSync('js/navigation-engine.js','utf8'),{window,Date,Promise,Math});return window.VaiNavigation.create(callback)}
const route={distance:2500,duration:500,geometry:{coordinates:[[-43.18,-22.51],[-43.17,-22.51],[-43.16,-22.51]]},legs:[{steps:[{name:'Rua Principal',maneuver:{type:'depart',location:[-43.18,-22.51]}},{name:'Rua do Destino',maneuver:{type:'turn',modifier:'right',location:[-43.17,-22.51]}},{name:'',maneuver:{type:'arrive',location:[-43.16,-22.51]}}]}]};

test('orientação encontra a via, mostra manobra e distância restante',()=>{
 const nav=engine();nav.setRoute(route);
 const fix=nav.update({lat:-22.51008,lng:-43.179,accuracy:10});
 assert.equal(fix.state,'on-route');
 assert.match(fix.next,/direita/);
 assert.ok(fix.maneuverMeters>100);
 assert.ok(fix.remainingMeters>fix.maneuverMeters);
 assert.ok(fix.gapMeters<30);
});

test('GPS impreciso não recalcula; três amostras fora da rota recalculam uma vez',async()=>{
 let calls=0;const nav=engine(()=>{calls++});nav.setRoute(route);
 assert.equal(nav.update({lat:-22.52,lng:-43.18,accuracy:180}).state,'gps-imprecise');
 for(let i=0;i<3;i++)nav.update({lat:-22.52,lng:-43.18,accuracy:10});
 await Promise.resolve();
 assert.equal(calls,1);
});
