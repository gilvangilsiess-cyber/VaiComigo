const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');

test('rota com trânsito exige segredo no servidor e devolve geometria sem a credencial',async()=>{
 const script=fs.readFileSync('supabase/functions/navigation-route/index.ts','utf8');
 let handler,url;
 const Deno={env:{get:key=>key==='MAPBOX_ACCESS_TOKEN'?'test-only-secret':undefined},serve:callback=>{handler=callback}};
 const context={Deno,Response,URL,AbortController,setTimeout,clearTimeout,Object,Number,JSON,fetch:async target=>{
  url=String(target);
  return {ok:true,json:async()=>({routes:[{distance:1800,duration:500,geometry:{coordinates:[[-43.18,-22.51],[-43.17,-22.51]]},legs:[{steps:[],annotation:{congestion:['heavy']}}]}]})};
 }};
 vm.runInNewContext(script,context);
 const response=await handler({method:'POST',json:async()=>({origin:{lat:-22.51,lng:-43.18},target:{lat:-22.51,lng:-43.17}})});
 const result=await response.json();
 assert.equal(result.source,'mapbox');
 assert.equal(result.traffic.congestion[0],'heavy');
 assert.equal(result.route.distance,1800);
 assert.ok(url.includes('driving-traffic'));
 assert.ok(url.includes('access_token=test-only-secret'));
 assert.equal(JSON.stringify(result).includes('test-only-secret'),false);
 Deno.env.get=()=>undefined;
 const unavailable=await handler({method:'POST'});
 assert.equal(unavailable.status,503);
});
