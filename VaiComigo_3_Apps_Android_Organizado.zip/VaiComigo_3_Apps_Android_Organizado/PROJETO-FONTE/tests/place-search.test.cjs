const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
function node(){return {children:[],value:'',hidden:false,textContent:'',className:'',listeners:{},style:{},
 append(...x){this.children.push(...x)},replaceChildren(...x){this.children=x},
 setAttribute(){},addEventListener(event,fn){this.listeners[event]=fn},
 focus(){},blur(){},querySelector(){return null}}}
const ids=Object.fromEntries(['dest','originSearch','placeSuggestions','voiceSearchButton','savePlaceButton','msg'].map(id=>[id,node()]));
const document={getElementById:id=>ids[id],createElement:()=>node()};
const localStorage={getItem:()=>null,setItem(){}};
const window={VaiPlaces:{rank:()=>[]},VaiRecents:{list:()=>[],add(){}},localStorage,
 vaiLatestGps:{lat:-22.51,lng:-43.18},goTo(...args){this.chosen=args},resetQuoteForPickup(){}};
vm.runInNewContext(fs.readFileSync('js/place-search.js','utf8'),vm.createContext({window,document,localStorage,console,setTimeout,clearTimeout,prompt:()=>null}));
ids.dest.value='castelo';
window.VaiPlaceUI.show([{name:'Castelo de Itaipava',address:'BR-040, Itaipava, Petrópolis - RJ',category:'hotel',lat:-22.36,lng:-43.125}]);
const [item,footer]=ids.placeSuggestions.children;
assert.equal(item.className,'geoResult');
assert.match(item.children[0].textContent,/km/);
assert.equal(item.children[1].textContent,'🛏️');
assert.equal(item.children[2].children[0].textContent,'Castelo de Itaipava');
assert.match(item.children[2].children[1].textContent,/Petrópolis/);
assert.equal(footer.className,'geoFooter');
assert.equal(footer.children.length,3);
assert.match(footer.children[1].children[1].textContent,/castelo/);
item.listeners.click();
assert.equal(window.chosen[2],'Castelo de Itaipava');
assert.equal(window.chosen[3].category,'hotel');
console.log('Busca visual: distância, categoria, endereço e três ações fixas OK');
