const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');

test('máquina de estados respeita sequência e restaura o estado do servidor',()=>{
 const window={renderActiveRidePanel(){},renderDriverRideState(){},setRideStatus(){},activeDriverRide:null};
 vm.runInNewContext(fs.readFileSync('js/ride-state.js','utf8'),{window,document:{getElementById(){return null}}});
 const machine=window.VaiRideMachine;
 assert.equal(machine.canTransition('requested','accepted'),true);
 assert.equal(machine.canTransition('accepted','arriving'),true);
 assert.equal(machine.canTransition('arriving','in_progress'),true);
 assert.equal(machine.canTransition('in_progress','completed'),true);
 assert.equal(machine.canTransition('requested','completed'),false);
 assert.equal(machine.canTransition('completed','requested'),false);
 assert.equal(machine.observe({id:'a',status:'requested'}).changed,true);
 assert.equal(machine.observe({id:'a',status:'requested'}).changed,false);
 assert.equal(machine.observe({id:'a',status:'in_progress'}).step,3);
 assert.equal(machine.observe(null),null);
});
