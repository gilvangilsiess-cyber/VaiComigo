-- VaiComigo v12 — realtime passenger/driver backend
create extension if not exists cube;
create extension if not exists earthdistance;

create or replace function public.nearest_requested_rides(
  p_lat double precision, p_lng double precision, p_radius_km double precision default 10
)
returns table(
  id uuid, distance_km double precision, destination_name text, estimated_price numeric,
  origin_lat double precision, origin_lng double precision
)
language sql security definer set search_path=public as $$
  select r.id,
    earth_distance(ll_to_earth(r.origin_lat,r.origin_lng),ll_to_earth(p_lat,p_lng))/1000,
    r.destination_name,r.estimated_price,r.origin_lat,r.origin_lng
  from public.rides r
  where r.status='requested'
    and r.origin_lat is not null and r.origin_lng is not null
    and earth_distance(ll_to_earth(r.origin_lat,r.origin_lng),ll_to_earth(p_lat,p_lng)) <= p_radius_km*1000
  order by earth_distance(ll_to_earth(r.origin_lat,r.origin_lng),ll_to_earth(p_lat,p_lng))
  limit 10;
$$;
grant execute on function public.nearest_requested_rides(double precision,double precision,double precision) to authenticated;

-- Realtime: enable ride changes.
alter table public.rides replica identity full;

-- If your project has a publication, this adds rides to it.
do $$
begin
  alter publication supabase_realtime add table public.rides;
exception when duplicate_object then null;
end $$;
