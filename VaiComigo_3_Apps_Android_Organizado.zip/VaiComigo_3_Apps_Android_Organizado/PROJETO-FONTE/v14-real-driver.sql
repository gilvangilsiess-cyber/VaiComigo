-- VaiComigo v14: passageiro -> motorista real -> aceite -> rastreamento
alter table public.rides add column if not exists driver_id uuid references public.drivers(id);
alter table public.rides add column if not exists offered_at timestamptz;
alter table public.rides add column if not exists accepted_at timestamptz;

create index if not exists rides_driver_status_idx on public.rides(driver_id,status);

create or replace function public.accept_ride(p_ride_id uuid)
returns public.rides
language plpgsql security definer set search_path=public as $$
declare r public.rides;
begin
  update public.rides
     set status='accepted', accepted_at=now()
   where id=p_ride_id
     and driver_id=auth.uid()
     and status='offered'
  returning * into r;
  if r.id is null then
    raise exception 'Corrida não disponível para este motorista';
  end if;
  return r;
end $$;

alter table public.rides replica identity full;
do $$
begin
  alter publication supabase_realtime add table public.drivers;
exception when duplicate_object then null;
end $$;

grant execute on function public.accept_ride(uuid) to authenticated;
