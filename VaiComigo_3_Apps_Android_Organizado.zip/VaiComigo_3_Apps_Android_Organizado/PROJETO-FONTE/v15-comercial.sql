-- VaiComigo v15 — perfil, métodos de pagamento e tarifa
alter table public.profiles add column if not exists phone text;
alter table public.profiles add column if not exists payment_method text default 'pix';
alter table public.rides add column if not exists fare_estimate numeric(10,2);
alter table public.rides add column if not exists payment_method text default 'pix';

create index if not exists profiles_phone_idx on public.profiles(phone);

-- Exemplo de cálculo inicial; valores podem ser ajustados no painel/admin.
create or replace function public.estimate_ride_fare(
  p_distance_km numeric, p_duration_min numeric
) returns numeric
language sql immutable as $$
  select greatest(10.00, round((6.00 + p_distance_km*2.40 + p_duration_min*0.35)::numeric,2));
$$;
grant execute on function public.estimate_ride_fare(numeric,numeric) to authenticated;
