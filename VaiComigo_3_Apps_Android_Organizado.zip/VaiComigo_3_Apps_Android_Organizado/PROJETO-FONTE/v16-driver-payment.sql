-- VaiComigo v16 — perfil do motorista + preparação para pagamentos
alter table public.drivers add column if not exists full_name text;
alter table public.drivers add column if not exists phone text;
alter table public.drivers add column if not exists vehicle_model text;
alter table public.drivers add column if not exists vehicle_plate text;
alter table public.drivers add column if not exists document_status text default 'pending';

alter table public.rides add column if not exists payment_status text default 'pending';
alter table public.rides add column if not exists payment_provider text;
alter table public.rides add column if not exists payment_reference text;

create index if not exists rides_payment_status_idx on public.rides(payment_status);

-- O servidor/provedor de pagamentos deverá atualizar payment_status.
-- Nunca coloque uma chave secreta de pagamento no JavaScript do aplicativo.
