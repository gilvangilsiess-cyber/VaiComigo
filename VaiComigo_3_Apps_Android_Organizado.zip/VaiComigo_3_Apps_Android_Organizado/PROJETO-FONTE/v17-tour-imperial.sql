-- VaiComigo v17 — Tour Imperial com reserva
create table if not exists public.tour_bookings (
  id uuid primary key default gen_random_uuid(),
  passenger_id uuid not null references public.profiles(id),
  driver_id uuid references public.drivers(id),
  start_at timestamptz not null,
  duration_hours integer not null default 6,
  price numeric(10,2) not null default 280.00,
  status text not null default 'requested',
  pickup_lat double precision,
  pickup_lng double precision,
  notes text,
  created_at timestamptz not null default now()
);

create index if not exists tour_bookings_driver_status_idx
  on public.tour_bookings(driver_id,status);
create index if not exists tour_bookings_start_idx
  on public.tour_bookings(start_at);

alter table public.tour_bookings enable row level security;

create policy "tour passenger own rows"
on public.tour_bookings for all
to authenticated
using (passenger_id=auth.uid())
with check (passenger_id=auth.uid());

create policy "tour driver assigned rows"
on public.tour_bookings for select
to authenticated
using (driver_id=auth.uid());

alter table public.tour_bookings replica identity full;
do $$
begin
  alter publication supabase_realtime add table public.tour_bookings;
exception when duplicate_object then null;
end $$;
