alter table public.tour_bookings add column if not exists route_code text default 'imperial-6h';
alter table public.tour_bookings add column if not exists itinerary jsonb;
