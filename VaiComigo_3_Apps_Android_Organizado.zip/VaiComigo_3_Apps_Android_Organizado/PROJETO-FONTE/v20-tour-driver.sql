-- VaiComigo v20 — distribuição e aceite de Tours pelo motorista
-- Executar depois da v17/v18. Não cria uma nova tabela.

alter table public.tour_bookings replica identity full;

create index if not exists tour_bookings_status_start_idx
  on public.tour_bookings(status,start_at);

create or replace function public.nearest_requested_tours(
  p_lat double precision,
  p_lng double precision,
  p_radius_km double precision default 15
)
returns table(
  id uuid,
  distance_km double precision,
  start_at timestamptz,
  duration_hours integer,
  price numeric,
  pickup_lat double precision,
  pickup_lng double precision,
  route_code text
)
language sql
security definer
set search_path=public
as $$
  select
    t.id,
    earth_distance(ll_to_earth(t.pickup_lat,t.pickup_lng),ll_to_earth(p_lat,p_lng))/1000,
    t.start_at,t.duration_hours,t.price,t.pickup_lat,t.pickup_lng,t.route_code
  from public.tour_bookings t
  where t.status='requested'
    and t.driver_id is null
    and t.pickup_lat is not null
    and t.pickup_lng is not null
    and t.start_at > now()
    and earth_distance(ll_to_earth(t.pickup_lat,t.pickup_lng),ll_to_earth(p_lat,p_lng)) <= p_radius_km*1000
  order by t.start_at asc, earth_distance(ll_to_earth(t.pickup_lat,t.pickup_lng),ll_to_earth(p_lat,p_lng)) asc
  limit 10;
$$;

grant execute on function public.nearest_requested_tours(double precision,double precision,double precision) to authenticated;

create or replace function public.accept_tour(p_tour_id uuid)
returns public.tour_bookings
language plpgsql
security definer
set search_path=public
as $$
declare
  t public.tour_bookings;
begin
  if not exists (
    select 1 from public.drivers d
    where d.id=auth.uid() and d.status='available'
  ) then
    raise exception 'Motorista não está disponível';
  end if;

  update public.tour_bookings
     set driver_id=auth.uid(), status='accepted'
   where id=p_tour_id
     and status='requested'
     and driver_id is null
     and start_at > now()
  returning * into t;

  if t.id is null then
    raise exception 'Este Tour já foi aceito ou não está mais disponível';
  end if;

  return t;
end;
$$;

grant execute on function public.accept_tour(uuid) to authenticated;
