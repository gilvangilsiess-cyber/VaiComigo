-- VaiComigo v21 — fluxo real de corrida comum
-- requested -> accepted -> arriving -> in_progress -> completed
-- A tela do motorista trata a chamada disponível como uma oferta.
-- Não usamos status='offered' para evitar corrida presa nesse estado.

alter table public.rides add column if not exists accepted_at timestamptz;
alter table public.rides add column if not exists arrived_at timestamptz;
alter table public.rides add column if not exists started_at timestamptz;
alter table public.rides add column if not exists completed_at timestamptz;
alter table public.rides add column if not exists cancelled_at timestamptz;

create index if not exists rides_status_origin_idx
  on public.rides(status, origin_lat, origin_lng);

create or replace function public.nearest_requested_rides(
  p_lat double precision,
  p_lng double precision,
  p_radius_km double precision default 10
)
returns table(
  id uuid,
  distance_km double precision,
  destination_name text,
  estimated_price numeric,
  origin_lat double precision,
  origin_lng double precision
)
language sql
security definer
set search_path=public
as $$
  select
    r.id,
    earth_distance(ll_to_earth(r.origin_lat,r.origin_lng),ll_to_earth(p_lat,p_lng))/1000,
    r.destination_name,
    r.estimated_price,
    r.origin_lat,
    r.origin_lng
  from public.rides r
  where r.status='requested'
    and r.driver_id is null
    and r.origin_lat is not null
    and r.origin_lng is not null
    and earth_distance(ll_to_earth(r.origin_lat,r.origin_lng),ll_to_earth(p_lat,p_lng)) <= p_radius_km*1000
  order by earth_distance(ll_to_earth(r.origin_lat,r.origin_lng),ll_to_earth(p_lat,p_lng))
  limit 10;
$$;

grant execute on function public.nearest_requested_rides(double precision,double precision,double precision) to authenticated;

-- Aceite atômico: apenas um motorista consegue assumir a corrida.
-- Aceita tanto instalações antigas que ainda criaram 'offered' quanto o fluxo atual 'requested'.
create or replace function public.accept_ride(p_ride_id uuid)
returns public.rides
language plpgsql
security definer
set search_path=public
as $$
declare
  r public.rides;
begin
  if not exists (
    select 1 from public.drivers d
    where d.id=auth.uid()
      and d.status='available'
  ) then
    raise exception 'Motorista não está disponível';
  end if;

  update public.rides
     set driver_id=auth.uid(),
         status='accepted',
         accepted_at=coalesce(accepted_at,now())
   where id=p_ride_id
     and driver_id is null
     and status in ('requested','offered')
  returning * into r;

  if r.id is null then
    raise exception 'Corrida já foi aceita ou não está mais disponível';
  end if;

  return r;
end;
$$;

grant execute on function public.accept_ride(uuid) to authenticated;

-- Atualização controlada do ciclo da corrida.
create or replace function public.update_ride_status(
  p_ride_id uuid,
  p_status text
)
returns public.rides
language plpgsql
security definer
set search_path=public
as $$
declare
  r public.rides;
begin
  if p_status not in ('arriving','in_progress','completed','cancelled') then
    raise exception 'Status inválido';
  end if;

  update public.rides
     set status=p_status,
         arrived_at=case when p_status='arriving' then coalesce(arrived_at,now()) else arrived_at end,
         started_at=case when p_status='in_progress' then coalesce(started_at,now()) else started_at end,
         completed_at=case when p_status='completed' then coalesce(completed_at,now()) else completed_at end,
         cancelled_at=case when p_status='cancelled' then coalesce(cancelled_at,now()) else cancelled_at end
   where id=p_ride_id
     and driver_id=auth.uid()
     and (
       (status='accepted' and p_status in ('arriving','cancelled')) or
       (status='arriving' and p_status in ('in_progress','cancelled')) or
       (status='in_progress' and p_status in ('completed','cancelled'))
     )
  returning * into r;

  if r.id is null then
    raise exception 'Transição de corrida inválida';
  end if;

  return r;
end;
$$;

grant execute on function public.update_ride_status(uuid,text) to authenticated;

alter table public.rides replica identity full;
do $$
begin
  alter publication supabase_realtime add table public.rides;
exception when duplicate_object then null;
end $$;
