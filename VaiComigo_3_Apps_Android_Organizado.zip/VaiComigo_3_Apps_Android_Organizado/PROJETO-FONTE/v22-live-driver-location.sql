-- VaiComigo V22 — localização real do motorista em tempo real
-- O motorista publica sua posição em public.drivers.
-- O passageiro acompanha a posição através do Supabase Realtime.

alter table public.drivers add column if not exists location_accuracy double precision;
alter table public.drivers add column if not exists heading double precision;
alter table public.drivers add column if not exists speed double precision;
alter table public.drivers add column if not exists location_updated_at timestamptz;

create index if not exists drivers_location_idx on public.drivers(status, updated_at);

create or replace function public.update_driver_location(
  p_lat double precision,
  p_lng double precision,
  p_accuracy double precision default null,
  p_heading double precision default null,
  p_speed double precision default null
)
returns public.drivers
language plpgsql
security definer
set search_path=public
as $$
declare d public.drivers;
begin
  if auth.uid() is null then raise exception 'Usuário não autenticado'; end if;
  if p_lat is null or p_lng is null then raise exception 'Localização inválida'; end if;
  if p_lat < -90 or p_lat > 90 or p_lng < -180 or p_lng > 180 then raise exception 'Coordenadas inválidas'; end if;

  insert into public.drivers(id,status,lat,lng,updated_at,location_accuracy,heading,speed,location_updated_at)
  values(auth.uid(),'available',p_lat,p_lng,now(),p_accuracy,p_heading,p_speed,now())
  on conflict (id) do update set
    lat=excluded.lat,
    lng=excluded.lng,
    updated_at=now(),
    location_accuracy=excluded.location_accuracy,
    heading=excluded.heading,
    speed=excluded.speed,
    location_updated_at=now();

  select * into d from public.drivers where id=auth.uid();
  return d;
end;
$$;

grant execute on function public.update_driver_location(double precision,double precision,double precision,double precision,double precision) to authenticated;

alter table public.drivers replica identity full;
do $$
begin
  alter publication supabase_realtime add table public.drivers;
exception when duplicate_object then null;
end $$;
