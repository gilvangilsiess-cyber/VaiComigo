-- VaiComigo V23 — base para navegação do motorista
-- Não cria novas tabelas. A navegação usa origin_lat/origin_lng da corrida aceita.
-- O frontend usa OSRM para calcular a rota e Google Maps como opção de navegação externa.

-- Índice para recuperar rapidamente corridas aceitas pelo motorista.
create index if not exists rides_driver_status_idx
  on public.rides(driver_id, status, accepted_at);

-- Garante que o Realtime continue disponível para alterações de rota/status da corrida.
alter table public.rides replica identity full;
do $$
begin
  alter publication supabase_realtime add table public.rides;
exception when duplicate_object then null;
end $$;
