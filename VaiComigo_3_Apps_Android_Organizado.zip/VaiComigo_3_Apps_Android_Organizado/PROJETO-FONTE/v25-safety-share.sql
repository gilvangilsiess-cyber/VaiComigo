-- VaiComigo V25 — Segurança, SOS e compartilhamento de viagem
-- Cria somente a camada de segurança. Não altera o fluxo de corrida existente.

create extension if not exists pgcrypto;

create table if not exists public.sos_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  ride_id uuid null references public.rides(id) on delete set null,
  lat double precision not null,
  lng double precision not null,
  message text,
  status text not null default 'open' check (status in ('open','acknowledged','closed')),
  created_at timestamptz not null default now()
);

create table if not exists public.trip_shares (
  id uuid primary key default gen_random_uuid(),
  ride_id uuid not null references public.rides(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  token text not null unique default encode(gen_random_bytes(24),'hex'),
  expires_at timestamptz not null default (now() + interval '12 hours'),
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists sos_events_ride_idx on public.sos_events(ride_id, created_at desc);
create index if not exists trip_shares_ride_idx on public.trip_shares(ride_id, created_at desc);
create index if not exists trip_shares_token_idx on public.trip_shares(token);

alter table public.sos_events enable row level security;
alter table public.trip_shares enable row level security;

-- O app usa RPCs security-definer para não expor leitura pública dessas tabelas.
drop policy if exists sos_events_owner_select on public.sos_events;
drop policy if exists trip_shares_owner_select on public.trip_shares;
create policy sos_events_owner_select on public.sos_events for select to authenticated using (user_id = auth.uid());
create policy trip_shares_owner_select on public.trip_shares for select to authenticated using (owner_id = auth.uid());

create or replace function public.create_sos_event(
  p_ride_id uuid default null,
  p_lat double precision default null,
  p_lng double precision default null,
  p_message text default null
)
returns public.sos_events
language plpgsql
security definer
set search_path=public
as $$
declare e public.sos_events;
begin
  if auth.uid() is null then raise exception 'Usuário não autenticado'; end if;
  if p_lat is null or p_lng is null or p_lat < -90 or p_lat > 90 or p_lng < -180 or p_lng > 180 then raise exception 'Localização inválida'; end if;
  if p_ride_id is not null and not exists(select 1 from public.rides where id=p_ride_id and passenger_id=auth.uid()) then raise exception 'Corrida não pertence ao usuário'; end if;
  insert into public.sos_events(user_id,ride_id,lat,lng,message) values(auth.uid(),p_ride_id,p_lat,p_lng,left(coalesce(p_message,''),500)) returning * into e;
  return e;
end;
$$;
grant execute on function public.create_sos_event(uuid,double precision,double precision,text) to authenticated;

create or replace function public.create_trip_share(p_ride_id uuid)
returns table(token text, expires_at timestamptz)
language plpgsql
security definer
set search_path=public
as $$
declare s public.trip_shares;
begin
  if auth.uid() is null then raise exception 'Usuário não autenticado'; end if;
  if not exists(select 1 from public.rides where id=p_ride_id and passenger_id=auth.uid()) then raise exception 'Corrida não pertence ao usuário'; end if;
  insert into public.trip_shares(ride_id,owner_id) values(p_ride_id,auth.uid()) returning * into s;
  return query select s.token,s.expires_at;
end;
$$;
grant execute on function public.create_trip_share(uuid) to authenticated;

create or replace function public.get_shared_trip(p_token text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare result jsonb;
begin
  select jsonb_build_object(
    'status',r.status,
    'destination_name',r.destination_name,
    'updated_at',coalesce(d.location_updated_at,r.updated_at),
    'lat',case when r.driver_id is not null then d.lat else r.origin_lat end,
    'lng',case when r.driver_id is not null then d.lng else r.origin_lng end,
    'driver_id',case when r.driver_id is not null then r.driver_id else null end
  ) into result
  from public.trip_shares s
  join public.rides r on r.id=s.ride_id
  left join public.drivers d on d.id=r.driver_id
  where s.token=p_token
    and s.revoked_at is null
    and s.expires_at > now();
  if result is null then raise exception 'Link inválido ou expirado'; end if;
  return result;
end;
$$;
grant execute on function public.get_shared_trip(text) to anon, authenticated;

-- Nunca retorna nome, telefone, e-mail ou outros dados pessoais do passageiro/motorista.
