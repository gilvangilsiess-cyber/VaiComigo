-- VaiComigo V26 — Histórico e recibo de corridas
-- Adiciona apenas campos necessários para registrar o valor final e melhora os índices.

alter table public.rides add column if not exists final_price numeric(10,2);

create index if not exists rides_passenger_created_idx
  on public.rides(passenger_id, created_at desc);

-- Reforça que o passageiro autenticado só consulte suas próprias corridas.
alter table public.rides enable row level security;
drop policy if exists rides_passenger_select on public.rides;
create policy rides_passenger_select on public.rides
  for select to authenticated
  using (passenger_id = auth.uid());

-- O motorista também pode consultar as corridas que lhe foram atribuídas.
drop policy if exists rides_driver_select on public.rides;
create policy rides_driver_select on public.rides
  for select to authenticated
  using (driver_id = auth.uid());

-- Permite ao motorista registrar o valor final sem expor update amplo ao passageiro.
create or replace function public.complete_ride(
  p_ride_id uuid,
  p_final_price numeric default null
)
returns public.rides
language plpgsql
security definer
set search_path=public
as $$
declare r public.rides;
begin
  if auth.uid() is null then raise exception 'Usuário não autenticado'; end if;
  if p_final_price is not null and p_final_price < 0 then raise exception 'Valor inválido'; end if;

  update public.rides
     set status='completed',
         completed_at=coalesce(completed_at,now()),
         final_price=coalesce(p_final_price,final_price,estimated_price,fare_estimate)
   where id=p_ride_id
     and driver_id=auth.uid()
     and status='in_progress'
   returning * into r;

  if r.id is null then raise exception 'Corrida não está em andamento ou não pertence ao motorista'; end if;
  return r;
end;
$$;

grant execute on function public.complete_ride(uuid,numeric) to authenticated;

alter table public.rides replica identity full;
