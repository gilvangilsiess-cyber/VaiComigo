-- VaiComigo V27 — preparação financeira e ciclo de pagamento
-- Esta migração NÃO processa Pix/cartão sozinha. Ela cria o registro seguro da cobrança
-- para futura integração com um provedor. Dinheiro pode ser confirmado pelo motorista.

alter table public.rides add column if not exists payment_status text default 'pending';
alter table public.rides add column if not exists payment_provider text;
alter table public.rides add column if not exists payment_reference text;
alter table public.rides add column if not exists payment_paid_at timestamptz;

create table if not exists public.payment_transactions (
  id uuid primary key default gen_random_uuid(),
  ride_id uuid not null references public.rides(id) on delete cascade,
  passenger_id uuid not null references auth.users(id),
  driver_id uuid references auth.users(id),
  amount numeric(10,2) not null check (amount >= 0),
  method text not null check (method in ('pix','card','cash')),
  status text not null default 'pending' check (status in ('pending','authorized','paid','failed','cancelled')),
  provider text,
  provider_reference text,
  created_at timestamptz not null default now(),
  paid_at timestamptz
);

create unique index if not exists payment_transactions_ride_unique
  on public.payment_transactions(ride_id);
create index if not exists payment_transactions_passenger_idx
  on public.payment_transactions(passenger_id, created_at desc);
create index if not exists payment_transactions_driver_idx
  on public.payment_transactions(driver_id, created_at desc);

alter table public.payment_transactions enable row level security;
drop policy if exists payment_tx_passenger_select on public.payment_transactions;
create policy payment_tx_passenger_select on public.payment_transactions
for select to authenticated using (passenger_id = auth.uid());
drop policy if exists payment_tx_driver_select on public.payment_transactions;
create policy payment_tx_driver_select on public.payment_transactions
for select to authenticated using (driver_id = auth.uid());

create or replace function public.create_payment_intent(p_ride_id uuid)
returns public.payment_transactions
language plpgsql security definer set search_path=public
as $$
declare
  r public.rides;
  tx public.payment_transactions;
begin
  select * into r from public.rides where id=p_ride_id and passenger_id=auth.uid();
  if r.id is null then raise exception 'Corrida não encontrada'; end if;
  if r.status <> 'completed' then raise exception 'A corrida ainda não foi finalizada'; end if;
  if coalesce(r.final_price,r.estimated_price,r.fare_estimate,0) < 0 then raise exception 'Valor inválido'; end if;

  insert into public.payment_transactions(ride_id,passenger_id,driver_id,amount,method,status,provider)
  values(r.id,r.passenger_id,r.driver_id,coalesce(r.final_price,r.estimated_price,r.fare_estimate,0),coalesce(r.payment_method,'pix'),'pending',null)
  on conflict (ride_id) do update set
    amount=excluded.amount,
    method=excluded.method,
    driver_id=excluded.driver_id
  returning * into tx;

  update public.rides
  set payment_status='pending', payment_reference=tx.id::text
  where id=r.id;
  return tx;
end;
$$;
grant execute on function public.create_payment_intent(uuid) to authenticated;

create or replace function public.confirm_cash_payment(p_ride_id uuid)
returns public.payment_transactions
language plpgsql security definer set search_path=public
as $$
declare tx public.payment_transactions;
 r public.rides;
begin
 select * into r from public.rides where id=p_ride_id and driver_id=auth.uid();
 if r.id is null then raise exception 'Corrida não encontrada para este motorista'; end if;
 if r.status <> 'completed' then raise exception 'A corrida precisa estar finalizada'; end if;
 if coalesce(r.payment_method,'pix') <> 'cash' then raise exception 'Esta corrida não está configurada para dinheiro'; end if;

 insert into public.payment_transactions(ride_id,passenger_id,driver_id,amount,method,status,provider,paid_at)
 values(r.id,r.passenger_id,r.driver_id,coalesce(r.final_price,r.estimated_price,r.fare_estimate,0),'cash','paid','manual_cash',now())
 on conflict (ride_id) do update set status='paid',provider='manual_cash',paid_at=now()
 returning * into tx;

 update public.rides set payment_status='paid',payment_provider='manual_cash',payment_reference=tx.id::text,payment_paid_at=now() where id=r.id;
 return tx;
end;
$$;
grant execute on function public.confirm_cash_payment(uuid) to authenticated;

alter table public.rides replica identity full;
alter table public.payment_transactions replica identity full;
do $$ begin alter publication supabase_realtime add table public.payment_transactions; exception when duplicate_object then null; end $$;
