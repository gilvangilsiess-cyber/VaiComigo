-- VaiComigo V28 — painel financeiro do motorista e comissão da plataforma
-- Esta etapa NÃO movimenta dinheiro e NÃO faz repasse bancário.
-- O financeiro é calculado a partir das corridas concluídas e fica pronto para futura integração PJ/gateway.

create table if not exists public.platform_settings (
  id boolean primary key default true check (id=true),
  commission_percent numeric(5,2) not null default 20.00 check (commission_percent >= 0 and commission_percent <= 100),
  updated_at timestamptz not null default now()
);

insert into public.platform_settings(id,commission_percent)
values(true,20.00)
on conflict (id) do nothing;

alter table public.platform_settings enable row level security;
drop policy if exists platform_settings_authenticated_select on public.platform_settings;
create policy platform_settings_authenticated_select on public.platform_settings
for select to authenticated using (true);

create or replace function public.get_driver_financial_summary()
returns table(
  gross_completed numeric,
  platform_commission numeric,
  driver_earnings numeric,
  paid_to_driver numeric,
  commission_percent numeric,
  completed_rides bigint
)
language sql security definer set search_path=public
as $$
  with cfg as (
    select commission_percent from public.platform_settings where id=true
  ),
  r as (
    select
      coalesce(sum(coalesce(ri.final_price,ri.estimated_price,ri.fare_estimate,0)),0)::numeric as gross,
      count(*)::bigint as total
    from public.rides ri
    where ri.driver_id=auth.uid() and ri.status='completed'
  ),
  paid as (
    select coalesce(sum(pt.amount * (1 - cfg.commission_percent / 100.0)),0)::numeric as amount
    from public.payment_transactions pt
    cross join cfg
    where pt.driver_id=auth.uid() and pt.status='paid'
  )
  select
    r.gross,
    round((r.gross * cfg.commission_percent / 100.0)::numeric,2),
    round((r.gross * (1 - cfg.commission_percent / 100.0))::numeric,2),
    paid.amount,
    cfg.commission_percent,
    r.total
  from r cross join cfg cross join paid;
$$;
grant execute on function public.get_driver_financial_summary() to authenticated;

create or replace function public.get_driver_earnings(p_limit integer default 20)
returns table(
  ride_id uuid,
  completed_at timestamptz,
  destination_name text,
  gross_amount numeric,
  platform_commission numeric,
  driver_earnings numeric,
  payment_status text
)
language sql security definer set search_path=public
as $$
  select
    r.id,
    r.completed_at,
    r.destination_name,
    coalesce(r.final_price,r.estimated_price,r.fare_estimate,0)::numeric,
    round((coalesce(r.final_price,r.estimated_price,r.fare_estimate,0) * s.commission_percent / 100.0)::numeric,2),
    round((coalesce(r.final_price,r.estimated_price,r.fare_estimate,0) * (1 - s.commission_percent / 100.0))::numeric,2),
    coalesce(r.payment_status,'pending')
  from public.rides r
  cross join public.platform_settings s
  where r.driver_id=auth.uid() and r.status='completed'
  order by r.completed_at desc nulls last
  limit greatest(1,least(coalesce(p_limit,20),100));
$$;
grant execute on function public.get_driver_earnings(integer) to authenticated;

-- Realtime não é necessário para os cálculos, pois eles são derivados das corridas.
-- Nenhuma chave bancária, Pix ou credencial privada é armazenada nesta etapa.
