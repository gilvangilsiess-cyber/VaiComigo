-- VaiComigo V29 — Painel administrativo protegido
-- O painel não expõe consultas administrativas diretamente ao frontend.
-- O acesso ocorre por funções SECURITY DEFINER que validam profiles.role='admin'.

alter table public.profiles add column if not exists role text not null default 'passenger';
create index if not exists profiles_role_idx on public.profiles(role);

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id=auth.uid() and p.role='admin'
  );
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

create or replace function public.admin_dashboard()
returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  result jsonb;
  cfg numeric;
begin
  if not public.is_admin() then
    raise exception 'Acesso administrativo negado';
  end if;

  select commission_percent into cfg from public.platform_settings where id=true;

  select jsonb_build_object(
    'completed_rides', (select count(*) from public.rides where status='completed'),
    'active_rides', (select count(*) from public.rides where status in ('requested','accepted','arriving','in_progress','offered')),
    'requested_tours', (select count(*) from public.tour_bookings where status='requested'),
    'available_drivers', (select count(*) from public.drivers where status='available'),
    'users', (select count(*) from public.profiles),
    'gross_completed', (select coalesce(sum(coalesce(final_price,estimated_price,fare_estimate,0)),0) from public.rides where status='completed'),
    'commission_percent', coalesce(cfg,20),
    'drivers', coalesce((select jsonb_agg(to_jsonb(x) order by x.updated_at desc nulls last) from (
      select id,full_name,status,vehicle_model,vehicle_plate,updated_at
      from public.drivers order by updated_at desc nulls last limit 20
    ) x),'[]'::jsonb),
    'rides', coalesce((select jsonb_agg(to_jsonb(x) order by x.created_at desc) from (
      select id,created_at,status,destination_name,coalesce(final_price,estimated_price,fare_estimate,0)::numeric as amount
      from public.rides order by created_at desc limit 30
    ) x),'[]'::jsonb),
    'tours', coalesce((select jsonb_agg(to_jsonb(x) order by x.start_at desc) from (
      select id,start_at,status,duration_hours,price
      from public.tour_bookings order by start_at desc limit 20
    ) x),'[]'::jsonb)
  ) into result;

  return result;
end;
$$;
revoke all on function public.admin_dashboard() from public;
grant execute on function public.admin_dashboard() to authenticated;

create or replace function public.admin_set_commission(p_percent numeric)
returns numeric
language plpgsql
security definer
set search_path=public
as $$
declare v numeric;
begin
  if not public.is_admin() then
    raise exception 'Acesso administrativo negado';
  end if;
  v := round(p_percent::numeric,2);
  if v < 0 or v > 100 then
    raise exception 'Comissão deve estar entre 0 e 100';
  end if;
  update public.platform_settings
     set commission_percent=v, updated_at=now()
   where id=true;
  return v;
end;
$$;
revoke all on function public.admin_set_commission(numeric) from public;
grant execute on function public.admin_set_commission(numeric) to authenticated;

-- Crie o primeiro administrador manualmente, pelo SQL Editor, substituindo o UUID:
-- update public.profiles set role='admin' where id='SEU-UUID-AQUI';
-- Depois disso, a conta poderá abrir o painel administrativo.
