-- VaiComigo v30 — disponibilidade segura do motorista + aprovação administrativa
-- Depende de v14/v16/v22-v29.

create or replace function public.set_driver_availability(p_available boolean)
returns public.drivers
language plpgsql
security definer
set search_path=public
as $$
declare d public.drivers;
begin
  if auth.uid() is null then raise exception 'Usuário não autenticado'; end if;

  if p_available then
    update public.drivers
       set status='available', updated_at=now()
     where id=auth.uid()
       and coalesce(document_status,'pending')='approved'
     returning * into d;

    if d.id is null then
      if exists(select 1 from public.drivers where id=auth.uid()) then
        raise exception 'Motorista ainda não foi aprovado pelo administrador';
      end if;
      raise exception 'Cadastro de motorista não encontrado';
    end if;
  else
    update public.drivers
       set status='offline', updated_at=now()
     where id=auth.uid()
     returning * into d;

    if d.id is null then
      raise exception 'Cadastro de motorista não encontrado';
    end if;
  end if;

  return d;
end;
$$;

revoke all on function public.set_driver_availability(boolean) from public;
grant execute on function public.set_driver_availability(boolean) to authenticated;

create or replace function public.admin_set_driver_document_status(
  p_driver_id uuid,
  p_status text
)
returns public.drivers
language plpgsql
security definer
set search_path=public
as $$
declare d public.drivers;
begin
  if not public.is_admin() then
    raise exception 'Acesso administrativo negado';
  end if;

  if p_status not in ('pending','approved','rejected') then
    raise exception 'Status de documento inválido';
  end if;

  update public.drivers
     set document_status=p_status,
         status=case when p_status <> 'approved' then 'offline' else status end,
         updated_at=now()
   where id=p_driver_id
   returning * into d;

  if d.id is null then raise exception 'Motorista não encontrado'; end if;
  return d;
end;
$$;

revoke all on function public.admin_set_driver_document_status(uuid,text) from public;
grant execute on function public.admin_set_driver_document_status(uuid,text) to authenticated;

-- Atualiza o dashboard para expor o estado documental somente ao administrador.
create or replace function public.admin_dashboard()
returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  result jsonb;
  cfg numeric;
begin
  if not public.is_admin() then
    raise exception 'Acesso administrativo negado';
  end if;

  select commission_percent into cfg from public.platform_settings where id=true;

  select jsonb_build_object(
    'completed_rides', (select count(*) from public.rides where status='completed'),
    'active_rides', (select count(*) from public.rides where status in ('requested','accepted','arriving','in_progress','offered')),
    'requested_tours', (select count(*) from public.tour_bookings where status='requested'),
    'available_drivers', (select count(*) from public.drivers where status='available'),
    'users', (select count(*) from public.profiles),
    'gross_completed', (select coalesce(sum(coalesce(final_price,estimated_price,fare_estimate,0)),0) from public.rides where status='completed'),
    'commission_percent', coalesce(cfg,20),
    'drivers', coalesce((select jsonb_agg(to_jsonb(x) order by x.updated_at desc nulls last) from (
      select id,full_name,status,vehicle_model,vehicle_plate,document_status,updated_at
      from public.drivers order by updated_at desc nulls last limit 20
    ) x),'[]'::jsonb),
    'rides', coalesce((select jsonb_agg(to_jsonb(x) order by x.created_at desc) from (
      select id,created_at,status,destination_name,coalesce(final_price,estimated_price,fare_estimate,0)::numeric as amount
      from public.rides order by created_at desc limit 30
    ) x),'[]'::jsonb),
    'tours', coalesce((select jsonb_agg(to_jsonb(x) order by x.start_at desc) from (
      select id,start_at,status,duration_hours,price
      from public.tour_bookings order by start_at desc limit 20
    ) x),'[]'::jsonb)
  ) into result;

  return result;
end;
$$;
revoke all on function public.admin_dashboard() from public;
grant execute on function public.admin_dashboard() to authenticated;
