-- VaiComigo v31 — avaliação pós-corrida
create table if not exists public.ride_ratings (
  id uuid primary key default gen_random_uuid(),
  ride_id uuid not null unique references public.rides(id) on delete cascade,
  passenger_id uuid not null references auth.users(id) on delete cascade,
  driver_id uuid references auth.users(id) on delete set null,
  rating smallint not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);

create index if not exists ride_ratings_driver_idx on public.ride_ratings(driver_id);
create index if not exists ride_ratings_passenger_idx on public.ride_ratings(passenger_id);

alter table public.ride_ratings enable row level security;

drop policy if exists "ride ratings passenger read" on public.ride_ratings;
create policy "ride ratings passenger read" on public.ride_ratings
for select to authenticated using (passenger_id = auth.uid());

drop policy if exists "ride ratings passenger insert" on public.ride_ratings;
create policy "ride ratings passenger insert" on public.ride_ratings
for insert to authenticated with check (passenger_id = auth.uid());

create or replace function public.rate_completed_ride(
  p_ride_id uuid,
  p_rating smallint,
  p_comment text default null
)
returns public.ride_ratings
language plpgsql
security definer
set search_path=public
as $$
declare
  r public.rides;
  out_row public.ride_ratings;
begin
  if p_rating < 1 or p_rating > 5 then raise exception 'Nota deve estar entre 1 e 5'; end if;

  select * into r from public.rides
  where id=p_ride_id and passenger_id=auth.uid();

  if r.id is null then raise exception 'Corrida não encontrada'; end if;
  if r.status <> 'completed' then raise exception 'A corrida ainda não foi concluída'; end if;

  insert into public.ride_ratings(ride_id,passenger_id,driver_id,rating,comment)
  values(r.id,auth.uid(),r.driver_id,p_rating,nullif(trim(p_comment),''))
  on conflict (ride_id) do update set rating=excluded.rating,comment=excluded.comment
  returning * into out_row;

  return out_row;
end;
$$;

grant execute on function public.rate_completed_ride(uuid,smallint,text) to authenticated;
