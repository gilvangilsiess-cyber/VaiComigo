-- VaiComigo v33 — identidade, perfil do motorista, tarifa por rota e checkout seguro
alter table public.profiles add column if not exists full_name text;
alter table public.profiles add column if not exists avatar_url text;
alter table public.profiles add column if not exists phone text;
alter table public.profiles add column if not exists payment_method text default 'pix';

alter table public.drivers add column if not exists avatar_url text;
alter table public.drivers add column if not exists vehicle_color text;
alter table public.drivers add column if not exists vehicle_year integer;
alter table public.drivers add column if not exists vehicle_type text default 'carro';

alter table public.rides add column if not exists route_distance_km numeric(10,2);
alter table public.rides add column if not exists route_duration_min numeric(10,2);
alter table public.rides add column if not exists quote_source text default 'vai_route';

create index if not exists rides_route_distance_idx on public.rides(route_distance_km);

create or replace function public.create_ride_quote(
  p_origin_lat double precision,
  p_origin_lng double precision,
  p_destination_name text,
  p_distance_km numeric,
  p_duration_min numeric,
  p_payment_method text default 'pix'
)
returns public.rides
language plpgsql
security definer
set search_path=public
as $$
declare
  r public.rides;
  v_fare numeric(10,2);
  v_method text := lower(coalesce(p_payment_method,'pix'));
begin
  if auth.uid() is null then raise exception 'Usuário não autenticado'; end if;
  if p_origin_lat is null or p_origin_lng is null then raise exception 'Localização de origem obrigatória'; end if;
  if p_distance_km is null or p_distance_km < 0 or p_distance_km > 500 then raise exception 'Distância inválida'; end if;
  if p_duration_min is null or p_duration_min < 0 or p_duration_min > 1440 then raise exception 'Duração inválida'; end if;
  if v_method not in ('pix','card','cash') then raise exception 'Método de pagamento inválido'; end if;

  v_fare := public.estimate_ride_fare(p_distance_km,p_duration_min);

  insert into public.rides(
    passenger_id,origin_lat,origin_lng,destination_name,ride_type,
    estimated_price,fare_estimate,route_distance_km,route_duration_min,
    quote_source,payment_method,payment_status,status
  ) values (
    auth.uid(),p_origin_lat,p_origin_lng,nullif(trim(p_destination_name),''),'simple',
    v_fare,v_fare,round(p_distance_km,2),round(p_duration_min,2),
    'vai_route',v_method,'pending','requested'
  ) returning * into r;

  return r;
end;
$$;
revoke all on function public.create_ride_quote(double precision,double precision,text,numeric,numeric,text) from public;
grant execute on function public.create_ride_quote(double precision,double precision,text,numeric,numeric,text) to authenticated;

-- Atualiza somente o perfil do motorista autenticado.
create or replace function public.update_my_driver_profile(
  p_full_name text,
  p_phone text,
  p_vehicle_model text,
  p_vehicle_plate text,
  p_vehicle_color text default null,
  p_vehicle_year integer default null,
  p_avatar_url text default null
)
returns public.drivers
language plpgsql
security definer
set search_path=public
as $$
declare d public.drivers;
begin
  update public.drivers set
    full_name=nullif(trim(p_full_name),''),
    phone=nullif(trim(p_phone),''),
    vehicle_model=nullif(trim(p_vehicle_model),''),
    vehicle_plate=nullif(upper(trim(p_vehicle_plate)),''),
    vehicle_color=nullif(trim(p_vehicle_color),''),
    vehicle_year=p_vehicle_year,
    avatar_url=nullif(trim(p_avatar_url),'')
  where id=auth.uid()
  returning * into d;
  if d.id is null then raise exception 'Cadastro de motorista não encontrado'; end if;
  return d;
end;
$$;
revoke all on function public.update_my_driver_profile(text,text,text,text,text,integer,text) from public;
grant execute on function public.update_my_driver_profile(text,text,text,text,text,integer,text) to authenticated;

-- Consulta segura do motorista vinculado a uma corrida.
create or replace function public.get_ride_driver(p_ride_id uuid)
returns jsonb
language sql
security definer
set search_path=public
as $$
  select coalesce((
    select jsonb_build_object(
      'id',d.id,'full_name',d.full_name,'phone',d.phone,'avatar_url',d.avatar_url,
      'vehicle_model',d.vehicle_model,'vehicle_plate',d.vehicle_plate,
      'vehicle_color',d.vehicle_color,'vehicle_year',d.vehicle_year,
      'status',d.status,'rating',coalesce((select round(avg(rr.rating)::numeric,1) from public.ride_ratings rr where rr.driver_id=d.id),5.0)
    )
    from public.rides r join public.drivers d on d.id=r.driver_id
    where r.id=p_ride_id and (r.passenger_id=auth.uid() or r.driver_id=auth.uid())
  ), '{}'::jsonb);
$$;
revoke all on function public.get_ride_driver(uuid) from public;
grant execute on function public.get_ride_driver(uuid) to authenticated;
