-- VaiComigo v34 — gateway real de pagamentos (Pix + checkout de cartão)
alter table public.payment_transactions add column if not exists external_status text;
alter table public.payment_transactions add column if not exists qr_code text;
alter table public.payment_transactions add column if not exists qr_code_base64 text;
alter table public.payment_transactions add column if not exists checkout_url text;
alter table public.payment_transactions add column if not exists provider_payload jsonb;

create index if not exists payment_transactions_provider_ref_idx
  on public.payment_transactions(provider, provider_reference);

-- Permite que o passageiro veja o estado e dados necessários do próprio pagamento.
drop policy if exists payment_tx_passenger_select on public.payment_transactions;
create policy payment_tx_passenger_select on public.payment_transactions
for select to authenticated using (passenger_id = auth.uid());

-- A confirmação do provedor acontece pela Edge Function/webhook, nunca pelo navegador.
create or replace function public.sync_external_payment(
  p_provider text,
  p_provider_reference text,
  p_status text,
  p_external_status text default null,
  p_qr_code text default null,
  p_qr_code_base64 text default null,
  p_checkout_url text default null,
  p_payload jsonb default null
)
returns public.payment_transactions
language plpgsql
security definer
set search_path=public
as $$
declare tx public.payment_transactions;
  v_status text;
begin
  select * into tx from public.payment_transactions
   where provider=p_provider and provider_reference=p_provider_reference
   limit 1;
  if tx.id is null then raise exception 'Transação não encontrada'; end if;

  v_status = case
    when p_status in ('paid','approved') then 'paid'
    when p_status in ('failed','rejected','cancelled','cancelled_by_user') then 'failed'
    when p_status in ('authorized','in_process','pending','pending_waiting_payment') then 'pending'
    else tx.status
  end;

  update public.payment_transactions
  set status=v_status,
      external_status=p_external_status,
      qr_code=coalesce(p_qr_code,qr_code),
      qr_code_base64=coalesce(p_qr_code_base64,qr_code_base64),
      checkout_url=coalesce(p_checkout_url,checkout_url),
      provider_payload=coalesce(p_payload,provider_payload),
      paid_at=case when v_status='paid' then coalesce(paid_at,now()) else paid_at end
  where id=tx.id
  returning * into tx;

  update public.rides
  set payment_status=case when v_status='paid' then 'paid' when v_status='failed' then 'failed' else 'pending' end,
      payment_provider=p_provider,
      payment_reference=p_provider_reference,
      payment_paid_at=case when v_status='paid' then coalesce(payment_paid_at,now()) else payment_paid_at end
  where id=tx.ride_id;

  return tx;
end;
$$;
revoke all on function public.sync_external_payment(text,text,text,text,text,text,text,jsonb) from public;
-- Somente o backend deve executar esta função.
grant execute on function public.sync_external_payment(text,text,text,text,text,text,text,jsonb) to service_role;
