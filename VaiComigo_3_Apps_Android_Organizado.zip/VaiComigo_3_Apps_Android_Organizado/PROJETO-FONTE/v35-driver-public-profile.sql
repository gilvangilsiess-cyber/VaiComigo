-- VaiComigo v35 — perfil público seguro do motorista
create or replace function public.get_public_driver_profile(p_driver_id uuid)
returns table(
  id uuid,
  full_name text,
  avatar_url text,
  vehicle_model text,
  vehicle_color text,
  vehicle_year integer,
  vehicle_plate text,
  rating numeric,
  rating_count bigint,
  approved boolean
)
language sql
security definer
set search_path=public
as $$
  select d.id,
         d.full_name,
         d.avatar_url,
         d.vehicle_model,
         d.vehicle_color,
         d.vehicle_year,
         d.vehicle_plate,
         coalesce(round(avg(rr.rating)::numeric,1),0) as rating,
         count(rr.id) as rating_count,
         (d.document_status = 'approved') as approved
  from public.drivers d
  left join public.ride_ratings rr on rr.driver_id=d.id
  where d.id=p_driver_id
  group by d.id,d.full_name,d.avatar_url,d.vehicle_model,d.vehicle_color,d.vehicle_year,d.vehicle_plate,d.document_status;
$$;

revoke all on function public.get_public_driver_profile(uuid) from public;
grant execute on function public.get_public_driver_profile(uuid) to authenticated;

comment on function public.get_public_driver_profile(uuid) is
'Retorna somente dados necessários para o passageiro identificar o motorista aceito; não expõe telefone, documentos ou localização.';
