-- VaiComigo v36 — credenciamento documental seguro do motorista
create table if not exists public.driver_documents (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.drivers(id) on delete cascade,
  document_type text not null check (document_type in ('cnh','crlv','profile_photo','other')),
  file_path text not null,
  file_name text not null,
  mime_type text,
  expires_at date,
  status text not null default 'pending' check (status in ('pending','approved','rejected','expired')),
  rejection_reason text,
  reviewed_at timestamptz,
  reviewed_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists driver_documents_driver_idx on public.driver_documents(driver_id, document_type, status);

alter table public.driver_documents enable row level security;
drop policy if exists "driver documents own read" on public.driver_documents;
create policy "driver documents own read" on public.driver_documents for select to authenticated using (driver_id=auth.uid() or public.is_admin());
drop policy if exists "driver documents own insert" on public.driver_documents;
create policy "driver documents own insert" on public.driver_documents for insert to authenticated with check (driver_id=auth.uid());

insert into storage.buckets (id,name,public) values ('driver-documents','driver-documents',false) on conflict (id) do nothing;
drop policy if exists "driver docs storage insert" on storage.objects;
create policy "driver docs storage insert" on storage.objects for insert to authenticated with check (bucket_id='driver-documents' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "driver docs storage read" on storage.objects;
create policy "driver docs storage read" on storage.objects for select to authenticated using (bucket_id='driver-documents' and ((storage.foldername(name))[1]=auth.uid()::text or public.is_admin()));
drop policy if exists "driver docs storage update" on storage.objects;
create policy "driver docs storage update" on storage.objects for update to authenticated using (bucket_id='driver-documents' and ((storage.foldername(name))[1]=auth.uid()::text or public.is_admin()));

create or replace function public.get_my_driver_documents()
returns table(id uuid, document_type text, file_name text, mime_type text, expires_at date, status text, rejection_reason text, created_at timestamptz)
language sql security definer set search_path=public as $$
 select id,document_type,file_name,mime_type,expires_at,status,rejection_reason,created_at
 from public.driver_documents where driver_id=auth.uid() order by created_at desc;
$$;
grant execute on function public.get_my_driver_documents() to authenticated;

create or replace function public.admin_driver_documents(p_driver_id uuid default null)
returns table(id uuid,driver_id uuid,driver_name text,document_type text,file_name text,mime_type text,file_path text,expires_at date,status text,rejection_reason text,created_at timestamptz)
language plpgsql security definer set search_path=public as $$
begin
 if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
 return query select dd.id,dd.driver_id,d.full_name,dd.document_type,dd.file_name,dd.mime_type,dd.file_path,dd.expires_at,dd.status,dd.rejection_reason,dd.created_at
 from public.driver_documents dd join public.drivers d on d.id=dd.driver_id
 where p_driver_id is null or dd.driver_id=p_driver_id order by dd.created_at desc;
end; $$;
grant execute on function public.admin_driver_documents(uuid) to authenticated;

create or replace function public.admin_review_driver_document(p_document_id uuid,p_status text,p_reason text default null)
returns public.driver_documents
language plpgsql security definer set search_path=public as $$
declare x public.driver_documents;
begin
 if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
 if p_status not in ('pending','approved','rejected','expired') then raise exception 'Status inválido'; end if;
 update public.driver_documents set status=p_status,rejection_reason=case when p_status='rejected' then nullif(trim(p_reason),'') else null end,reviewed_at=now(),reviewed_by=auth.uid(),updated_at=now() where id=p_document_id returning * into x;
 if x.id is null then raise exception 'Documento não encontrado'; end if;
 if p_status='rejected' then update public.drivers set document_status='rejected',status='offline',updated_at=now() where id=x.driver_id;
 elsif p_status='approved' then
   if not exists(select 1 from public.driver_documents where driver_id=x.driver_id and document_type in ('cnh','crlv') and status<>'approved') then update public.drivers set document_status='approved',updated_at=now() where id=x.driver_id; end if;
 end if;
 return x;
end; $$;
grant execute on function public.admin_review_driver_document(uuid,text,text) to authenticated;

create or replace function public.expire_driver_documents()
returns integer language plpgsql security definer set search_path=public as $$
declare n integer;
begin
 update public.driver_documents set status='expired',updated_at=now() where expires_at is not null and expires_at < current_date and status='approved'; get diagnostics n=row_count;
 update public.drivers d set document_status='pending',status='offline',updated_at=now() where exists(select 1 from public.driver_documents x where x.driver_id=d.id and x.status='expired');
 return n;
end; $$;
revoke all on function public.expire_driver_documents() from public;
grant execute on function public.expire_driver_documents() to authenticated;
