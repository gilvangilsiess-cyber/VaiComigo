-- VaiComigo v37 — central de operações administrativa
-- Segurança: todas as operações administrativas passam por is_admin().

create index if not exists sos_events_status_created_idx
  on public.sos_events(status, created_at desc);
create index if not exists payment_transactions_status_created_idx
  on public.payment_transactions(status, created_at desc);

create or replace function public.admin_operations_dashboard()
returns jsonb
language plpgsql stable security definer set search_path=public
as $$
declare result jsonb; cfg numeric;
begin
  if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
  select commission_percent into cfg from public.platform_settings where id=true;
  select jsonb_build_object(
    'completed_rides',(select count(*) from public.rides where status='completed'),
    'active_rides',(select count(*) from public.rides where status in ('requested','accepted','arriving','in_progress','offered')),
    'requested_tours',(select count(*) from public.tour_bookings where status='requested'),
    'available_drivers',(select count(*) from public.drivers where status='available'),
    'users',(select count(*) from public.profiles),
    'gross_completed',(select coalesce(sum(coalesce(final_price,estimated_price,fare_estimate,0)),0) from public.rides where status='completed'),
    'commission_percent',coalesce(cfg,20),
    'open_sos',(select count(*) from public.sos_events where status in ('open','acknowledged')),
    'pending_payments',(select count(*) from public.payment_transactions where status='pending'),
    'pending_documents',(select count(*) from public.driver_documents where status='pending'),
    'drivers',coalesce((select jsonb_agg(to_jsonb(x) order by x.updated_at desc nulls last) from (select id,full_name,status,vehicle_model,vehicle_plate,document_status,updated_at from public.drivers order by updated_at desc nulls last limit 30) x),'[]'::jsonb),
    'rides',coalesce((select jsonb_agg(to_jsonb(x) order by x.created_at desc) from (select id,created_at,status,destination_name,coalesce(final_price,estimated_price,fare_estimate,0)::numeric as amount,payment_status from public.rides order by created_at desc limit 40) x),'[]'::jsonb),
    'tours',coalesce((select jsonb_agg(to_jsonb(x) order by x.start_at desc) from (select id,start_at,status,duration_hours,price from public.tour_bookings order by start_at desc limit 20) x),'[]'::jsonb),
    'sos',coalesce((select jsonb_agg(to_jsonb(x) order by x.created_at desc) from (select id,user_id,ride_id,lat,lng,message,status,created_at from public.sos_events order by created_at desc limit 30) x),'[]'::jsonb),
    'payments',coalesce((select jsonb_agg(to_jsonb(x) order by x.created_at desc) from (select id,ride_id,amount,method,status,provider,provider_reference,created_at,paid_at from public.payment_transactions order by created_at desc limit 30) x),'[]'::jsonb)
  ) into result;
  return result;
end; $$;
revoke all on function public.admin_operations_dashboard() from public;
grant execute on function public.admin_operations_dashboard() to authenticated;

create or replace function public.admin_resolve_sos(p_sos_id uuid,p_status text)
returns public.sos_events
language plpgsql security definer set search_path=public
as $$
declare x public.sos_events;
begin
  if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
  if p_status not in ('acknowledged','closed') then raise exception 'Status SOS inválido'; end if;
  update public.sos_events set status=p_status where id=p_sos_id returning * into x;
  if x.id is null then raise exception 'SOS não encontrado'; end if;
  return x;
end; $$;
revoke all on function public.admin_resolve_sos(uuid,text) from public;
grant execute on function public.admin_resolve_sos(uuid,text) to authenticated;

create or replace function public.admin_cancel_ride(p_ride_id uuid)
returns public.rides
language plpgsql security definer set search_path=public
as $$
declare x public.rides;
begin
  if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
  update public.rides
     set status='cancelled', cancelled_at=coalesce(cancelled_at,now())
   where id=p_ride_id and status in ('requested','accepted','arriving','in_progress','offered')
   returning * into x;
  if x.id is null then raise exception 'Corrida não pode ser cancelada neste estado'; end if;
  return x;
end; $$;
revoke all on function public.admin_cancel_ride(uuid) from public;
grant execute on function public.admin_cancel_ride(uuid) to authenticated;

create or replace function public.admin_set_driver_status(p_driver_id uuid,p_status text)
returns public.drivers
language plpgsql security definer set search_path=public
as $$
declare x public.drivers;
begin
  if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
  if p_status not in ('offline','available','busy','suspended') then raise exception 'Status de motorista inválido'; end if;
  if p_status='available' and exists(select 1 from public.driver_documents where driver_id=p_driver_id and document_type in ('cnh','crlv') and status<>'approved') then
    raise exception 'Motorista possui documento obrigatório pendente ou inválido';
  end if;
  update public.drivers set status=p_status,updated_at=now() where id=p_driver_id returning * into x;
  if x.id is null then raise exception 'Motorista não encontrado'; end if;
  return x;
end; $$;
revoke all on function public.admin_set_driver_status(uuid,text) from public;
grant execute on function public.admin_set_driver_status(uuid,text) to authenticated;
