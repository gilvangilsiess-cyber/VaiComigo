-- VaiComigo v38 — integração ponta a ponta e endurecimento de regras
-- Execute depois da v37.

create or replace function public.get_my_app_context()
returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  d public.drivers;
  result jsonb;
begin
  if u is null then raise exception 'Usuário não autenticado'; end if;

  select * into p from public.profiles where id=u;
  select * into d from public.drivers where id=u;

  select jsonb_build_object(
    'user_id', u,
    'role', coalesce(p.role,'passenger'),
    'is_admin', public.is_admin(),
    'has_driver_profile', d.id is not null,
    'driver_status', d.status,
    'driver_document_status', d.document_status,
    'driver_can_drive', (d.id is not null and d.document_status='approved' and d.status in ('available','busy'))
  ) into result;
  return result;
end;
$$;
revoke all on function public.get_my_app_context() from public;
grant execute on function public.get_my_app_context() to authenticated;

-- Um motorista só pode aceitar corridas quando seu credenciamento está aprovado.
create or replace function public.accept_ride(p_ride_id uuid)
returns public.rides
language plpgsql
security definer
set search_path=public
as $$
declare r public.rides;
begin
  if not exists (
    select 1 from public.drivers d
    where d.id=auth.uid()
      and d.status='available'
      and d.document_status='approved'
  ) then
    raise exception 'Motorista não está disponível ou não está aprovado';
  end if;

  -- Impede que o mesmo motorista assuma duas corridas simultâneas.
  if exists (
    select 1 from public.rides x
    where x.driver_id=auth.uid()
      and x.status in ('accepted','arriving','in_progress')
  ) then
    raise exception 'Motorista já possui uma corrida em andamento';
  end if;

  update public.rides
     set driver_id=auth.uid(),
         status='accepted',
         accepted_at=coalesce(accepted_at,now())
   where id=p_ride_id
     and driver_id is null
     and status in ('requested','offered')
  returning * into r;

  if r.id is null then
    raise exception 'Corrida já foi aceita ou não está mais disponível';
  end if;

  update public.drivers set status='busy', updated_at=now() where id=auth.uid();
  return r;
end;
$$;
revoke all on function public.accept_ride(uuid) from public;
grant execute on function public.accept_ride(uuid) to authenticated;

-- Ao concluir/cancelar, libera o motorista para nova corrida.
create or replace function public.update_ride_status(p_ride_id uuid,p_status text)
returns public.rides
language plpgsql
security definer
set search_path=public
as $$
declare r public.rides;
begin
  if p_status not in ('arriving','in_progress','completed','cancelled') then raise exception 'Status inválido'; end if;

  update public.rides
     set status=p_status,
         arrived_at=case when p_status='arriving' then coalesce(arrived_at,now()) else arrived_at end,
         started_at=case when p_status='in_progress' then coalesce(started_at,now()) else started_at end,
         completed_at=case when p_status='completed' then coalesce(completed_at,now()) else completed_at end,
         cancelled_at=case when p_status='cancelled' then coalesce(cancelled_at,now()) else cancelled_at end
   where id=p_ride_id and driver_id=auth.uid()
     and ((status='accepted' and p_status in ('arriving','cancelled'))
       or (status='arriving' and p_status in ('in_progress','cancelled'))
       or (status='in_progress' and p_status in ('completed','cancelled')))
   returning * into r;

  if r.id is null then raise exception 'Transição de corrida inválida'; end if;

  if p_status in ('completed','cancelled') then
    update public.drivers
       set status=case when document_status='approved' then 'offline' else 'suspended' end,
           updated_at=now()
     where id=auth.uid();
  end if;
  return r;
end;
$$;
revoke all on function public.update_ride_status(uuid,text) from public;
grant execute on function public.update_ride_status(uuid,text) to authenticated;

-- Diagnóstico operacional, acessível somente ao administrador.
create or replace function public.admin_system_health()
returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare result jsonb;
begin
  if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
  select jsonb_build_object(
    'profiles', (select count(*) from public.profiles),
    'drivers', (select count(*) from public.drivers),
    'approved_drivers', (select count(*) from public.drivers where document_status='approved'),
    'available_drivers', (select count(*) from public.drivers where status='available'),
    'busy_drivers', (select count(*) from public.drivers where status='busy'),
    'active_rides', (select count(*) from public.rides where status in ('requested','accepted','arriving','in_progress')),
    'stale_requested_rides', (select count(*) from public.rides where status='requested' and created_at < now()-interval '15 minutes'),
    'open_sos', (select count(*) from public.sos_events where status in ('open','acknowledged')),
    'pending_documents', (select count(*) from public.driver_documents where status='pending'),
    'pending_payments', (select count(*) from public.payment_transactions where status='pending')
  ) into result;
  return result;
end;
$$;
revoke all on function public.admin_system_health() from public;
grant execute on function public.admin_system_health() to authenticated;
