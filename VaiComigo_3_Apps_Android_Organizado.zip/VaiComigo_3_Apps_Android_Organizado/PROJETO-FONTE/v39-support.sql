-- VaiComigo v39 — suporte, atendimento e comunicação operacional
-- Execute depois da v38.

create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  ride_id uuid null references public.rides(id) on delete set null,
  category text not null default 'other',
  subject text not null,
  status text not null default 'open' check (status in ('open','in_progress','waiting_user','resolved','closed')),
  priority text not null default 'normal' check (priority in ('low','normal','high','urgent')),
  assigned_to uuid null references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  resolved_at timestamptz null
);

create table if not exists public.support_messages (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references public.support_tickets(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(trim(body)) between 1 and 4000),
  created_at timestamptz not null default now()
);

create index if not exists support_tickets_user_idx on public.support_tickets(user_id, updated_at desc);
create index if not exists support_tickets_status_idx on public.support_tickets(status, priority, updated_at desc);
create index if not exists support_messages_ticket_idx on public.support_messages(ticket_id, created_at);

alter table public.support_tickets enable row level security;
alter table public.support_messages enable row level security;

-- As políticas são restritivas: participantes veem seus próprios chamados; admins veem todos.
drop policy if exists support_tickets_select on public.support_tickets;
create policy support_tickets_select on public.support_tickets for select to authenticated
using (user_id = auth.uid() or public.is_admin());

drop policy if exists support_messages_select on public.support_messages;
create policy support_messages_select on public.support_messages for select to authenticated
using (exists(select 1 from public.support_tickets t where t.id=ticket_id and (t.user_id=auth.uid() or public.is_admin())));

create or replace function public.create_support_ticket(
  p_category text,
  p_subject text,
  p_body text,
  p_ride_id uuid default null,
  p_priority text default 'normal'
)
returns public.support_tickets
language plpgsql security definer set search_path=public
as $$
declare t public.support_tickets;
begin
  if auth.uid() is null then raise exception 'Usuário não autenticado'; end if;
  if char_length(trim(coalesce(p_subject,''))) < 3 then raise exception 'Informe um assunto'; end if;
  if char_length(trim(coalesce(p_body,''))) < 3 then raise exception 'Descreva o problema'; end if;
  if p_priority not in ('low','normal','high','urgent') then raise exception 'Prioridade inválida'; end if;
  insert into public.support_tickets(user_id,ride_id,category,subject,priority)
  values(auth.uid(),p_ride_id,coalesce(nullif(trim(p_category),''),'other'),trim(p_subject),p_priority)
  returning * into t;
  insert into public.support_messages(ticket_id,sender_id,body) values(t.id,auth.uid(),trim(p_body));
  return t;
end;
$$;
revoke all on function public.create_support_ticket(text,text,text,uuid,text) from public;
grant execute on function public.create_support_ticket(text,text,text,uuid,text) to authenticated;

create or replace function public.add_support_message(p_ticket_id uuid,p_body text)
returns public.support_messages
language plpgsql security definer set search_path=public
as $$
declare m public.support_messages;
declare t public.support_tickets;
begin
  if auth.uid() is null then raise exception 'Usuário não autenticado'; end if;
  select * into t from public.support_tickets where id=p_ticket_id and (user_id=auth.uid() or public.is_admin());
  if t.id is null then raise exception 'Chamado não encontrado'; end if;
  if t.status in ('resolved','closed') and not public.is_admin() then raise exception 'Este chamado já foi encerrado'; end if;
  if char_length(trim(coalesce(p_body,''))) < 1 then raise exception 'Mensagem vazia'; end if;
  insert into public.support_messages(ticket_id,sender_id,body) values(p_ticket_id,auth.uid(),trim(p_body)) returning * into m;
  update public.support_tickets set updated_at=now(), status=case when public.is_admin() then 'waiting_user' else 'open' end where id=p_ticket_id;
  return m;
end;
$$;
revoke all on function public.add_support_message(uuid,text) from public;
grant execute on function public.add_support_message(uuid,text) to authenticated;

create or replace function public.my_support_tickets()
returns table(id uuid, ride_id uuid, category text, subject text, status text, priority text, created_at timestamptz, updated_at timestamptz, message_count bigint)
language sql stable security definer set search_path=public
as $$
  select t.id,t.ride_id,t.category,t.subject,t.status,t.priority,t.created_at,t.updated_at,
         (select count(*) from public.support_messages m where m.ticket_id=t.id)
  from public.support_tickets t where t.user_id=auth.uid() order by t.updated_at desc limit 30;
$$;
revoke all on function public.my_support_tickets() from public;
grant execute on function public.my_support_tickets() to authenticated;

create or replace function public.support_ticket_messages(p_ticket_id uuid)
returns table(id uuid,sender_id uuid,body text,created_at timestamptz,is_admin boolean)
language sql stable security definer set search_path=public
as $$
  select m.id,m.sender_id,m.body,m.created_at,public.is_admin() and m.sender_id <> auth.uid()
  from public.support_messages m join public.support_tickets t on t.id=m.ticket_id
  where m.ticket_id=p_ticket_id and (t.user_id=auth.uid() or public.is_admin())
  order by m.created_at asc;
$$;
revoke all on function public.support_ticket_messages(uuid) from public;
grant execute on function public.support_ticket_messages(uuid) to authenticated;

create or replace function public.admin_support_dashboard()
returns jsonb language plpgsql stable security definer set search_path=public
as $$
declare result jsonb;
begin
  if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
  select jsonb_build_object(
    'open', (select count(*) from public.support_tickets where status='open'),
    'in_progress', (select count(*) from public.support_tickets where status='in_progress'),
    'urgent', (select count(*) from public.support_tickets where priority='urgent' and status not in ('resolved','closed')),
    'tickets', coalesce((select jsonb_agg(row_to_json(x) order by x.updated_at desc) from (
      select t.id,t.user_id,t.ride_id,t.category,t.subject,t.status,t.priority,t.created_at,t.updated_at,
             coalesce(p.full_name,'Usuário') as user_name,
             (select count(*) from public.support_messages m where m.ticket_id=t.id) as message_count
      from public.support_tickets t left join public.profiles p on p.id=t.user_id
      where t.status not in ('closed') order by t.updated_at desc limit 50
    ) x),'[]'::jsonb)
  ) into result;
  return result;
end;
$$;
revoke all on function public.admin_support_dashboard() from public;
grant execute on function public.admin_support_dashboard() to authenticated;

create or replace function public.admin_update_support_ticket(p_ticket_id uuid,p_status text,p_priority text default null)
returns public.support_tickets language plpgsql security definer set search_path=public
as $$
declare t public.support_tickets;
begin
  if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
  if p_status not in ('open','in_progress','waiting_user','resolved','closed') then raise exception 'Status inválido'; end if;
  if p_priority is not null and p_priority not in ('low','normal','high','urgent') then raise exception 'Prioridade inválida'; end if;
  update public.support_tickets set status=p_status, priority=coalesce(p_priority,priority), assigned_to=case when p_status='in_progress' then auth.uid() else assigned_to end, resolved_at=case when p_status in ('resolved','closed') then coalesce(resolved_at,now()) else null end, updated_at=now() where id=p_ticket_id returning * into t;
  if t.id is null then raise exception 'Chamado não encontrado'; end if;
  return t;
end;
$$;
revoke all on function public.admin_update_support_ticket(uuid,text,text) from public;
grant execute on function public.admin_update_support_ticket(uuid,text,text) to authenticated;

-- Realtime permite atualização instantânea do atendimento.
alter table public.support_tickets replica identity full;
alter table public.support_messages replica identity full;

do $$ begin
  alter publication supabase_realtime add table public.support_tickets;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.support_messages;
exception when duplicate_object then null; end $$;
