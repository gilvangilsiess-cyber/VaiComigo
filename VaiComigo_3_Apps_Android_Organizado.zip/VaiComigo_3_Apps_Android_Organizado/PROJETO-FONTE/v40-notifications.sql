-- VaiComigo V40 — notificações e preferências
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  type text not null default 'system',
  title text not null,
  body text not null,
  data jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_created_idx on public.notifications(user_id, created_at desc);
create index if not exists notifications_user_unread_idx on public.notifications(user_id) where read_at is null;
alter table public.notifications enable row level security;
drop policy if exists notifications_select_own on public.notifications;
create policy notifications_select_own on public.notifications for select to authenticated using (user_id=auth.uid());
drop policy if exists notifications_update_own on public.notifications;
create policy notifications_update_own on public.notifications for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());

create table if not exists public.notification_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  ride_updates boolean not null default true,
  payments boolean not null default true,
  safety boolean not null default true,
  support boolean not null default true,
  marketing boolean not null default false,
  push_enabled boolean not null default false,
  updated_at timestamptz not null default now()
);
alter table public.notification_preferences enable row level security;
drop policy if exists notification_preferences_own on public.notification_preferences;
create policy notification_preferences_own on public.notification_preferences for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());

create table if not exists public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  endpoint text not null,
  p256dh text not null,
  auth text not null,
  user_agent text,
  created_at timestamptz not null default now(),
  unique(user_id, endpoint)
);
alter table public.push_subscriptions enable row level security;
drop policy if exists push_subscriptions_own on public.push_subscriptions;
create policy push_subscriptions_own on public.push_subscriptions for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());

create or replace function public.ensure_notification_preferences()
returns public.notification_preferences language plpgsql security definer set search_path=public as $$
declare p public.notification_preferences;
begin
 insert into public.notification_preferences(user_id) values(auth.uid()) on conflict(user_id) do nothing;
 select * into p from public.notification_preferences where user_id=auth.uid();
 return p;
end; $$;
grant execute on function public.ensure_notification_preferences() to authenticated;

create or replace function public.mark_notification_read(p_id uuid)
returns void language plpgsql security definer set search_path=public as $$
begin update public.notifications set read_at=coalesce(read_at,now()) where id=p_id and user_id=auth.uid(); end; $$;
grant execute on function public.mark_notification_read(uuid) to authenticated;

create or replace function public.mark_all_notifications_read()
returns void language plpgsql security definer set search_path=public as $$
begin update public.notifications set read_at=coalesce(read_at,now()) where user_id=auth.uid() and read_at is null; end; $$;
grant execute on function public.mark_all_notifications_read() to authenticated;

create or replace function public.notify_user(p_user_id uuid,p_type text,p_title text,p_body text,p_data jsonb default '{}'::jsonb)
returns uuid language plpgsql security definer set search_path=public as $$
declare nid uuid;
begin
 if p_user_id is null then return null; end if;
 insert into public.notifications(user_id,type,title,body,data) values(p_user_id,p_type,p_title,p_body,coalesce(p_data,'{}'::jsonb)) returning id into nid;
 return nid;
end; $$;
revoke all on function public.notify_user(uuid,text,text,text,jsonb) from public,anon,authenticated;

create or replace function public.v40_ride_notification()
returns trigger language plpgsql security definer set search_path=public as $$
begin
 if new.status is distinct from old.status then
   if new.passenger_id is not null then
     perform public.notify_user(new.passenger_id,'ride','Atualização da corrida',
       case new.status when 'accepted' then 'Seu motorista aceitou a corrida.' when 'arriving' then 'Seu motorista está chegando.' when 'in_progress' then 'A corrida começou.' when 'completed' then 'A corrida foi concluída.' when 'cancelled' then 'A corrida foi cancelada.' else 'A corrida foi atualizada.' end,
       jsonb_build_object('ride_id',new.id,'status',new.status));
   end if;
   if new.driver_id is not null and new.status in ('requested','accepted','arriving','in_progress','completed','cancelled') then
     perform public.notify_user(new.driver_id,'ride','Atualização da corrida',
       case new.status when 'requested' then 'Há uma nova corrida disponível.' when 'accepted' then 'Corrida aceita.' when 'arriving' then 'Você está a caminho do passageiro.' when 'in_progress' then 'Corrida iniciada.' when 'completed' then 'Corrida concluída.' when 'cancelled' then 'A corrida foi cancelada.' else 'A corrida foi atualizada.' end,
       jsonb_build_object('ride_id',new.id,'status',new.status));
   end if;
 end if;
 return new;
end; $$;
drop trigger if exists v40_ride_notification on public.rides;
create trigger v40_ride_notification after update of status on public.rides for each row execute function public.v40_ride_notification();

create or replace function public.v40_payment_notification()
returns trigger language plpgsql security definer set search_path=public as $$
begin
 if new.status is distinct from old.status then
   perform public.notify_user(new.passenger_id,'payment','Pagamento atualizado',
     case new.status when 'paid' then 'Pagamento confirmado.' when 'failed' then 'O pagamento não foi aprovado.' when 'cancelled' then 'O pagamento foi cancelado.' else 'O pagamento foi atualizado.' end,
     jsonb_build_object('ride_id',new.ride_id,'payment_id',new.id,'status',new.status));
 end if;
 return new;
end; $$;
drop trigger if exists v40_payment_notification on public.payment_transactions;
create trigger v40_payment_notification after update of status on public.payment_transactions for each row execute function public.v40_payment_notification();

create or replace function public.v40_support_notification()
returns trigger language plpgsql security definer set search_path=public as $$
declare uid uuid; isadm boolean;
begin
 select t.user_id into uid from public.support_tickets t where t.id=new.ticket_id;
 select coalesce((select role='admin' from public.profiles where id=new.sender_id),false) into isadm;
 if isadm and uid is not null then perform public.notify_user(uid,'support','Nova resposta do suporte','O atendimento respondeu ao seu chamado.',jsonb_build_object('ticket_id',new.ticket_id)); end if;
 return new;
end; $$;
drop trigger if exists v40_support_notification on public.support_messages;
create trigger v40_support_notification after insert on public.support_messages for each row execute function public.v40_support_notification();

alter table public.notifications replica identity full;
alter table public.notification_preferences replica identity full;
do $$ begin alter publication supabase_realtime add table public.notifications; exception when duplicate_object then null; end $$;
