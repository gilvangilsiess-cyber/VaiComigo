-- VaiComigo v43 — retry automático do despacho de corridas
-- Objetivo: uma corrida não morrer porque não havia motorista elegível no
-- exato segundo do INSERT. A fila passa a ter backoff e um worker periódico.

alter table public.ride_push_queue
  add column if not exists next_attempt_at timestamptz not null default now(),
  add column if not exists max_attempts integer not null default 20;

create index if not exists ride_push_queue_ready_idx
  on public.ride_push_queue(processed_at, next_attempt_at, locked_until, created_at);

create or replace function public.finish_ride_push(
  p_ride_id uuid,
  p_success boolean,
  p_error text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare a integer;
begin
  select attempts into a from public.ride_push_queue where ride_id=p_ride_id;
  update public.ride_push_queue
     set processed_at=case when p_success then now() else null end,
         locked_at=null,
         locked_until=null,
         next_attempt_at=case
           when p_success then now()
           when coalesce(a,0) >= max_attempts then now()
           else now() + make_interval(secs => least(300, greatest(15, power(2, greatest(coalesce(a,1)-1,0))::integer)))
         end,
         last_error=case
           when p_success then null
           else left(coalesce(p_error,'Falha no push'),1000)
         end
   where ride_id=p_ride_id;
end;
$$;

-- Uma função segura para o worker obter somente itens prontos.
create or replace function public.pending_ride_pushes(p_limit integer default 25)
returns table(ride_id uuid)
language sql
security definer
set search_path=public
as $$
  select q.ride_id
  from public.ride_push_queue q
  where q.processed_at is null
    and q.next_attempt_at <= now()
    and (q.locked_until is null or q.locked_until < now())
    and q.attempts < q.max_attempts
  order by q.created_at
  limit greatest(1, least(p_limit,100));
$$;
revoke all on function public.pending_ride_pushes(integer) from public,anon,authenticated;
grant execute on function public.pending_ride_pushes(integer) to service_role;

-- Opcional, mas recomendado no Supabase: pg_cron + pg_net.
-- O bloco abaixo não agenda nada automaticamente porque a URL e o secret são
-- específicos do projeto. Depois de configurar Vault, execute o exemplo do
-- README-v43.md uma única vez.
