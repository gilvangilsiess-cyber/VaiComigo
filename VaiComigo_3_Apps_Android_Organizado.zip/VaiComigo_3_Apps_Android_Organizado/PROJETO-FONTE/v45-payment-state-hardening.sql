-- VaiComigo v45 — proteção contra regressão de estado de pagamento
-- Mantém pagamentos liquidados como estado terminal para webhooks atrasados/repetidos.

create or replace function public.sync_external_payment(
  p_provider text,
  p_provider_reference text,
  p_status text,
  p_external_status text default null,
  p_qr_code text default null,
  p_qr_code_base64 text default null,
  p_checkout_url text default null,
  p_payload jsonb default null
)
returns public.payment_transactions
language plpgsql
security definer
set search_path=public
as $$
declare
  tx public.payment_transactions;
  v_status text;
  v_next_status text;
begin
  select * into tx
  from public.payment_transactions
  where provider=p_provider and provider_reference=p_provider_reference
  limit 1
  for update;

  if tx.id is null then
    raise exception 'Transação não encontrada';
  end if;

  v_next_status = case
    when p_status in ('paid','approved') then 'paid'
    when p_status in ('failed','rejected','cancelled','cancelled_by_user') then 'failed'
    when p_status in ('authorized','in_process','pending','pending_waiting_payment') then 'pending'
    else tx.status
  end;

  -- paid é terminal: webhook atrasado não pode desfazer uma liquidação.
  if tx.status = 'paid' then
    v_status := 'paid';
  elsif tx.status = 'failed' and v_next_status = 'pending' then
    -- Um estado explicitamente falho também não volta para pending por evento antigo.
    v_status := 'failed';
  else
    v_status := v_next_status;
  end if;

  update public.payment_transactions
  set status=v_status,
      external_status=p_external_status,
      qr_code=coalesce(p_qr_code,qr_code),
      qr_code_base64=coalesce(p_qr_code_base64,qr_code_base64),
      checkout_url=coalesce(p_checkout_url,checkout_url),
      provider_payload=coalesce(p_payload,provider_payload),
      paid_at=case when v_status='paid' then coalesce(paid_at,now()) else paid_at end
  where id=tx.id
  returning * into tx;

  update public.rides
  set payment_status=case
        when v_status='paid' then 'paid'
        when v_status='failed' then 'failed'
        else 'pending'
      end,
      payment_provider=p_provider,
      payment_reference=p_provider_reference,
      payment_paid_at=case
        when v_status='paid' then coalesce(payment_paid_at,now())
        else payment_paid_at
      end
  where id=tx.ride_id
    and coalesce(payment_status,'pending') <> 'paid';

  -- Se a corrida já estava paga, ainda devolvemos a transação como paid sem rebaixá-la.
  if exists (select 1 from public.rides where id=tx.ride_id and payment_status='paid') then
    update public.payment_transactions
    set status='paid', paid_at=coalesce(paid_at,now())
    where id=tx.id
    returning * into tx;
  end if;

  return tx;
end;
$$;

revoke all on function public.sync_external_payment(text,text,text,text,text,text,text,jsonb) from public;
grant execute on function public.sync_external_payment(text,text,text,text,text,text,text,jsonb) to service_role;
