-- VaiComigo v46 — laboratório E2E isolado para testes manuais com 2 celulares
-- IMPORTANTE: o modo de teste é DESLIGADO por padrão. Só administrador pode ligar/desligar.
-- Quando ligado, contas autenticadas podem preparar a própria conta como motorista de teste.
-- Isto NÃO deve ser habilitado em produção pública.

alter table public.platform_settings
  add column if not exists test_mode_enabled boolean not null default false;

create or replace function public.admin_set_test_mode(p_enabled boolean)
returns boolean
language plpgsql
security definer
set search_path=public
as $$
begin
  if not public.is_admin() then
    raise exception 'Acesso administrativo negado';
  end if;
  update public.platform_settings
     set test_mode_enabled=p_enabled, updated_at=now()
   where id=true;
  return p_enabled;
end;
$$;
revoke all on function public.admin_set_test_mode(boolean) from public;
grant execute on function public.admin_set_test_mode(boolean) to authenticated;

create or replace function public.get_test_mode()
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select coalesce((select test_mode_enabled from public.platform_settings where id=true),false);
$$;
revoke all on function public.get_test_mode() from public;
grant execute on function public.get_test_mode() to authenticated;

-- Cria/prepara um motorista para a conta autenticada somente enquanto o laboratório está ligado.
-- Não altera role de admin/passageiro: o perfil da conta continua podendo ser usado no app.
create or replace function public.test_prepare_my_driver(
  p_full_name text default 'Motorista Teste',
  p_phone text default '(24) 99999-0000',
  p_vehicle_model text default 'Veículo Teste',
  p_vehicle_plate text default 'TESTE01'
)
returns public.drivers
language plpgsql
security definer
set search_path=public
as $$
declare
  d public.drivers;
  u uuid := auth.uid();
  v_enabled boolean;
begin
  if u is null then raise exception 'Usuário não autenticado'; end if;
  select coalesce(test_mode_enabled,false) into v_enabled from public.platform_settings where id=true;
  if not v_enabled then raise exception 'Laboratório de testes está desligado'; end if;

  insert into public.profiles(id,full_name,phone)
  values(u,nullif(trim(p_full_name),''),nullif(trim(p_phone),''))
  on conflict(id) do update set
    full_name=coalesce(excluded.full_name,public.profiles.full_name),
    phone=coalesce(excluded.phone,public.profiles.phone);

  insert into public.drivers(
    id,status,full_name,phone,vehicle_model,vehicle_plate,document_status,updated_at
  ) values(
    u,'offline',coalesce(nullif(trim(p_full_name),''),'Motorista Teste'),
    nullif(trim(p_phone),''),coalesce(nullif(trim(p_vehicle_model),''),'Veículo Teste'),
    coalesce(nullif(upper(trim(p_vehicle_plate)),''),'TESTE01'),'approved',now()
  )
  on conflict(id) do update set
    full_name=excluded.full_name,
    phone=excluded.phone,
    vehicle_model=excluded.vehicle_model,
    vehicle_plate=excluded.vehicle_plate,
    document_status='approved',
    status=case when public.drivers.status='busy' then public.drivers.status else 'offline' end,
    updated_at=now()
  returning * into d;

  return d;
end;
$$;
revoke all on function public.test_prepare_my_driver(text,text,text,text) from public;
grant execute on function public.test_prepare_my_driver(text,text,text,text) to authenticated;

create or replace function public.test_set_my_driver_location(
  p_lat double precision,
  p_lng double precision
)
returns public.drivers
language plpgsql
security definer
set search_path=public
as $$
declare d public.drivers;
begin
  if not public.get_test_mode() then raise exception 'Laboratório de testes está desligado'; end if;
  if auth.uid() is null then raise exception 'Usuário não autenticado'; end if;
  if p_lat is null or p_lng is null or p_lat not between -90 and 90 or p_lng not between -180 and 180 then
    raise exception 'Coordenadas inválidas';
  end if;
  update public.drivers
     set lat=p_lat,lng=p_lng,location_accuracy=5,location_updated_at=now(),updated_at=now()
   where id=auth.uid()
   returning * into d;
  if d.id is null then raise exception 'Prepare primeiro o motorista de teste'; end if;
  return d;
end;
$$;
revoke all on function public.test_set_my_driver_location(double precision,double precision) from public;
grant execute on function public.test_set_my_driver_location(double precision,double precision) to authenticated;

create or replace function public.admin_test_overview()
returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
begin
  if not public.is_admin() then raise exception 'Acesso administrativo negado'; end if;
  return jsonb_build_object(
    'test_mode_enabled',(select coalesce(test_mode_enabled,false) from public.platform_settings where id=true),
    'users',(select count(*) from public.profiles),
    'test_drivers',(select count(*) from public.drivers where document_status='approved' and coalesce(vehicle_plate,'') like 'TESTE%'),
    'active_test_rides',(select count(*) from public.rides where status in ('requested','accepted','arriving','in_progress') and (coalesce(destination_name,'') ilike '%[TESTE]%'))
  );
end;
$$;
revoke all on function public.admin_test_overview() from public;
grant execute on function public.admin_test_overview() to authenticated;

-- Marca novas corridas como teste no laboratório apenas quando o administrador o tiver ligado.
alter table public.rides add column if not exists test_run boolean not null default false;
create index if not exists rides_test_run_idx on public.rides(test_run,status,created_at desc);

create or replace function public.create_ride_quote(
  p_origin_lat double precision,
  p_origin_lng double precision,
  p_destination_name text,
  p_distance_km numeric,
  p_duration_min numeric,
  p_payment_method text default 'pix'
)
returns public.rides
language plpgsql
security definer
set search_path=public
as $$
declare
  r public.rides;
  v_fare numeric(10,2);
  v_method text := lower(coalesce(p_payment_method,'pix'));
  v_test boolean := public.get_test_mode();
begin
  if auth.uid() is null then raise exception 'Usuário não autenticado'; end if;
  if p_origin_lat is null or p_origin_lng is null then raise exception 'Localização de origem obrigatória'; end if;
  if p_distance_km is null or p_distance_km < 0 or p_distance_km > 500 then raise exception 'Distância inválida'; end if;
  if p_duration_min is null or p_duration_min < 0 or p_duration_min > 1440 then raise exception 'Duração inválida'; end if;
  if v_method not in ('pix','card','cash') then raise exception 'Método de pagamento inválido'; end if;

  v_fare := public.estimate_ride_fare(p_distance_km,p_duration_min);
  insert into public.rides(
    passenger_id,origin_lat,origin_lng,destination_name,ride_type,
    estimated_price,fare_estimate,route_distance_km,route_duration_min,
    quote_source,payment_method,payment_status,status,test_run
  ) values (
    auth.uid(),p_origin_lat,p_origin_lng,nullif(trim(p_destination_name),''),'simple',
    v_fare,v_fare,round(p_distance_km,2),round(p_duration_min,2),
    'vai_route',v_method,'pending','requested',v_test
  ) returning * into r;
  return r;
end;
$$;
revoke all on function public.create_ride_quote(double precision,double precision,text,numeric,numeric,text) from public;
grant execute on function public.create_ride_quote(double precision,double precision,text,numeric,numeric,text) to authenticated;

-- Diagnóstico específico do cenário E2E atual.
create or replace function public.test_e2e_status(p_ride_id uuid default null)
returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare r public.rides;
begin
  if not public.get_test_mode() then raise exception 'Laboratório de testes está desligado'; end if;
  if p_ride_id is not null then
    select * into r from public.rides where id=p_ride_id and (passenger_id=auth.uid() or driver_id=auth.uid());
  end if;
  return jsonb_build_object(
    'test_mode',true,
    'authenticated',auth.uid() is not null,
    'ride_id',r.id,
    'ride_status',r.status,
    'driver_id',r.driver_id,
    'payment_status',r.payment_status,
    'test_run',coalesce(r.test_run,false),
    'server_time',now()
  );
end;
$$;
revoke all on function public.test_e2e_status(uuid) from public;
grant execute on function public.test_e2e_status(uuid) to authenticated;
