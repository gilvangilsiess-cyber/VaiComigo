-- VaiComigo v47 — suporte ao teste ponta a ponta (idempotente)
-- Depende de: base (profiles/drivers/rides) + v12…v46.
-- Não liga o laboratório de teste e não altera a política real de aprovação.

-- 1) Cadastro de motorista pelo próprio usuário.
--    Produção: nasce 'pending' (aprovação por documentos/admin).
--    Laboratório LIGADO (v46): nasce/fica 'approved'. Nunca aprova com o laboratório desligado.
create or replace function public.register_driver(
  p_full_name text,
  p_phone text,
  p_vehicle_model text,
  p_vehicle_plate text,
  p_vehicle_color text default null,
  p_vehicle_year integer default null
)
returns public.drivers
language plpgsql
security definer
set search_path=public
as $$
declare
  d public.drivers;
  u uuid := auth.uid();
  v_test boolean := public.get_test_mode();
begin
  if u is null then raise exception 'Usuário não autenticado'; end if;
  if nullif(trim(p_full_name),'') is null then raise exception 'Informe o nome completo'; end if;
  if nullif(trim(p_vehicle_model),'') is null then raise exception 'Informe o modelo do veículo'; end if;
  if nullif(trim(p_vehicle_plate),'') is null then raise exception 'Informe a placa do veículo'; end if;

  insert into public.profiles(id,full_name,phone)
  values(u,nullif(trim(p_full_name),''),nullif(trim(p_phone),''))
  on conflict(id) do update set
    full_name=coalesce(excluded.full_name,public.profiles.full_name),
    phone=coalesce(excluded.phone,public.profiles.phone);

  insert into public.drivers(
    id,status,full_name,phone,vehicle_model,vehicle_plate,vehicle_color,vehicle_year,document_status,updated_at
  ) values(
    u,'offline',trim(p_full_name),nullif(trim(p_phone),''),trim(p_vehicle_model),
    upper(trim(p_vehicle_plate)),nullif(trim(p_vehicle_color),''),p_vehicle_year,
    case when v_test then 'approved' else 'pending' end,now()
  )
  on conflict(id) do update set
    full_name=excluded.full_name,
    phone=excluded.phone,
    vehicle_model=excluded.vehicle_model,
    vehicle_plate=excluded.vehicle_plate,
    vehicle_color=excluded.vehicle_color,
    vehicle_year=excluded.vehicle_year,
    document_status=case when v_test then 'approved' else public.drivers.document_status end,
    updated_at=now()
  returning * into d;

  return d;
end;
$$;
revoke all on function public.register_driver(text,text,text,text,text,integer) from public, anon;
grant execute on function public.register_driver(text,text,text,text,text,integer) to authenticated;

-- 2) Cancelamento pelo passageiro (a tela já chamava cancel_ride, que não existia).
create or replace function public.cancel_ride(p_ride_id uuid)
returns public.rides
language plpgsql
security definer
set search_path=public
as $$
declare r public.rides;
begin
  if auth.uid() is null then raise exception 'Usuário não autenticado'; end if;

  update public.rides
     set status='cancelled',
         cancelled_at=coalesce(cancelled_at,now())
   where id=p_ride_id
     and passenger_id=auth.uid()
     and status in ('requested','accepted','arriving')
   returning * into r;

  if r.id is null then raise exception 'Esta corrida não pode mais ser cancelada'; end if;

  if r.driver_id is not null then
    update public.drivers
       set status=case when document_status='approved' then 'available' else 'offline' end,
           updated_at=now()
     where id=r.driver_id and status='busy';
  end if;

  return r;
end;
$$;
revoke all on function public.cancel_ride(uuid) from public, anon;
grant execute on function public.cancel_ride(uuid) to authenticated;

-- 3) Relatório de despacho para o Diagnóstico E2E. Só funciona com o laboratório LIGADO e
--    só para participantes da corrida. Não expõe identidade de outros motoristas (apenas contagens).
create or replace function public.test_e2e_report(p_ride_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  u uuid := auth.uid();
  r public.rides;
  q public.ride_push_queue;
  v_eligible integer := 0;
  v_eligible_subs integer := 0;
  v_nearby_any integer := 0;
  v_available_total integer := 0;
begin
  if u is null then raise exception 'Usuário não autenticado'; end if;
  if not public.get_test_mode() then raise exception 'Laboratório de testes está desligado'; end if;

  if p_ride_id is not null then
    select * into r from public.rides where id=p_ride_id and (passenger_id=u or driver_id=u);
  else
    select * into r from public.rides
     where passenger_id=u or driver_id=u
     order by created_at desc limit 1;
  end if;

  if r.id is null then
    return jsonb_build_object('has_ride',false,'server_time',now());
  end if;

  select * into q from public.ride_push_queue where ride_id=r.id;

  select count(*) into v_eligible from public.push_ride_candidates(r.id,10,180);
  select count(*) into v_eligible_subs from public.push_subscriptions s
   where s.user_id in (select c.driver_id from public.push_ride_candidates(r.id,10,180) c);
  select count(*) into v_available_total from public.drivers where status='available';
  select count(*) into v_nearby_any from public.drivers d
   where d.status='available' and d.lat is not null and d.lng is not null
     and r.origin_lat is not null and r.origin_lng is not null
     and earth_distance(ll_to_earth(r.origin_lat,r.origin_lng),ll_to_earth(d.lat,d.lng)) <= 10000;

  return jsonb_build_object(
    'has_ride',true,
    'ride',jsonb_build_object(
      'id',r.id,'status',r.status,'test_run',coalesce(r.test_run,false),
      'payment_method',r.payment_method,'payment_status',r.payment_status,
      'has_driver',r.driver_id is not null,
      'created_at',r.created_at,'accepted_at',r.accepted_at,'arrived_at',r.arrived_at,
      'started_at',r.started_at,'completed_at',r.completed_at,'cancelled_at',r.cancelled_at),
    'dispatch',jsonb_build_object(
      'radius_km',10,'fresh_seconds',180,
      'eligible_now',v_eligible,
      'eligible_with_push_subscription',v_eligible_subs,
      'available_nearby_any_gps_age',v_nearby_any,
      'available_total',v_available_total),
    'push_queue',case when q.ride_id is null then jsonb_build_object('exists',false)
      else jsonb_build_object('exists',true,'attempts',q.attempts,'max_attempts',q.max_attempts,
        'processed_at',q.processed_at,'next_attempt_at',q.next_attempt_at,
        'locked_until',q.locked_until,'last_error',q.last_error,'created_at',q.created_at) end,
    'payment',(select jsonb_build_object('status',t.status,'method',t.method,'provider',t.provider,'paid_at',t.paid_at)
                 from public.payment_transactions t where t.ride_id=r.id limit 1),
    'server_time',now()
  );
end;
$$;
revoke all on function public.test_e2e_report(uuid) from public, anon;
grant execute on function public.test_e2e_report(uuid) to authenticated;
