-- VaiComigo v47 — endurecimento de permissões de RPC (RECOMENDADO, independente do teste)
-- No Supabase, "revoke ... from public" NÃO remove os grants diretos a anon/authenticated
-- criados pelos privilégios padrão do schema public. Aqui revogamos explicitamente.
-- Idempotente; ignora funções que não existam.

do $$
declare f record;
begin
  -- Somente service_role (Edge Functions / webhook / cron).
  for f in
    select p.oid::regprocedure as sig
      from pg_proc p join pg_namespace n on n.oid=p.pronamespace
     where n.nspname='public'
       and p.proname in ('push_ride_candidates','claim_ride_push','finish_ride_push',
                         'pending_ride_pushes','sync_external_payment','cleanup_driver_location_history')
  loop
    execute format('revoke all on function %s from public, anon, authenticated', f.sig);
    execute format('grant execute on function %s to service_role', f.sig);
  end loop;

  -- Usuários autenticados apenas (anon nunca precisa destas).
  for f in
    select p.oid::regprocedure as sig
      from pg_proc p join pg_namespace n on n.oid=p.pronamespace
     where n.nspname='public'
       and p.proname in ('nearest_requested_rides','accept_ride','update_ride_status','complete_ride',
                         'cancel_ride','create_ride_quote','update_driver_location',
                         'set_driver_availability','get_my_app_context','confirm_cash_payment',
                         'create_payment_intent','register_driver','update_my_driver_profile',
                         'test_prepare_my_driver','test_set_my_driver_location','test_e2e_status',
                         'test_e2e_report','admin_set_test_mode','admin_test_overview','get_test_mode')
  loop
    execute format('revoke all on function %s from public, anon', f.sig);
    execute format('grant execute on function %s to authenticated, service_role', f.sig);
  end loop;
end $$;
