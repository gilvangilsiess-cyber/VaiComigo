-- VaiComigo v48: restringe RPCs privilegiadas e impede alteração unilateral da tarifa.
-- get_shared_trip(text) continua pública: o token é a autorização do link compartilhado.
do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as signature
    from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.prosecdef
      and p.proname <> 'get_shared_trip'
  loop
    execute format('revoke execute on function %s from public, anon', f.signature);
  end loop;

  -- Funções para gatilhos/serviço não são chamadas por passageiros ou motoristas.
  for f in
    select p.oid::regprocedure as signature
    from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname in (
      'enqueue_ride_push','ensure_notification_preferences','expire_driver_documents',
      'rls_auto_enable','v40_payment_notification','v40_ride_notification',
      'v40_support_notification','notify_user','claim_ride_push','finish_ride_push',
      'push_ride_candidates','pending_ride_pushes','sync_external_payment',
      'cleanup_driver_location_history')
  loop
    execute format('revoke execute on function %s from authenticated', f.signature);
  end loop;
end $$;

create or replace function public.complete_ride(p_ride_id uuid, p_final_price numeric default null)
returns public.rides
language plpgsql security definer set search_path=public
as $$
declare r public.rides;
begin
  if auth.uid() is null then raise exception 'Usuário não autenticado'; end if;
  -- Parâmetro preservado para compatibilidade com versões antigas do app.
  -- O motorista não define o valor cobrado; vale a tarifa calculada pelo servidor.
  update public.rides
     set status='completed', completed_at=coalesce(completed_at,now()),
         final_price=coalesce(estimated_price,fare_estimate)
   where id=p_ride_id and driver_id=auth.uid() and status='in_progress'
   returning * into r;
  if r.id is null then raise exception 'Corrida não está em andamento ou não pertence ao motorista'; end if;
  if r.final_price is null then raise exception 'Tarifa da corrida ausente'; end if;
  update public.drivers
     set status=case when document_status='approved' then 'offline' else 'suspended' end,
         updated_at=now()
   where id=auth.uid();
  return r;
end;
$$;
revoke execute on function public.complete_ride(uuid,numeric) from public, anon;
grant execute on function public.complete_ride(uuid,numeric) to authenticated;

create or replace function public.estimate_ride_fare(p_distance_km numeric,p_duration_min numeric)
returns numeric language sql immutable set search_path=public
as $$
  select greatest(10.00,round((6.00 + p_distance_km * 2.40 + p_duration_min * 0.35)::numeric,2));
$$;

-- O papel administrativo é decidido no servidor. O cliente só edita dados de contato.
revoke insert, update on public.profiles from public, anon, authenticated;
grant insert (id,full_name,phone) on public.profiles to authenticated;
grant update (full_name,phone) on public.profiles to authenticated;

-- O fluxo do Tour no app grava estes campos. Sua ausência fazia a reserva falhar.
alter table public.tour_bookings add column if not exists route_code text;
alter table public.tour_bookings add column if not exists itinerary jsonb;

-- Limita inserção e cancelamento diretos do passageiro; motorista/admin usam RPCs auditadas.
revoke insert, update, delete on public.tour_bookings from public, anon, authenticated;
grant insert (passenger_id,start_at,duration_hours,price,status,pickup_lat,pickup_lng,route_code,itinerary)
  on public.tour_bookings to authenticated;
grant update (status) on public.tour_bookings to authenticated;

create or replace function public.guard_passenger_tour()
returns trigger language plpgsql set search_path=public as $$
begin
  if current_user <> 'authenticated' then return new; end if;
  if tg_op='INSERT' then
    if new.passenger_id is distinct from auth.uid() or new.driver_id is not null
       or new.status <> 'requested' or new.duration_hours not in (4,6,8)
       or new.price is distinct from (case new.duration_hours when 4 then 200 when 6 then 280 when 8 then 360 end)
    then raise exception 'Solicitação de Tour inválida'; end if;
  elsif tg_op='UPDATE' then
    if old.status <> 'requested' or new.status <> 'cancelled' or
       (to_jsonb(new) - 'status' - 'updated_at') is distinct from (to_jsonb(old) - 'status' - 'updated_at')
    then raise exception 'Somente cancelamento de Tour solicitado é permitido'; end if;
  end if;
  return new;
end;
$$;
drop trigger if exists trg_guard_passenger_tour on public.tour_bookings;
create trigger trg_guard_passenger_tour before insert or update on public.tour_bookings
for each row execute function public.guard_passenger_tour();
revoke execute on function public.guard_passenger_tour() from public, anon, authenticated;

-- Guarda o destino exato para navegação do motorista e evita depender de geocodificar o nome novamente.
alter table public.rides add column if not exists destination_lat double precision;
alter table public.rides add column if not exists destination_lng double precision;

create or replace function public.create_ride_with_destination(
  p_origin_lat double precision,p_origin_lng double precision,p_destination_name text,
  p_destination_lat double precision,p_destination_lng double precision,
  p_distance_km numeric,p_duration_min numeric,p_payment_method text
)
returns public.rides language plpgsql security definer set search_path=public as $$
declare r public.rides;
begin
  if auth.uid() is null then raise exception 'Usuário não autenticado'; end if;
  if p_destination_lat is null or p_destination_lat < -90 or p_destination_lat > 90
     or p_destination_lng is null or p_destination_lng < -180 or p_destination_lng > 180
  then raise exception 'Coordenadas de destino inválidas'; end if;
  if p_origin_lat is null or p_origin_lat < -90 or p_origin_lat > 90
     or p_origin_lng is null or p_origin_lng < -180 or p_origin_lng > 180
  then raise exception 'Coordenadas de origem inválidas'; end if;
  -- Não aceita distância menor que a linha reta ou duração fisicamente implausível.
  if p_distance_km is null or p_distance_km <
       earth_distance(ll_to_earth(p_origin_lat,p_origin_lng),
                      ll_to_earth(p_destination_lat,p_destination_lng))/1000 * 0.85
     or p_duration_min is null or p_duration_min < p_distance_km * 0.4
  then raise exception 'Rota e duração incompatíveis com os pontos informados'; end if;
  r := public.create_ride_quote(p_origin_lat,p_origin_lng,p_destination_name,
                                p_distance_km,p_duration_min,p_payment_method);
  update public.rides set destination_lat=p_destination_lat,destination_lng=p_destination_lng
   where id=r.id returning * into r;
  return r;
end;
$$;
revoke execute on function public.create_ride_with_destination(double precision,double precision,text,double precision,double precision,numeric,numeric,text) from public,anon;
grant execute on function public.create_ride_with_destination(double precision,double precision,text,double precision,double precision,numeric,numeric,text) to authenticated;
-- Bloqueia o endpoint antigo, que não recebia coordenadas e aceitava duração arbitrária.
revoke execute on function public.create_ride_quote(double precision,double precision,text,numeric,numeric,text)
  from public, anon, authenticated;
