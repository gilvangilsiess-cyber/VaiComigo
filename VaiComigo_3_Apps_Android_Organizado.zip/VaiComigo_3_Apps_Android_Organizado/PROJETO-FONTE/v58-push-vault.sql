-- O par VAPID fica em Vault; apenas service_role pode obtê-lo via RPC.
-- Esta migration não contém segredos. Criar os segredos no Vault em operação separada.
create or replace function public.get_push_vapid_keys()
returns jsonb
language sql
security definer
set search_path = ''
as $$
  select jsonb_build_object(
    'public_key', max(decrypted_secret) filter (where name = 'vai_vapid_public_v1'),
    'private_key', max(decrypted_secret) filter (where name = 'vai_vapid_private_v1')
  )
  from vault.decrypted_secrets
  where name in ('vai_vapid_public_v1', 'vai_vapid_private_v1');
$$;
revoke all on function public.get_push_vapid_keys() from public, anon, authenticated;
grant execute on function public.get_push_vapid_keys() to service_role;
