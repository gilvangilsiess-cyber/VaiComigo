-- Disparo imediato e retentativas Web Push sem depender do celular do passageiro.
create extension if not exists pg_net with schema extensions;
create extension if not exists pg_cron with schema pg_catalog;

create or replace function public.get_push_webhook_secret()
returns text
language sql
security definer
set search_path = ''
as $$
  select decrypted_secret from vault.decrypted_secrets
  where name = 'vai_webhook_secret_v1' limit 1;
$$;
revoke all on function public.get_push_webhook_secret() from public, anon, authenticated;
grant execute on function public.get_push_webhook_secret() to service_role;

create schema if not exists private;
revoke all on schema private from public, anon, authenticated;

create or replace function private.dispatch_ride_push()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  perform net.http_post(
    url := 'https://uuywjwmarjrmcjtvezbg.supabase.co/functions/v1/push-notify',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-vai-webhook-secret', (select decrypted_secret from vault.decrypted_secrets where name = 'vai_webhook_secret_v1')
    ),
    body := jsonb_build_object('action', 'process_ride_queue', 'ride_id', new.ride_id),
    timeout_milliseconds := 10000
  );
  return new;
end;
$$;
revoke all on function private.dispatch_ride_push() from public, anon, authenticated;
drop trigger if exists vai_ride_push_dispatch on public.ride_push_queue;
create trigger vai_ride_push_dispatch after insert on public.ride_push_queue
for each row execute function private.dispatch_ride_push();

select cron.schedule(
  'vai_push_retry_minutely',
  '* * * * *',
  $$select net.http_post(
    url := 'https://uuywjwmarjrmcjtvezbg.supabase.co/functions/v1/push-notify',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-vai-webhook-secret', (select decrypted_secret from vault.decrypted_secrets where name = 'vai_webhook_secret_v1')
    ),
    body := '{"action":"process_ride_queue"}'::jsonb,
    timeout_milliseconds := 10000
  );$$
);
