-- Etapa 1 — geografia indexada e localização privada por corrida.
create schema if not exists extensions;
create extension if not exists postgis with schema extensions;

create index if not exists drivers_location_geog_gist
 on public.drivers using gist ((extensions.ST_SetSRID(extensions.ST_MakePoint(lng,lat),4326)::extensions.geography))
 where lat between -90 and 90 and lng between -180 and 180 and status='available';
create index if not exists rides_driver_active_idx on public.rides(driver_id,status)
 where driver_id is not null and status in ('accepted','arriving','in_progress');

-- Apenas participantes autenticados podem escutar o canal privado de uma corrida ativa.
create policy "ride_participants_receive_location"
 on realtime.messages for select to authenticated
 using (
   extension='broadcast' and realtime.topic() ~ '^ride-location:[0-9a-f-]{36}$'
   and exists (
     select 1 from public.rides r
     where r.id::text=split_part(realtime.topic(),':',2)
       and r.status in ('accepted','arriving','in_progress')
       and ((select auth.uid())=r.passenger_id or (select auth.uid())=r.driver_id)
   )
 );

-- A RPC de posição atual não expõe a tabela inteira de motoristas.
create or replace function public.ride_driver_location(p_ride_id uuid)
returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('lat',d.lat,'lng',d.lng,'heading',d.heading,
   'accuracy',d.location_accuracy,'location_updated_at',d.location_updated_at)
 from public.rides r join public.drivers d on d.id=r.driver_id
 where r.id=p_ride_id and r.status in ('accepted','arriving','in_progress')
   and ((select auth.uid())=r.passenger_id or (select auth.uid())=r.driver_id)
   and d.lat between -90 and 90 and d.lng between -180 and 180
 limit 1
$$;
revoke all on function public.ride_driver_location(uuid) from public,anon;
grant execute on function public.ride_driver_location(uuid) to authenticated;

-- Publicação parte do banco: clientes não recebem permissão de enviar posição falsificada.
create or replace function public.broadcast_driver_ride_location()
returns trigger language plpgsql security definer set search_path='' as $$
declare ride_id uuid;
begin
 if new.lat is null or new.lng is null then return new; end if;
 if old.lat is not distinct from new.lat and old.lng is not distinct from new.lng
    and old.location_updated_at is not distinct from new.location_updated_at then return new; end if;
 for ride_id in select r.id from public.rides r
   where r.driver_id=new.id and r.status in ('accepted','arriving','in_progress')
 loop
   perform realtime.send(jsonb_build_object('lat',new.lat,'lng',new.lng,
      'heading',new.heading,'accuracy',new.location_accuracy,
      'location_updated_at',new.location_updated_at),
      'position','ride-location:'||ride_id::text,true);
 end loop;
 return new;
end $$;
revoke all on function public.broadcast_driver_ride_location() from public,anon,authenticated;
drop trigger if exists driver_ride_location_broadcast on public.drivers;
create trigger driver_ride_location_broadcast after update of lat,lng,location_updated_at on public.drivers
 for each row execute function public.broadcast_driver_ride_location();
