-- Busca local categorizada e dados pessoais de lugares.
create extension if not exists pg_trgm with schema extensions;

create table if not exists public.ride_pois (
 id uuid primary key default gen_random_uuid(),
 name text not null check(length(name) between 2 and 160),
 address text not null check(length(address) between 2 and 320),
 aliases text[] not null default '{}',
 category text not null check(category in ('address','neighborhood','shopping','hotel','tourism','transport','business','other')),
 location extensions.geography(Point,4326) not null,
 provider text not null default 'editorial',
 verified boolean not null default false,
 updated_at timestamptz not null default now(),
 search_text text not null default ''
);
create or replace function public.ride_poi_search_text() returns trigger language plpgsql set search_path='' as $$
begin
 new.search_text:=translate(lower(new.name||' '||new.address||' '||array_to_string(new.aliases,' ')),
   'áàâãäéèêëíìîïóòôõöúùûüç','aaaaaeeeeiiiiooooouuuuc');
 return new;
end $$;
create trigger ride_poi_search_text before insert or update of name,address,aliases on public.ride_pois
 for each row execute function public.ride_poi_search_text();
create index if not exists ride_pois_geo_idx on public.ride_pois using gist(location);
create index if not exists ride_pois_search_trgm_idx on public.ride_pois using gin(search_text extensions.gin_trgm_ops);
create unique index if not exists ride_pois_name_location_idx on public.ride_pois(lower(name), (extensions.ST_AsText(location::extensions.geometry)));
alter table public.ride_pois enable row level security;
create policy "published_places_are_visible" on public.ride_pois for select to anon,authenticated using(verified);
grant select on public.ride_pois to anon,authenticated;

insert into public.ride_pois(name,address,aliases,category,location,verified)
values
 ('Castelo de Itaipava','BR-040, km 56, Itaipava, Petrópolis - RJ',array['castelo','castelo do barão'],'hotel',extensions.ST_SetSRID(extensions.ST_MakePoint(-43.12510,-22.36076),4326)::extensions.geography,true),
 ('Museu Imperial','Rua da Imperatriz, 220, Centro, Petrópolis - RJ',array['museu','palácio imperial'],'tourism',extensions.ST_SetSRID(extensions.ST_MakePoint(-43.1779,-22.5096),4326)::extensions.geography,true),
 ('Catedral de São Pedro','Rua São Pedro de Alcântara, 60, Centro, Petrópolis - RJ',array['catedral'],'tourism',extensions.ST_SetSRID(extensions.ST_MakePoint(-43.1785,-22.5065),4326)::extensions.geography,true),
 ('Palácio Quitandinha','Avenida Joaquim Rolla, 2, Quitandinha, Petrópolis - RJ',array['quitandinha'],'tourism',extensions.ST_SetSRID(extensions.ST_MakePoint(-43.2310,-22.5215),4326)::extensions.geography,true)
on conflict do nothing;

create or replace function public.search_ride_pois(p_query text,p_lat double precision default -22.51,p_lng double precision default -43.18,p_limit int default 10)
returns table(id uuid,name text,address text,category text,lat double precision,lng double precision,distance_m double precision,score double precision)
language sql stable security invoker set search_path='' as $$
 with input as(select translate(lower(trim(coalesce(p_query,''))),'áàâãäéèêëíìîïóòôõöúùûüç','aaaaaeeeeiiiiooooouuuuc') as q,
   extensions.ST_SetSRID(extensions.ST_MakePoint(
      case when p_lng between -180 and 180 then p_lng else -43.18 end,
      case when p_lat between -90 and 90 then p_lat else -22.51 end),4326)::extensions.geography as origin)
 select p.id,p.name,p.address,p.category,
    extensions.ST_Y(p.location::extensions.geometry) as lat,
    extensions.ST_X(p.location::extensions.geometry) as lng,
    extensions.ST_Distance(p.location,i.origin) as distance_m,
    ((case when translate(lower(p.name),'áàâãäéèêëíìîïóòôõöúùûüç','aaaaaeeeeiiiiooooouuuuc')=i.q then 150 when p.search_text like i.q||'%' then 110
      when lower(p.search_text) like '%'||i.q||'%' then 70 else 0 end)
      + extensions.similarity(p.search_text,i.q)*45
      - least(extensions.ST_Distance(p.location,i.origin)/1300,35))::double precision as score
 from public.ride_pois p cross join input i
 where p.verified and length(i.q) between 1 and 120
   and (p.search_text like '%'||i.q||'%' or (length(i.q)>=3 and p.search_text OPERATOR(extensions.%) i.q))
 order by score desc, distance_m asc limit least(greatest(p_limit,1),25)
$$;
revoke all on function public.search_ride_pois(text,double precision,double precision,int) from public;
grant execute on function public.search_ride_pois(text,double precision,double precision,int) to anon,authenticated;

create table if not exists public.saved_places (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 label text not null check(length(label) between 1 and 80), name text not null check(length(name) between 2 and 160),
 address text not null check(length(address) between 2 and 320),
 category text not null default 'address',lat double precision not null check(lat between -90 and 90),
 lng double precision not null check(lng between -180 and 180),
 created_at timestamptz not null default now(),unique(user_id,label)
);
create index if not exists saved_places_user_idx on public.saved_places(user_id);
alter table public.saved_places enable row level security;
create policy "saved_places_owner_read" on public.saved_places for select to authenticated using(user_id=(select auth.uid()));
create policy "saved_places_owner_insert" on public.saved_places for insert to authenticated with check(user_id=(select auth.uid()));
create policy "saved_places_owner_update" on public.saved_places for update to authenticated using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()));
create policy "saved_places_owner_delete" on public.saved_places for delete to authenticated using(user_id=(select auth.uid()));
grant select,insert,update,delete on public.saved_places to authenticated;

create table if not exists public.recent_places (
 user_id uuid not null references auth.users(id) on delete cascade,
 place_key text not null check(length(place_key) between 2 and 180),
 name text not null check(length(name) between 2 and 160), address text not null,
 category text not null default 'address', lat double precision not null check(lat between -90 and 90),
 lng double precision not null check(lng between -180 and 180),last_used_at timestamptz not null default now(),
 primary key(user_id,place_key)
);
create index if not exists recent_places_user_time_idx on public.recent_places(user_id,last_used_at desc);
alter table public.recent_places enable row level security;
create policy "recent_places_owner_read" on public.recent_places for select to authenticated using(user_id=(select auth.uid()));
create policy "recent_places_owner_insert" on public.recent_places for insert to authenticated with check(user_id=(select auth.uid()));
create policy "recent_places_owner_update" on public.recent_places for update to authenticated using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()));
create policy "recent_places_owner_delete" on public.recent_places for delete to authenticated using(user_id=(select auth.uid()));
grant select,insert,update,delete on public.recent_places to authenticated;
