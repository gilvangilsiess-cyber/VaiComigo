-- Cache somente de resultados OSM/Photon; fornecedores com restrições de retenção não entram aqui.
create table if not exists public.place_search_cache(
 cache_key text primary key, payload jsonb not null, expires_at timestamptz not null,
 created_at timestamptz not null default now()
);
create index if not exists place_search_cache_expiry_idx on public.place_search_cache(expires_at);
alter table public.place_search_cache enable row level security;
revoke all on public.place_search_cache from anon,authenticated;
