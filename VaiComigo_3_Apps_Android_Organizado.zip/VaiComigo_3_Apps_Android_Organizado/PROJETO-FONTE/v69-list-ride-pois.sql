-- Catálogo editorial para respostas imediatas e uso degradado no navegador.
create or replace function public.list_ride_pois()
returns table(id uuid,name text,address text,aliases text[],category text,lat double precision,lng double precision)
language sql stable security invoker set search_path='' as $$
 select p.id,p.name,p.address,p.aliases,p.category,
 extensions.ST_Y(p.location::extensions.geometry),extensions.ST_X(p.location::extensions.geometry)
 from public.ride_pois p where p.verified order by p.name limit 2000
$$;
revoke all on function public.list_ride_pois() from public;
grant execute on function public.list_ride_pois() to anon,authenticated;
