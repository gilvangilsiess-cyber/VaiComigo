-- RLS por dono + remoção do grant padrão do papel PUBLIC.
revoke all on public.saved_places from public,anon;
revoke all on public.recent_places from public,anon;
grant select,insert,update,delete on public.saved_places to authenticated;
grant select,insert,update,delete on public.recent_places to authenticated;
