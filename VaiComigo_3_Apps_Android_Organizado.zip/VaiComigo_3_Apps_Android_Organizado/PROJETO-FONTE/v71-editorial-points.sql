-- Coordenadas verificadas por objetos OSM/Photon e dados de endereço disponíveis.
-- Terminais sem ponto de acesso confirmado não são inventados como locais de embarque.
insert into public.ride_pois(name,address,aliases,category,location,verified)
values
 ('Centro','Centro, Petrópolis - RJ',array['centro de petropolis','bairro centro'],'neighborhood',extensions.ST_SetSRID(extensions.ST_MakePoint(-43.1754892,-22.5099814),4326)::extensions.geography,true),
 ('Itaipava','Itaipava, Petrópolis - RJ',array['bairro itaipava','distrito itaipava'],'neighborhood',extensions.ST_SetSRID(extensions.ST_MakePoint(-43.1421,-22.4127),4326)::extensions.geography,true),
 ('Terminal Rodoviário Imperatriz Leopoldina','Rua Doutor Porciúncula, 75, Centro, Petrópolis - RJ',array['rodoviaria','rodoviária do centro','terminal centro','terminal rodoviario'],'transport',extensions.ST_SetSRID(extensions.ST_MakePoint(-43.1699262,-22.5081307),4326)::extensions.geography,true),
 ('Palácio de Cristal','Rua Alfredo Pachá, Centro, Petrópolis - RJ',array['palacio','castelo','ponto turistico'],'tourism',extensions.ST_SetSRID(extensions.ST_MakePoint(-43.18308,-22.50544),4326)::extensions.geography,true)
on conflict do nothing;
