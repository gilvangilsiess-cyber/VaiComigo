-- Terminal do Bingen: OSM way 256719153, identificado em 24/09/2026.
-- Coordenada representa o centro da estação, não a posição de embarque de veículos.
insert into public.ride_pois(name,address,aliases,category,location,provider,verified)
values ('Rodoviária de Petrópolis - Terminal Governador Leonel Brizola',
 'Rodovia Washington Luiz, Bingen, Petrópolis - RJ',
 array['rodoviaria','rodoviária do bingen','rodoviaria do bingen','terminal do bingen','terminal rodoviario','terminal leonel brizola','estacao rodoviaria petropolis'],
 'transport',extensions.ST_SetSRID(extensions.ST_MakePoint(-43.2290271,-22.5162932),4326)::extensions.geography,
 'osm:way:256719153',true)
on conflict do nothing;
