-- Catálogo offline completo mesmo com o limite padrão de linhas da API REST.
create or replace function public.list_ride_pois_page(p_offset integer default 0,p_limit integer default 400)
returns table(id uuid,name text,address text,aliases text[],category text,lat double precision,lng double precision)
language sql stable security invoker set search_path='' as $$
 select p.id,p.name,p.address,p.aliases,p.category,
 extensions.ST_Y(p.location::extensions.geometry),extensions.ST_X(p.location::extensions.geometry)
 from public.ride_pois p where p.verified order by p.name,p.id
 limit least(greatest(p_limit,1),500) offset greatest(p_offset,0)
$$;
revoke all on function public.list_ride_pois_page(integer,integer) from public;
grant execute on function public.list_ride_pois_page(integer,integer) to anon,authenticated;
