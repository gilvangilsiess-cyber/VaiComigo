-- Consultas genéricas por categoria incluem todos os bairros conhecidos.
update public.ride_pois
set aliases=array_append(aliases,'bairro')
where category='neighborhood' and not ('bairro'=any(aliases));
